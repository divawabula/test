import React, { useState, useEffect } from "react";
import { Clock, RefreshCw, Trash2, Download, Disc3, HardDrive } from "lucide-react";
import { CachedItem, AudioFormat } from "../types";

interface CacheManagerProps {
  onSelectSong: (videoId: string) => void;
  refreshTrigger: number;
}

export const CacheManager: React.FC<CacheManagerProps> = ({
  onSelectSong,
  refreshTrigger,
}) => {
  const [items, setItems] = useState<CachedItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [currentTime, setCurrentTime] = useState(Date.now());

  const fetchCache = async () => {
    try {
      const res = await fetch("/api/cache");
      const data = await res.json();
      if (data.items) {
        setItems(data.items);
      }
    } catch (err) {
      console.error("Gagal mengambil data cache:", err);
    }
  };

  useEffect(() => {
    fetchCache();
    const syncInterval = setInterval(fetchCache, 3000);

    const handleMessage = (event: MessageEvent) => {
      if (
        event.data &&
        (event.data.type === "M4A_DOWNLOAD_RENEWED" ||
          event.data.type === "MP3_DOWNLOAD_RENEWED" ||
          event.data.type === "WEBM_DOWNLOAD_RENEWED")
      ) {
        fetchCache();
      }
    };
    window.addEventListener("message", handleMessage);

    return () => {
      clearInterval(syncInterval);
      window.removeEventListener("message", handleMessage);
    };
  }, [refreshTrigger]);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(Date.now());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleRenew = async (videoId: string, format: AudioFormat) => {
    setLoading(true);
    try {
      await fetch("/api/cache/renew", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ videoId, format }),
      });
      await fetchCache();
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (videoId: string) => {
    setLoading(true);
    try {
      await fetch(`/api/cache/${videoId}`, { method: "DELETE" });
      await fetchCache();
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + " B";
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
    return (bytes / (1024 * 1024)).toFixed(2) + " MB";
  };

  const formatCountdown = (expiresAt: number) => {
    const diff = Math.max(0, expiresAt - currentTime);
    const totalSecs = Math.floor(diff / 1000);
    const mins = Math.floor(totalSecs / 60);
    const secs = totalSecs % 60;
    return `${mins}m ${secs < 10 ? "0" : ""}${secs}s`;
  };

  return (
    <div className="w-full bg-white border-2 border-black p-4 sm:p-5 space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b-2 border-black pb-3">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 bg-black text-white flex items-center justify-center font-bold">
            <HardDrive className="w-4 h-4 text-[#FFE500]" />
          </div>
          <div>
            <h2 className="text-sm font-black uppercase tracking-wide text-black">
              Manajemen Cache Unduhan (TTL 15 Menit)
            </h2>
            <p className="text-[11px] text-zinc-600 font-medium">
              Format WebM, MP3, dan M4A disimpan selama 15 menit dan otomatis terhapus jika tidak diperpanjang.
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={fetchCache}
          className="inline-flex items-center gap-1.5 bg-[#fafafa] hover:bg-zinc-200 border-2 border-black px-2.5 py-1 text-xs font-bold cursor-pointer transition-colors"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
          <span>Refresh Cache</span>
        </button>
      </div>

      {/* Items List */}
      {items.length === 0 ? (
        <div className="py-8 text-center border-2 border-dashed border-zinc-300 bg-[#fafafa] space-y-1">
          <Disc3 className="w-8 h-8 text-zinc-400 mx-auto animate-pulse" />
          <p className="text-xs font-bold text-zinc-600">Belum ada file audio yang tersimpan di cache.</p>
          <p className="text-[11px] text-zinc-500">
            Unduh lagu melalui form atau buka page iframe <code className="font-mono">/webm/[id]</code>, <code className="font-mono">/mp3/[id]</code> untuk melihat status cache.
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {items.map((item) => {
            const isNearExpiry = item.expiresAt - currentTime < 180000;
            const fmt = item.format || (item.fileName.endsWith(".webm") ? "webm" : item.fileName.endsWith(".mp3") ? "mp3" : "m4a");
            return (
              <div
                key={`${item.videoId}_${fmt}`}
                className="p-3 border-2 border-black bg-[#fafafa] flex flex-col md:flex-row items-start md:items-center justify-between gap-3 transition-colors"
              >
                {/* Left: Artwork + Meta */}
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-12 h-12 shrink-0 border-2 border-black bg-zinc-200 overflow-hidden relative">
                    {item.metadata.coverArtUrl ? (
                      <img
                        src={item.metadata.coverArtUrl}
                        alt={item.metadata.title}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center font-black text-xs">
                        {fmt.toUpperCase()}
                      </div>
                    )}
                    <span className="absolute top-0 left-0 bg-black text-[#FFE500] text-[8px] font-mono font-bold px-1 border-b border-r border-black">
                      {fmt.toUpperCase()}
                    </span>
                  </div>

                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <h3 className="text-xs font-black text-black truncate max-w-xs sm:max-w-md">
                        {item.metadata.title}
                      </h3>
                      <span className="bg-black text-white text-[9px] font-mono font-bold px-1 uppercase">
                        {fmt}
                      </span>
                    </div>
                    <p className="text-[11px] text-zinc-700 font-semibold truncate">
                      {item.metadata.artist} &bull; {item.metadata.album || "Single"} ({item.metadata.year || "N/A"})
                    </p>
                    <div className="flex items-center gap-2 mt-0.5 text-[10px] text-zinc-600 font-mono">
                      <span>Ukuran: {formatFileSize(item.fileSize)}</span>
                      <span>&bull;</span>
                      <span>ID: {item.videoId}</span>
                    </div>
                  </div>
                </div>

                {/* Right: TTL Countdown & Action buttons */}
                <div className="flex flex-wrap items-center gap-2 w-full md:w-auto justify-between md:justify-end">
                  {/* Countdown Badge */}
                  <div
                    className={`flex items-center gap-1.5 px-2 py-1 border-2 border-black font-mono text-xs font-black ${
                      isNearExpiry ? "bg-[#FF5555] text-white" : "bg-[#FFE500] text-black"
                    }`}
                    title="Waktu tersisa sebelum dihapus otomatis"
                  >
                    <Clock className="w-3.5 h-3.5" />
                    <span>{formatCountdown(item.expiresAt)}</span>
                  </div>

                  {/* Renew Button */}
                  <button
                    type="button"
                    onClick={() => handleRenew(item.videoId, fmt)}
                    className="px-2.5 py-1 bg-white hover:bg-[#CCFF00] border-2 border-black text-xs font-bold transition-colors cursor-pointer flex items-center gap-1"
                    title="Perpanjang durasi penyimpanan kembali ke 15 menit penuh"
                  >
                    <RefreshCw className="w-3 h-3" />
                    <span>+15 Menit</span>
                  </button>

                  {/* Direct Download */}
                  <a
                    href={`/api/file/${item.videoId}?format=${fmt}`}
                    download={item.fileName}
                    onClick={() => {
                      setTimeout(() => handleRenew(item.videoId, fmt), 150);
                    }}
                    className="px-2.5 py-1 bg-black text-white hover:bg-[#FFE500] hover:text-black border-2 border-black text-xs font-black transition-colors flex items-center gap-1 cursor-pointer"
                    title={`Unduh file ${fmt.toUpperCase()} dan perbarui masa aktif kembali ke 15 menit`}
                  >
                    <Download className="w-3 h-3" />
                    <span>Unduh {fmt.toUpperCase()}</span>
                  </a>

                  {/* Delete Button */}
                  <button
                    type="button"
                    onClick={() => handleDelete(item.videoId)}
                    className="p-1 text-zinc-600 hover:text-red-600 hover:bg-zinc-200 border border-transparent hover:border-black transition-colors cursor-pointer"
                    title="Hapus dari cache sekarang"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
