import React, { useState } from "react";
import { Terminal, Code, ChevronDown, ChevronUp, Copy, Check, ShieldCheck, FileAudio, Music, Disc } from "lucide-react";

export const CommandReference: React.FC = () => {
  const [copiedWebm, setCopiedWebm] = useState(false);
  const [copiedMp3, setCopiedMp3] = useState(false);
  const [copiedM4a, setCopiedM4a] = useState(false);
  const [expanded, setExpanded] = useState(false);

  const webmCommand = `yt-dlp \\
  -f "bestaudio[ext=webm]" \\
  "https://music.youtube.com/watch?v=[idyoutube]"`;

  const mp3Command = `yt-dlp \\
  -f "bestaudio/best" \\
  -x \\
  --audio-format mp3 \\
  --audio-quality 0 \\
  "https://music.youtube.com/watch?v=[idyoutube]"`;

  const m4aCommand = `yt-dlp \\
  -f "ba[acodec^=mp4a.40.]/ba" \\
  "https://music.youtube.com/watch?v=[idyoutube]"`;

  const copyWebm = () => {
    navigator.clipboard.writeText(webmCommand);
    setCopiedWebm(true);
    setTimeout(() => setCopiedWebm(false), 2000);
  };

  const copyMp3 = () => {
    navigator.clipboard.writeText(mp3Command);
    setCopiedMp3(true);
    setTimeout(() => setCopiedMp3(false), 2000);
  };

  const copyM4a = () => {
    navigator.clipboard.writeText(m4aCommand);
    setCopiedM4a(true);
    setTimeout(() => setCopiedM4a(false), 2000);
  };

  return (
    <div className="w-full bg-white border-2 border-black">
      {/* Accordion Bar */}
      <button
        type="button"
        onClick={() => setExpanded(!expanded)}
        className="w-full px-4 py-3 bg-[#fafafa] hover:bg-zinc-100 flex items-center justify-between text-left cursor-pointer transition-colors"
      >
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-black" />
          <span className="text-xs font-black uppercase tracking-wider text-black">
            Spesifikasi Eksekusi yt-dlp (WebM &bull; MP3 &bull; M4A)
          </span>
          <span className="hidden sm:inline-block text-[10px] bg-black text-[#FFE500] px-2 py-0.5 font-mono font-bold">
            /usr/local/bin/yt-dlp
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-zinc-600">
            {expanded ? "Sembunyikan Detail" : "Lihat Perintah & Format"}
          </span>
          {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </div>
      </button>

      {/* Expanded Content */}
      {expanded && (
        <div className="p-4 sm:p-5 border-t-2 border-black space-y-4 text-xs">
          {/* 1. WebM Command (Direct, No Metadata) */}
          <div className="space-y-1.5 border-2 border-black p-3 bg-zinc-50">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Disc className="w-4 h-4 text-black" />
                <span className="font-black text-black uppercase tracking-wide">
                  Konfigurasi yt-dlp Format WebM (Langsung Tanpa Metadata):
                </span>
              </div>
              <button
                type="button"
                onClick={copyWebm}
                className="inline-flex items-center gap-1 bg-white hover:bg-[#FFE500] border-2 border-black px-2 py-0.5 font-bold text-[11px] cursor-pointer"
              >
                {copiedWebm ? <Check className="w-3.5 h-3.5 text-green-700" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedWebm ? "Tersalin!" : "Salin Perintah WebM"}</span>
              </button>
            </div>

            <div className="bg-black text-[#2DD4BF] p-3 font-mono text-[11px] sm:text-xs overflow-x-auto border-2 border-black leading-relaxed whitespace-pre">
              <code>{webmCommand}</code>
            </div>
            <p className="text-[11px] text-zinc-600 font-medium">
              * Mode WebM mengunduh stream audio asli opus/vorbis dalam kontainer webm secara langsung tanpa penanaman metadata ID3/cover art. Halaman iframe: <code className="font-bold text-black font-mono">/webm/[idyoutube]</code>.
            </p>
          </div>

          {/* 2. MP3 Command */}
          <div className="space-y-1.5 border-2 border-black p-3 bg-zinc-50">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <FileAudio className="w-4 h-4 text-black" />
                <span className="font-black text-black uppercase tracking-wide">
                  Konfigurasi yt-dlp Format MP3 (Best Audio + Tagging):
                </span>
              </div>
              <button
                type="button"
                onClick={copyMp3}
                className="inline-flex items-center gap-1 bg-white hover:bg-[#FFE500] border-2 border-black px-2 py-0.5 font-bold text-[11px] cursor-pointer"
              >
                {copiedMp3 ? <Check className="w-3.5 h-3.5 text-green-700" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedMp3 ? "Tersalin!" : "Salin Perintah MP3"}</span>
              </button>
            </div>

            <div className="bg-black text-[#CCFF00] p-3 font-mono text-[11px] sm:text-xs overflow-x-auto border-2 border-black leading-relaxed whitespace-pre">
              <code>{mp3Command}</code>
            </div>
            <p className="text-[11px] text-zinc-600 font-medium">
              * Mode MP3 mengekstrak audio kualitas terbaik (<code className="font-mono">audio-quality 0</code>) dan menanam ID3v2 tags (Cover Art, Title, Artist, Album, Year, Genre Music). Halaman iframe: <code className="font-bold text-black font-mono">/mp3/[idyoutube]</code>.
            </p>
          </div>

          {/* 3. M4A Command */}
          <div className="space-y-1.5 border-2 border-black p-3 bg-zinc-50">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Music className="w-4 h-4 text-black" />
                <span className="font-black text-black uppercase tracking-wide">
                  Konfigurasi yt-dlp Format M4A (AAC Stream + Tagging):
                </span>
              </div>
              <button
                type="button"
                onClick={copyM4a}
                className="inline-flex items-center gap-1 bg-white hover:bg-[#FFE500] border-2 border-black px-2 py-0.5 font-bold text-[11px] cursor-pointer"
              >
                {copiedM4a ? <Check className="w-3.5 h-3.5 text-green-700" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedM4a ? "Tersalin!" : "Salin Perintah M4A"}</span>
              </button>
            </div>

            <div className="bg-black text-[#FFE500] p-3 font-mono text-[11px] sm:text-xs overflow-x-auto border-2 border-black leading-relaxed whitespace-pre">
              <code>{m4aCommand}</code>
            </div>
            <p className="text-[11px] text-zinc-600 font-medium">
              * Mode M4A mengunduh stream AAC asli dengan penanaman cover art &amp; tags. Halaman iframe: <code className="font-bold text-black font-mono">/m4a/[idyoutube]</code>.
            </p>
          </div>

          {/* Breakdown Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="p-3 border-2 border-black bg-white space-y-2">
              <div className="flex items-center gap-1.5 font-black text-black uppercase">
                <Code className="w-4 h-4 text-black" />
                <span>Format Ringkasan &amp; Metadata</span>
              </div>
              <ul className="space-y-1 text-zinc-800">
                <li>
                  &bull; <strong>WebM:</strong> <span className="font-bold text-teal-700">Langsung tanpa metadata</span> (cepat &amp; stream murni).
                </li>
                <li>
                  &bull; <strong>MP3:</strong> Re-encode VBR 0 dengan tag ID3v2 &amp; cover art.
                </li>
                <li>
                  &bull; <strong>M4A:</strong> Kontainer AAC m4a dengan tag MP4 &amp; cover art.
                </li>
              </ul>
            </div>

            <div className="p-3 border-2 border-black bg-white space-y-2">
              <div className="flex items-center gap-1.5 font-black text-black uppercase">
                <ShieldCheck className="w-4 h-4 text-black" />
                <span>Mekanisme Cache 15 Menit</span>
              </div>
              <ul className="space-y-1 text-zinc-800">
                <li>
                  &bull; File WebM, MP3, dan M4A disimpan di cache lokal selama <strong>15 menit</strong>.
                </li>
                <li>
                  &bull; <strong>Reset Durasi:</strong> Mengunduh ulang link yang sama memperpanjang durasi kembali ke <strong>15 menit penuh</strong>.
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
