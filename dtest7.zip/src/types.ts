export interface TrackMetadata {
  id: string;
  title: string;
  artist: string;
  album: string;
  year: string;
  genre: string;
  coverArtUrl: string;
  duration?: number;
}

export type AudioFormat = "mp3" | "m4a" | "webm";

export interface CachedItem {
  videoId: string;
  format: AudioFormat;
  fileName: string;
  fileSize: number;
  metadata: TrackMetadata;
  cachedAt: number;
  expiresAt: number;
  remainingSeconds: number;
}

export interface CacheStatusResponse {
  ttlMinutes: number;
  totalItems: number;
  items: CachedItem[];
}

export interface CookiesStatus {
  exists: boolean;
  lineCount: number;
  hasNetscapeHeader: boolean;
  size: number;
  path: string;
}

export interface DownloadResponse {
  success: boolean;
  format: AudioFormat;
  cached?: boolean;
  renewed?: boolean;
  message: string;
  metadata: TrackMetadata;
  fileName: string;
  fileSize: number;
  downloadUrl: string;
  expiresAt: number;
  remainingSeconds: number;
}
