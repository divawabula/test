/**
 * AES-256-GCM Symmetric Encryption Utility for API Payloads.
 * Uses Web Crypto API (SubtleCrypto) for high performance and standard compatibility.
 */

export interface EncryptedPayload {
  _encrypted: true;
  alg: "AES-256-GCM";
  iv: string; // Base64 (12 bytes)
  data: string; // Base64 (ciphertext)
  tag: string; // Base64 (16 bytes auth tag)
  timestamp: number;
}

export const SHARED_AES_SECRET =
  (typeof import.meta !== "undefined" && import.meta.env?.VITE_API_AES_SECRET) ||
  "yt-dlp-aes-256-gcm-symmetric-key-secure";

let cachedCryptoKey: CryptoKey | null = null;

/**
 * Derives a 256-bit CryptoKey from the shared symmetric secret using SHA-256.
 */
export async function getSymmetricKey(): Promise<CryptoKey> {
  if (cachedCryptoKey) return cachedCryptoKey;

  const encoder = new TextEncoder();
  const secretBytes = encoder.encode(SHARED_AES_SECRET);
  const hashBuffer = await window.crypto.subtle.digest("SHA-256", secretBytes);

  cachedCryptoKey = await window.crypto.subtle.importKey(
    "raw",
    hashBuffer,
    { name: "AES-GCM" },
    false,
    ["encrypt", "decrypt"]
  );

  return cachedCryptoKey;
}

/**
 * Converts ArrayBuffer/Uint8Array to Base64.
 */
function bufferToBase64(buffer: ArrayBuffer | Uint8Array): string {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  let binary = "";
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

/**
 * Converts Base64 string to Uint8Array.
 */
function base64ToBuffer(base64: string): Uint8Array {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

/**
 * Encrypts arbitrary data (objects, arrays, strings) into an AES-256-GCM EncryptedPayload.
 */
export async function encryptPayload<T = any>(data: T): Promise<EncryptedPayload> {
  const key = await getSymmetricKey();
  const iv = window.crypto.getRandomValues(new Uint8Array(12)); // 12 bytes standard for GCM

  const jsonStr = JSON.stringify(data);
  const plainBytes = new TextEncoder().encode(jsonStr);

  // SubtleCrypto appends the 16-byte authentication tag at the end of the ciphertext
  const cipherBuffer = await window.crypto.subtle.encrypt(
    { name: "AES-GCM", iv: iv as unknown as BufferSource },
    key,
    plainBytes as unknown as BufferSource
  );

  const cipherBytes = new Uint8Array(cipherBuffer);
  const tagBytes = cipherBytes.slice(cipherBytes.length - 16);
  const dataBytes = cipherBytes.slice(0, cipherBytes.length - 16);

  return {
    _encrypted: true,
    alg: "AES-256-GCM",
    iv: bufferToBase64(iv),
    data: bufferToBase64(dataBytes),
    tag: bufferToBase64(tagBytes),
    timestamp: Date.now(),
  };
}

/**
 * Decrypts an AES-256-GCM EncryptedPayload back into the original data.
 */
export async function decryptPayload<T = any>(payload: EncryptedPayload): Promise<T> {
  const key = await getSymmetricKey();
  const iv = base64ToBuffer(payload.iv);
  const dataBytes = base64ToBuffer(payload.data);
  const tagBytes = base64ToBuffer(payload.tag);

  // Recombine data + tag for SubtleCrypto AES-GCM
  const combined = new Uint8Array(dataBytes.length + tagBytes.length);
  combined.set(dataBytes, 0);
  combined.set(tagBytes, dataBytes.length);

  const decryptedBuffer = await window.crypto.subtle.decrypt(
    { name: "AES-GCM", iv: iv as unknown as BufferSource },
    key,
    combined as unknown as BufferSource
  );

  const decryptedText = new TextDecoder().decode(decryptedBuffer);
  return JSON.parse(decryptedText) as T;
}

/**
 * Checks if a response or object is an AES-256 EncryptedPayload.
 */
export function isEncryptedPayload(obj: any): obj is EncryptedPayload {
  return Boolean(
    obj &&
      typeof obj === "object" &&
      obj._encrypted === true &&
      typeof obj.data === "string" &&
      typeof obj.iv === "string" &&
      typeof obj.tag === "string"
  );
}

/**
 * Secure fetch wrapper that:
 * 1. Encrypts request body with AES-256-GCM if provided as an object/JSON.
 * 2. Sets X-Encrypted-Payload header.
 * 3. Intercepts response: if response is AES-256 encrypted, transparently decrypts it.
 */
export async function secureFetch(url: string, options: RequestInit = {}): Promise<Response> {
  const headers = new Headers(options.headers || {});
  headers.set("X-Encrypted-Payload", "true");

  let body = options.body;
  if (body) {
    if (typeof body === "string") {
      try {
        const parsed = JSON.parse(body);
        const encrypted = await encryptPayload(parsed);
        body = JSON.stringify(encrypted);
        headers.set("Content-Type", "application/json");
      } catch {
        // Not a JSON string, leave as is
      }
    } else if (typeof body === "object" && !(body instanceof FormData) && !(body instanceof Blob)) {
      const encrypted = await encryptPayload(body);
      body = JSON.stringify(encrypted);
      headers.set("Content-Type", "application/json");
    }
  }

  const response = await fetch(url, {
    ...options,
    headers,
    body,
  });

  // Check if response is encrypted
  const isEncryptedHeader = response.headers.get("X-Encrypted-Payload") === "true";

  // Wrap response to intercept .json()
  const originalJson = response.json.bind(response);
  response.json = async () => {
    const rawData = await originalJson();
    if (isEncryptedPayload(rawData)) {
      return await decryptPayload(rawData);
    }
    return rawData;
  };

  return response;
}
