import React, { useState } from "react";
import { Copy, Check, ExternalLink, Code2, FileAudio, Music, Disc } from "lucide-react";
import { AudioFormat } from "../types";

export const IframeEmbedGenerator: React.FC = () => {
  const [videoId, setVideoId] = useState("NDLsmKPOPyE");
  const [format, setFormat] = useState<AudioFormat>("webm");
  const [theme, setTheme] = useState<"ytjar" | "neobrutalism">("ytjar");
  const [customColor, setCustomColor] = useState("");
  const [buttonText, setButtonText] = useState("");
  const [width, setWidth] = useState("300");
  const [height, setHeight] = useState("54");
  const [copied, setCopied] = useState(false);

  // Derive origin or fallback domain
  const origin = typeof window !== "undefined" ? window.location.origin : "https://namadomain.com";

  // Build query params
  const params = new URLSearchParams();
  if (theme === "neobrutalism") params.append("theme", "neobrutalism");
  if (customColor) params.append("color", customColor.replace("#", ""));
  if (buttonText) params.append("text", buttonText);

  const queryString = params.toString() ? `?${params.toString()}` : "";
  const iframeSrcRelative = `/${format}/${videoId || "NDLsmKPOPyE"}${queryString}`;
  const iframeSrcAbsolute = `${origin}${iframeSrcRelative}`;

  const iframeSnippet = `<iframe src="${iframeSrcAbsolute}" width="${width}" height="${height}" frameborder="0" scrolling="no" style="border:none;outline:none;overflow:hidden;"></iframe>`;

  const handleCopy = () => {
    navigator.clipboard.writeText(iframeSnippet);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePreset = (w: string, h: string) => {
    setWidth(w);
    setHeight(h);
  };

  return (
    <div className="w-full bg-white border-2 border-black p-4 sm:p-6 space-y-5">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b-2 border-black pb-3">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 bg-black text-white flex items-center justify-center font-bold">
            <Code2 className="w-4 h-4 text-[#FFE500]" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-base font-black uppercase tracking-tight text-black">
                Generator Page Iframe: namadomain.com/{format}/[idyoutube]
              </h2>
              <span className="bg-black text-[#FFE500] px-1.5 py-0.5 text-[10px] font-mono font-bold">
                WEBM &bull; MP3 &bull; M4A
              </span>
              <span className="bg-[#64c896] text-white border border-black px-1.5 py-0.2 text-[10px] font-bold">
                mp3api.ytjar Style
              </span>
              <span className="bg-[#FFE500] text-black border border-black px-1.5 py-0.5 text-[10px] font-black">
                Whitelist: anaku.web.id &amp; fomo.web.id
              </span>
            </div>
            <p className="text-xs text-zinc-600 font-medium mt-0.5">
              Sematkan tombol unduh audio langsung via <code className="bg-zinc-100 px-1 border border-black font-mono font-bold text-black">namadomain.com/webm/[idyoutube]</code> (direct audio tanpa metadata), <code className="bg-zinc-100 px-1 border border-black font-mono font-bold text-black">/mp3/[idyoutube]</code>, atau <code className="bg-zinc-100 px-1 border border-black font-mono font-bold text-black">/m4a/[idyoutube]</code>.
            </p>
          </div>
        </div>

        <a
          href={iframeSrcRelative}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#FFE500] hover:bg-[#ffd900] border-2 border-black text-xs font-black uppercase transition-colors cursor-pointer text-black"
        >
          <span>Buka Page /{format}/[id]</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </a>
      </div>

      {/* Format Selector: WebM, MP3, M4A */}
      <div className="bg-[#FAFAFA] border-2 border-black p-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="space-y-0.5">
          <span className="text-[10px] font-black uppercase text-zinc-500 tracking-wider">
            Pilih Halaman Iframe
          </span>
          <p className="text-xs font-bold text-black">
            Pilih endpoint halaman iframe yang ingin disematkan:
          </p>
        </div>

        <div className="grid grid-cols-3 gap-2 w-full sm:w-auto">
          {/* WebM Button */}
          <button
            type="button"
            onClick={() => setFormat("webm")}
            className={`px-3 py-2 border-2 border-black text-xs font-black uppercase flex items-center justify-center gap-1.5 cursor-pointer transition-colors ${
              format === "webm"
                ? "bg-black text-[#FFE500]"
                : "bg-white text-black hover:bg-zinc-100"
            }`}
          >
            <Disc className="w-3.5 h-3.5" />
            <span>/webm/[id]</span>
          </button>

          {/* MP3 Button */}
          <button
            type="button"
            onClick={() => setFormat("mp3")}
            className={`px-3 py-2 border-2 border-black text-xs font-black uppercase flex items-center justify-center gap-1.5 cursor-pointer transition-colors ${
              format === "mp3"
                ? "bg-black text-[#FFE500]"
                : "bg-white text-black hover:bg-zinc-100"
            }`}
          >
            <FileAudio className="w-3.5 h-3.5" />
            <span>/mp3/[id]</span>
          </button>

          {/* M4A Button */}
          <button
            type="button"
            onClick={() => setFormat("m4a")}
            className={`px-3 py-2 border-2 border-black text-xs font-black uppercase flex items-center justify-center gap-1.5 cursor-pointer transition-colors ${
              format === "m4a"
                ? "bg-black text-[#FFE500]"
                : "bg-white text-black hover:bg-zinc-100"
            }`}
          >
            <Music className="w-3.5 h-3.5" />
            <span>/m4a/[id]</span>
          </button>
        </div>
      </div>

      {/* Main Grid: Settings (Left) and Live Iframe Preview (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column: Configuration Controls */}
        <div className="lg:col-span-7 space-y-4">
          {/* YouTube ID / URL Input */}
          <div className="space-y-1">
            <label className="text-[11px] font-black uppercase tracking-wider text-black block">
              ID atau URL YouTube
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={videoId}
                onChange={(e) => setVideoId(e.target.value.trim())}
                placeholder="Contoh: NDLsmKPOPyE atau s9u7oQ7aaV0"
                className="w-full px-3 py-2 border-2 border-black bg-white text-xs sm:text-sm font-bold text-black focus:outline-none"
              />
              <button
                type="button"
                onClick={() => setVideoId("NDLsmKPOPyE")}
                className="px-2.5 py-2 bg-zinc-100 hover:bg-[#FFE500] border-2 border-black text-xs font-black whitespace-nowrap cursor-pointer transition-colors"
                title="Gunakan lagu contoh"
              >
                Contoh
              </button>
            </div>
            <div className="p-2 bg-zinc-100 border border-black font-mono text-[11px] flex flex-wrap items-center justify-between gap-1">
              <span>Endpoint: <strong className="text-black">/{format}/{videoId || "[idyoutube]"}</strong></span>
              <span className="text-zinc-500 font-sans text-[10px]">
                {format === "webm"
                  ? 'yt-dlp -f "bestaudio[ext=webm]" (Langsung No Tag)'
                  : format === "mp3"
                  ? "yt-dlp MP3 Quality 0 (Tagged)"
                  : "yt-dlp AAC M4A (Tagged)"}
              </span>
            </div>
          </div>

          {/* Theme & Style Selector */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="text-[11px] font-black uppercase tracking-wider text-black block">
                Tema Desain
              </label>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setTheme("ytjar")}
                  className={`flex-1 py-2 px-2 border-2 border-black text-xs font-black uppercase transition-colors flex items-center justify-center gap-1.5 cursor-pointer ${
                    theme === "ytjar"
                      ? format === "webm"
                        ? "bg-[#0D9488] text-white"
                        : format === "mp3"
                        ? "bg-[#2563EB] text-white"
                        : "bg-[#64c896] text-white"
                      : "bg-white text-black hover:bg-zinc-100"
                  }`}
                >
                  <span className={`w-2.5 h-2.5 ${format === "webm" ? "bg-[#0D9488]" : format === "mp3" ? "bg-[#2563EB]" : "bg-[#64c896]"} border border-white inline-block`}></span>
                  <span>YTJar ({format === "webm" ? "#0D9488" : format === "mp3" ? "#2563EB" : "#64c896"})</span>
                </button>
                <button
                  type="button"
                  onClick={() => setTheme("neobrutalism")}
                  className={`flex-1 py-2 px-2 border-2 border-black text-xs font-black uppercase transition-colors flex items-center justify-center gap-1.5 cursor-pointer ${
                    theme === "neobrutalism" ? "bg-[#FFE500] text-black" : "bg-white text-black hover:bg-zinc-100"
                  }`}
                >
                  <span className="w-2.5 h-2.5 bg-[#FFE500] border border-black inline-block"></span>
                  <span>Neobrutalism</span>
                </button>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-black uppercase tracking-wider text-black block">
                Custom Teks Tombol (Opsional)
              </label>
              <input
                type="text"
                value={buttonText}
                onChange={(e) => setButtonText(e.target.value)}
                placeholder={
                  format === "webm"
                    ? "Download WebM"
                    : format === "mp3"
                    ? "Download MP3"
                    : "Download M4A"
                }
                className="w-full px-3 py-2 border-2 border-black bg-white text-xs font-bold text-black focus:outline-none"
              />
            </div>
          </div>

          {/* Size Dimension Controls */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-[11px] font-black uppercase tracking-wider text-black block">
                Dimensi Iframe
              </label>
              <div className="flex items-center gap-1.5 text-[11px] font-bold">
                <span className="text-zinc-500">Preset:</span>
                <button
                  type="button"
                  onClick={() => handlePreset("260", "48")}
                  className="px-1.5 py-0.5 border border-black hover:bg-zinc-200 cursor-pointer text-[10px]"
                >
                  260x48
                </button>
                <button
                  type="button"
                  onClick={() => handlePreset("300", "56")}
                  className="px-1.5 py-0.5 border border-black bg-black text-white cursor-pointer text-[10px]"
                >
                  300x56
                </button>
                <button
                  type="button"
                  onClick={() => handlePreset("100%", "54")}
                  className="px-1.5 py-0.5 border border-black hover:bg-zinc-200 cursor-pointer text-[10px]"
                >
                  100%
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div className="flex items-center gap-2 border-2 border-black px-2 py-1 bg-white">
                <span className="text-[10px] font-bold text-zinc-500 uppercase">Lebar:</span>
                <input
                  type="text"
                  value={width}
                  onChange={(e) => setWidth(e.target.value)}
                  className="w-full text-xs font-mono font-bold focus:outline-none"
                />
              </div>
              <div className="flex items-center gap-2 border-2 border-black px-2 py-1 bg-white">
                <span className="text-[10px] font-bold text-zinc-500 uppercase">Tinggi:</span>
                <input
                  type="text"
                  value={height}
                  onChange={(e) => setHeight(e.target.value)}
                  className="w-full text-xs font-mono font-bold focus:outline-none"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Live Iframe Preview */}
        <div className="lg:col-span-5 flex flex-col justify-between border-2 border-black bg-[#fafafa] p-4 space-y-3">
          <div>
            <div className="flex items-center justify-between pb-2 border-b border-zinc-300">
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] font-black uppercase text-black">
                  Live Preview: /{format}/[id]
                </span>
              </div>
              <span className="text-[10px] font-mono text-zinc-500">
                {width} x {height}
              </span>
            </div>

            {/* The Actual Rendered Iframe */}
            <div className="py-4 flex items-center justify-center min-h-[90px] bg-white border border-dashed border-zinc-300 overflow-hidden my-2">
              <iframe
                key={`${format}-${videoId}-${theme}-${buttonText}`}
                src={iframeSrcRelative}
                width={width}
                height={height}
                frameBorder="0"
                scrolling="no"
                title={`Preview Download ${format.toUpperCase()}`}
                className="max-w-full outline-none border-0"
                style={{ border: "none", outline: "none", overflow: "hidden" }}
              />
            </div>

            <p className="text-[10px] text-zinc-600 text-center font-medium">
              * Tombol di atas adalah iframe aktif halaman <code className="font-bold">/{format}/{videoId}</code>.
            </p>
          </div>

          {/* Quick Copy Snippet */}
          <div className="space-y-2 pt-2 border-t border-zinc-300">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-black uppercase text-black">
                Kode Embed Iframe ({format.toUpperCase()})
              </span>
              <button
                type="button"
                onClick={handleCopy}
                className="inline-flex items-center gap-1 px-2 py-1 bg-[#FFE500] hover:bg-[#edd100] border border-black text-[10px] font-black uppercase cursor-pointer transition-colors"
              >
                {copied ? <Check className="w-3 h-3 text-green-700" /> : <Copy className="w-3 h-3" />}
                <span>{copied ? "Tersalin!" : "Salin Kode"}</span>
              </button>
            </div>

            <div className="p-2 bg-black text-[#CCFF00] font-mono text-[10px] leading-tight break-all border border-black select-all">
              {iframeSnippet}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
