import React, { useState, useEffect } from "react";
import { X, Check, AlertCircle, Save, Upload, Info } from "lucide-react";
import { CookiesStatus } from "../types";
import { secureFetch } from "../utils/crypto";

interface CookiesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaved: () => void;
}

export const CookiesModal: React.FC<CookiesModalProps> = ({
  isOpen,
  onClose,
  onSaved,
}) => {
  const [content, setContent] = useState("");
  const [status, setStatus] = useState<CookiesStatus | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<{ text: string; type: "success" | "error" } | null>(null);

  useEffect(() => {
    if (isOpen) {
      fetchStatus();
    }
  }, [isOpen]);

  const fetchStatus = async () => {
    setLoading(true);
    try {
      const res = await secureFetch("/api/cookies");
      const data = await res.json();
      setStatus(data);
    } catch (e) {
      console.error("Gagal memeriksa cookies:", e);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    if (!content.trim()) {
      setMsg({ text: "Konten cookies tidak boleh kosong", type: "error" });
      return;
    }
    setSaving(true);
    setMsg(null);
    try {
      const res = await secureFetch("/api/cookies", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ cookiesContent: content }),
      });
      const data = await res.json();
      if (res.ok) {
        setMsg({ text: "cookies.txt berhasil disimpan!", type: "success" });
        fetchStatus();
        onSaved();
      } else {
        setMsg({ text: data.error || "Gagal menyimpan cookies", type: "error" });
      }
    } catch (e: any) {
      setMsg({ text: e.message || "Error saat menghubungi server", type: "error" });
    } finally {
      setSaving(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        setContent(text);
      }
    };
    reader.readAsText(file);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
      <div className="w-full max-w-xl bg-white border-2 border-black max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="bg-[#FFE500] border-b-2 border-black px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-black text-black uppercase tracking-tight text-base">
              Pengaturan cookies.txt
            </span>
            <span className="bg-black text-white text-[10px] font-bold px-1.5 py-0.5">
              yt-dlp
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center bg-white hover:bg-black hover:text-white border-2 border-black font-bold transition-colors cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-4">
          {/* Status info */}
          <div className="p-3 border-2 border-black bg-[#fafafa] space-y-1 text-xs">
            <div className="flex items-center justify-between font-bold">
              <span>Status File cookies.txt:</span>
              <span
                className={`px-2 py-0.5 border border-black ${
                  status?.lineCount && status.lineCount > 0
                    ? "bg-[#CCFF00] text-black"
                    : "bg-[#FF5555] text-white"
                }`}
              >
                {status?.lineCount && status.lineCount > 0
                  ? `${status.lineCount} entri cookies aktif`
                  : "Belum ada entri cookies"}
              </span>
            </div>
            <p className="text-zinc-600">
              Lokasi: <code className="bg-zinc-200 px-1 font-mono">{status?.path || "cookies.txt"}</code>
            </p>
          </div>

          {/* Tutorial Banner */}
          <div className="border-2 border-black bg-[#E6F4FE] p-3 text-xs space-y-1.5">
            <div className="flex items-center gap-1.5 font-bold text-black">
              <Info className="w-4 h-4 text-blue-600" />
              <span>Mengapa YouTube Memerlukan cookies.txt?</span>
            </div>
            <p className="text-zinc-800 leading-relaxed">
              YouTube Music sering memblokir unduhan server dengan pesan <em>"Sign in to confirm you're not a bot"</em>. Mengisi file <code className="font-mono bg-white px-1 border border-black">cookies.txt</code> memverifikasi sesi resmi Anda ke yt-dlp.
            </p>
            <div className="text-[11px] text-zinc-700 pt-1 space-y-0.5">
              <p className="font-semibold">Cara mudah mendapatkan cookies.txt:</p>
              <ol className="list-decimal pl-4 space-y-0.5">
                <li>Buka Chrome/Firefox dan pasang ekstensi <strong>"Get cookies.txt LOCALLY"</strong>.</li>
                <li>Buka situs <a href="https://music.youtube.com" target="_blank" rel="noreferrer" className="underline font-bold">music.youtube.com</a> dalam kondisi sudah login.</li>
                <li>Klik ikon ekstensi lalu klik <strong>Export</strong> atau salin teksnya ke sini.</li>
              </ol>
            </div>
          </div>

          {/* Upload & Textarea */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-black uppercase tracking-wider">
                Tempel Isi File cookies.txt (Format Netscape)
              </label>
              <label className="cursor-pointer inline-flex items-center gap-1 bg-white hover:bg-zinc-100 text-black border-2 border-black px-2 py-1 text-xs font-bold">
                <Upload className="w-3.5 h-3.5" />
                <span>Upload File</span>
                <input
                  type="file"
                  accept=".txt"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </label>
            </div>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="# Netscape HTTP Cookie File&#10;.youtube.com	TRUE	/	TRUE	1774390000	LOGIN_INFO	..."
              rows={8}
              className="w-full p-2.5 font-mono text-xs border-2 border-black bg-white resize-y"
            />
          </div>

          {msg && (
            <div
              className={`p-2.5 border-2 border-black flex items-center gap-2 text-xs font-bold ${
                msg.type === "success"
                  ? "bg-[#CCFF00] text-black"
                  : "bg-[#FF5555] text-white"
              }`}
            >
              {msg.type === "success" ? (
                <Check className="w-4 h-4" />
              ) : (
                <AlertCircle className="w-4 h-4" />
              )}
              <span>{msg.text}</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="bg-[#fafafa] border-t-2 border-black p-3 sm:p-4 flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-white hover:bg-zinc-200 border-2 border-black text-xs font-bold uppercase cursor-pointer"
          >
            Tutup
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={saving}
            className="px-4 py-2 bg-[#FFE500] hover:bg-[#ebd300] border-2 border-black text-xs font-black uppercase flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? "Menyimpan..." : "Simpan cookies.txt"}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
