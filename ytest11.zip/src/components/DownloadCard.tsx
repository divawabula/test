import { useState } from "react";
import { X, FileAudio, AlertTriangle } from "lucide-react";
import { Song } from "../types";

interface DownloadCardProps {
  song: Song;
  onClose: () => void;
  initialFormat?: string;
}

type AudioFormat = "m4a" | "webm" | "mp3";
type M4aServer = "server1" | "server2";
type Mp3Server = "server1" | "server2" | "server3";
type WebmServer = "server1" | "server2";

export default function DownloadCard({ song, onClose, initialFormat = "m4a" }: DownloadCardProps) {
  const [format, setFormat] = useState<AudioFormat>(
    initialFormat === "webm" ? "webm" : initialFormat === "mp3" ? "mp3" : "m4a"
  );
  const [m4aServer, setM4aServer] = useState<M4aServer>("server1");
  const [mp3Server, setMp3Server] = useState<Mp3Server>("server1");
  const [webmServer, setWebmServer] = useState<WebmServer>("server1");

  return (
    <div
      id={`download-card-${song.id}`}
      onClick={(e) => e.stopPropagation()}
      className="mt-1.5 p-3.5 sm:p-4 bg-white border-2 border-black animate-in fade-in slide-in-from-top-2 duration-150 relative"
    >
      {/* Card Header with Format Selector and Close Button */}
      <div className="flex items-center justify-between gap-3 mb-2.5 flex-wrap">
        <div className="flex items-center gap-2 flex-wrap">
          {/* Format Tabs: M4A, WEBM, and MP3 in requested order */}
          <div className="inline-flex items-center p-0.5 border-2 border-black bg-neutral-100">
            <button
              type="button"
              id={`format-m4a-btn-${song.id}`}
              onClick={() => setFormat("m4a")}
              className={`px-3 py-1 text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${
                format === "m4a"
                  ? "bg-[#FFE600] text-black border border-black"
                  : "bg-transparent text-neutral-600 hover:text-black"
              }`}
            >
              <FileAudio className="w-3.5 h-3.5" />
              <span>M4A</span>
            </button>
            <button
              type="button"
              id={`format-webm-btn-${song.id}`}
              onClick={() => setFormat("webm")}
              className={`px-3 py-1 text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${
                format === "webm"
                  ? "bg-[#FFE600] text-black border border-black"
                  : "bg-transparent text-neutral-600 hover:text-black"
              }`}
            >
              <FileAudio className="w-3.5 h-3.5" />
              <span>WEBM</span>
            </button>
            <button
              type="button"
              id={`format-mp3-btn-${song.id}`}
              onClick={() => setFormat("mp3")}
              className={`px-3 py-1 text-xs font-black transition-all cursor-pointer flex items-center gap-1.5 ${
                format === "mp3"
                  ? "bg-[#FFE600] text-black border border-black"
                  : "bg-transparent text-neutral-600 hover:text-black"
              }`}
            >
              <FileAudio className="w-3.5 h-3.5" />
              <span>MP3</span>
            </button>
          </div>

          <span className="text-[11px] font-black uppercase tracking-wider text-neutral-500">
            Download {format.toUpperCase()}
          </span>
        </div>

        {/* Close Button */}
        <button
          onClick={onClose}
          className="p-1 border border-black bg-white hover:bg-black hover:text-white transition-colors cursor-pointer text-xs ml-auto"
          aria-label="Close download panel"
          title="Close"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Song details inside card */}
      <div className="mb-3">
        <h4 className="text-xs sm:text-sm font-black text-black truncate" title={song.title}>
          {song.title}
        </h4>
        <p className="text-[11px] sm:text-xs font-bold text-neutral-600 truncate">
          {song.artist_name} {song.album?.name ? `• ${song.album.name}` : ""}
        </p>
      </div>

      {/* M4A Format Section */}
      {format === "m4a" && (
        <div id={`m4a-section-${song.id}`} className="pt-2 border-t border-neutral-200">
          {/* Server Selector for M4A */}
          <div className="flex items-center justify-between gap-2 mb-2 flex-wrap">
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-black uppercase text-neutral-700">Server:</span>
              <div className="inline-flex items-center p-0.5 border-2 border-black bg-neutral-100">
                <button
                  type="button"
                  id={`m4a-server1-btn-${song.id}`}
                  onClick={() => setM4aServer("server1")}
                  className={`px-2.5 py-0.5 text-xs font-black transition-all cursor-pointer ${
                    m4aServer === "server1"
                      ? "bg-[#FFE600] text-black border border-black"
                      : "bg-transparent text-neutral-600 hover:text-black"
                  }`}
                >
                  Server 1
                </button>
                <button
                  type="button"
                  id={`m4a-server2-btn-${song.id}`}
                  onClick={() => setM4aServer("server2")}
                  className={`px-2.5 py-0.5 text-xs font-black transition-all cursor-pointer ${
                    m4aServer === "server2"
                      ? "bg-[#FFE600] text-black border border-black"
                      : "bg-transparent text-neutral-600 hover:text-black"
                  }`}
                >
                  Server 2
                </button>
              </div>
            </div>
            <span className="text-[10px] font-bold text-neutral-400">
              {m4aServer === "server1" ? "dl1.anaku.web.id" : "dl.anaku.web.id"}
            </span>
          </div>

          {/* Iframe Container for M4A */}
          <div className="w-full overflow-hidden border-2 border-black bg-white">
            {m4aServer === "server1" && (
              <iframe
                id={`m4a-iframe-server1-${song.id}`}
                src={`https://dl1.anaku.web.id/m4a/${song.id}?theme=neobrutalism`}
                title={`Download M4A Server 1 - ${song.title}`}
                width="100%"
                height="54"
                scrolling="no"
                style={{ border: "none", outline: "none", overflow: "hidden", width: "100%", height: "54px" }}
                className="w-full h-[54px] border-0 block overflow-hidden"
                loading="lazy"
              />
            )}
            {m4aServer === "server2" && (
              <iframe
                id={`m4a-iframe-server2-${song.id}`}
                src={`https://dl.anaku.web.id/m4a/${song.id}`}
                title={`Download M4A Server 2 - ${song.title}`}
                width="100%"
                height="54"
                scrolling="no"
                style={{ border: "none", outline: "none", overflow: "hidden", width: "100%", height: "54px" }}
                className="w-full h-[54px] border-0 block overflow-hidden"
                loading="lazy"
              />
            )}
          </div>
        </div>
      )}

      {/* WEBM Format Section */}
      {format === "webm" && (
        <div id={`webm-section-${song.id}`} className="pt-2 border-t border-neutral-200">
          {/* Server Selector for WEBM */}
          <div className="flex items-center justify-between gap-2 mb-2 flex-wrap">
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-black uppercase text-neutral-700">Server:</span>
              <div className="inline-flex items-center p-0.5 border-2 border-black bg-neutral-100">
                <button
                  type="button"
                  id={`webm-server1-btn-${song.id}`}
                  onClick={() => setWebmServer("server1")}
                  className={`px-2.5 py-0.5 text-xs font-black transition-all cursor-pointer ${
                    webmServer === "server1"
                      ? "bg-[#FFE600] text-black border border-black"
                      : "bg-transparent text-neutral-600 hover:text-black"
                  }`}
                >
                  Server 1
                </button>
                <button
                  type="button"
                  id={`webm-server2-btn-${song.id}`}
                  onClick={() => setWebmServer("server2")}
                  className={`px-2.5 py-0.5 text-xs font-black transition-all cursor-pointer ${
                    webmServer === "server2"
                      ? "bg-[#FFE600] text-black border border-black"
                      : "bg-transparent text-neutral-600 hover:text-black"
                  }`}
                >
                  Server 2
                </button>
              </div>
            </div>
            <span className="text-[10px] font-bold text-neutral-400">
              pc4.anaku.web.id
            </span>
          </div>

          {/* Iframe Container for WEBM */}
          <div className="w-full overflow-hidden border-2 border-black bg-white">
            {webmServer === "server1" && (
              <iframe
                id={`webm-iframe-server1-${song.id}`}
                src={`https://dl1.anaku.web.id/webm/${song.id}?theme=neobrutalism`}
                title={`Download WebM Server 1 - ${song.title}`}
                width="100%"
                height="54"
                scrolling="no"
                style={{ border: "none", outline: "none", overflow: "hidden", width: "100%", height: "54px" }}
                className="w-full h-[54px] border-0 block overflow-hidden"
                loading="lazy"
              />
            )}
            {webmServer === "server2" && (
              <iframe
                id={`webm-iframe-server2-${song.id}`}
                src={`https://dl.anaku.web.id/webm/${song.id}`}
                title={`Download WebM Server 2 - ${song.title}`}
                width="100%"
                height="54"
                scrolling="no"
                style={{ border: "none", outline: "none", overflow: "hidden", width: "100%", height: "54px" }}
                className="w-full h-[54px] border-0 block overflow-hidden"
                loading="lazy"
              />
            )}
          </div>
        </div>
      )}

      {/* MP3 Format Section */}
      {format === "mp3" && (
        <div id={`mp3-section-${song.id}`} className="pt-2 border-t border-neutral-200">
          {/* Quality Notice Warning Banner */}
          <div className="flex items-start gap-2.5 p-2.5 mb-2.5 bg-[#FFF9D2] border-2 border-black text-xs">
            <AlertTriangle className="w-4 h-4 text-black flex-shrink-0 mt-0.5" />
            <div className="leading-snug text-neutral-800">
              <strong className="font-black uppercase text-black block mb-0.5 tracking-wide">
                Notice: M4A or WebM is Recommended
              </strong>
              <span>
                <strong>M4A</strong> or <strong>WebM</strong> is better and highly recommended because it is sourced directly from YouTube Music without re-encoding quality loss. MP3 requires conversion which may take longer and slightly reduce fidelity.
              </span>
            </div>
          </div>

          {/* Server Selector for MP3 */}
          <div className="flex items-center justify-between gap-2 mb-2 flex-wrap">
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-black uppercase text-neutral-700">Server:</span>
              <div className="inline-flex items-center p-0.5 border-2 border-black bg-neutral-100">
                <button
                  type="button"
                  id={`mp3-server1-btn-${song.id}`}
                  onClick={() => setMp3Server("server1")}
                  className={`px-2.5 py-0.5 text-xs font-black transition-all cursor-pointer ${
                    mp3Server === "server1"
                      ? "bg-[#FFE600] text-black border border-black"
                      : "bg-transparent text-neutral-600 hover:text-black"
                  }`}
                >
                  Server 1
                </button>
                <button
                  type="button"
                  id={`mp3-server2-btn-${song.id}`}
                  onClick={() => setMp3Server("server2")}
                  className={`px-2.5 py-0.5 text-xs font-black transition-all cursor-pointer ${
                    mp3Server === "server2"
                      ? "bg-[#FFE600] text-black border border-black"
                      : "bg-transparent text-neutral-600 hover:text-black"
                  }`}
                >
                  Server 2
                </button>
                <button
                  type="button"
                  id={`mp3-server3-btn-${song.id}`}
                  onClick={() => setMp3Server("server3")}
                  className={`px-2.5 py-0.5 text-xs font-black transition-all cursor-pointer ${
                    mp3Server === "server3"
                      ? "bg-[#FFE600] text-black border border-black"
                      : "bg-transparent text-neutral-600 hover:text-black"
                  }`}
                >
                  Server 3
                </button>
              </div>
            </div>
            <span className="text-[10px] font-bold text-neutral-400">
              {mp3Server === "server1"
                ? "ytjar.info"
                : mp3Server === "server2"
                ? "y2jar.cc"
                : "dl.anaku.web.id"}
            </span>
          </div>

          {/* Iframe Container for MP3 */}
          <div className="w-full overflow-hidden border-2 border-black bg-white">
            {mp3Server === "server1" && (
              <iframe
                id={`mp3-iframe-server1-${song.id}`}
                src={`https://mp3api.ytjar.info/?id=${song.id}`}
                title={`Download MP3 Server 2 - ${song.title}`}
                sandbox="allow-scripts allow-same-origin allow-forms allow-downloads"
                style={{ width: "100%", height: "50px" }}
                className="w-full h-[54px] border-0 block"
                loading="lazy"
              />
            )}
            {mp3Server === "server2" && (
              <iframe
                id={`mp3-iframe-server2-${song.id}`}
                src={`https://v2.y2jar.cc/?id=${song.id}`}
                title={`Download MP3 Server 3 - ${song.title}`}
                sandbox="allow-scripts allow-same-origin allow-forms allow-downloads"
                style={{ width: "100%", height: "700px" }}
                className="w-full h-[700px] border-0 block"
                loading="lazy"
              />
            )}
            {mp3Server === "server3" && (
              <iframe
                id={`mp3-iframe-server3-${song.id}`}
                src={`https://dl.anaku.web.id/mp3/${song.id}`}
                title={`Download MP3 Server 1 - ${song.title}`}
                width="100%"
                height="54"
                scrolling="no"
                style={{ border: "none", overflow: "hidden", width: "100%", height: "54px" }}
                className="w-full h-[54px] border-0 block overflow-hidden"
                loading="lazy"
              />
              
            )}
          </div>
        </div>
      )}
    </div>
  );
}
