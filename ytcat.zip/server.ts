import express, { Request, Response, NextFunction } from "express";
import path from "path";
import fs from "fs";
import compression from "compression";
import { createServer as createViteServer } from "vite";
import {
  getHomeTopSongs,
  searchSongs,
  getSearchSuggestions,
  getArtistDetails,
  getSongDetails,
  slugify,
  warmupYtMusic,
} from "./server/ytmusic";
import { resolvePageMeta, injectMetaIntoHtml } from "./server/seoRenderer";
import {
  encryptPayload,
  decryptPayload,
  isEncryptedPayload,
} from "./server/crypto";
import { fetchSongLyrics } from "./server/lyrics";
import {
  translateLyrics,
  romanizeTexts,
  analyzeScript,
} from "./server/translation";

const app = express();
const PORT = 3000;

// Enable response compression (gzip / deflate / brotli)
app.use(
  compression({
    level: 6,
    threshold: 1024, // only compress responses above 1KB
  })
);

app.use(express.json());

// Symmetric AES-256-GCM Encryption Middleware for API Payloads
app.use("/api", (req: Request, res: Response, next: NextFunction) => {
  // 1. Transparently decrypt incoming encrypted request payload if present
  if (isEncryptedPayload(req.body)) {
    try {
      req.body = decryptPayload(req.body);
    } catch (err: any) {
      console.warn("Failed to decrypt incoming API request body:", err.message);
      return res.status(400).json({ success: false, error: "Malformed or invalid encrypted request body" });
    }
  }

  // 2. Intercept res.json to automatically encrypt outgoing payloads with AES-256-GCM
  const originalJson = res.json.bind(res);
  res.json = (body: any) => {
    // Allow raw payload if requested via header or query parameter for testing/debugging
    if (req.headers["x-raw-payload"] === "true" || req.query.raw === "true") {
      return originalJson(body);
    }

    if (!body || isEncryptedPayload(body)) {
      return originalJson(body);
    }

    try {
      const encrypted = encryptPayload(body);
      res.setHeader("X-Payload-Encryption", "AES-256-GCM");
      return originalJson(encrypted);
    } catch (err: any) {
      console.error("AES-256-GCM Encryption error:", err);
      return originalJson(body);
    }
  };

  next();
});

// SEO & Security Headers
app.use((req: Request, res: Response, next: NextFunction) => {
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
  next();
});

// API Health
app.get("/api/health", (req: Request, res: Response) => {
  res.setHeader("Cache-Control", "no-store");
  res.json({
    node: "ok",
    service: "ytmusic-native",
    uptime: process.uptime(),
  });
});

// API: Home Top Songs (25 official songs) - High cacheability
app.get("/api/home", async (req: Request, res: Response) => {
  try {
    const songs = await getHomeTopSongs();
    // Cache in browser for 5 mins, stale-while-revalidate for 15 mins
    res.setHeader(
      "Cache-Control",
      "public, max-age=300, stale-while-revalidate=900"
    );
    res.json({
      success: true,
      data: songs,
      total: songs.length,
    });
  } catch (error: any) {
    console.error("Error in /api/home:", error);
    res.status(500).json({
      success: false,
      error: "Failed to fetch top songs",
      detail: error.message || "Unknown error",
    });
  }
});

// API: Search Songs
app.get("/api/search", async (req: Request, res: Response) => {
  const query = typeof req.query.q === "string" ? req.query.q : "";
  if (!query.trim()) {
    return res.status(400).json({ success: false, error: "Query parameter 'q' is required" });
  }

  try {
    const songs = await searchSongs(query);
    // Search query results cached for 3 mins, SWR for 10 mins
    res.setHeader(
      "Cache-Control",
      "public, max-age=180, stale-while-revalidate=600"
    );
    res.json({
      success: true,
      data: songs,
      query,
      total: songs.length,
    });
  } catch (error: any) {
    console.error(`Error in /api/search for '${query}':`, error);
    res.status(500).json({
      success: false,
      error: "Search failed",
      detail: error.message || "Unknown error",
    });
  }
});

// API: Search Suggestions (Autocomplete)
app.get("/api/suggestions", async (req: Request, res: Response) => {
  const query = typeof req.query.q === "string" ? req.query.q : "";
  if (!query.trim()) {
    return res.json({
      success: true,
      data: { queries: [], songs: [] },
      query: "",
    });
  }

  try {
    const suggestions = await getSearchSuggestions(query);
    res.setHeader(
      "Cache-Control",
      "public, max-age=300, stale-while-revalidate=900"
    );
    res.json({
      success: true,
      data: suggestions,
      query,
    });
  } catch (error: any) {
    console.error(`Error in /api/suggestions for '${query}':`, error);
    res.json({
      success: true,
      data: { queries: [], songs: [] },
      query,
    });
  }
});

// API: Artist Detail & Complete Songs Catalog
app.get("/api/artist/:idOrName", async (req: Request, res: Response) => {
  const { idOrName } = req.params;
  if (!idOrName || !idOrName.trim()) {
    return res.status(400).json({ success: false, error: "Parameter 'idOrName' is required" });
  }

  try {
    const artist = await getArtistDetails(idOrName);
    if (!artist) {
      return res.status(404).json({
        success: false,
        error: "Artist not found",
      });
    }

    // High performance caching: Browser caches for 10 minutes, SWR for 1 hour
    res.setHeader(
      "Cache-Control",
      "public, max-age=600, stale-while-revalidate=3600"
    );
    res.json({
      success: true,
      data: artist,
    });
  } catch (error: any) {
    console.error(`Error in /api/artist for '${idOrName}':`, error);
    res.status(500).json({
      success: false,
      error: "Failed to load artist details",
      detail: error.message || "Unknown error",
    });
  }
});

// API: Single Song Details for Direct Track & SEO resolution
app.get("/api/song/:id", async (req: Request, res: Response) => {
  const { id } = req.params;
  if (!id || !id.trim()) {
    return res.status(400).json({ success: false, error: "Parameter 'id' is required" });
  }

  try {
    const song = await getSongDetails(id);
    if (!song) {
      return res.status(404).json({
        success: false,
        error: "Song not found",
      });
    }

    res.setHeader(
      "Cache-Control",
      "public, max-age=1800, stale-while-revalidate=86400"
    );
    res.json({
      success: true,
      data: song,
    });
  } catch (error: any) {
    console.error(`Error in /api/song for '${id}':`, error);
    res.status(500).json({
      success: false,
      error: "Failed to load song details",
      detail: error.message || "Unknown error",
    });
  }
});

// API: Song Lyrics & Karaoke Synchronized Lines
app.get("/api/lyrics/:id", async (req: Request, res: Response) => {
  const { id } = req.params;
  const track = typeof req.query.track === "string" ? req.query.track : undefined;
  const artist = typeof req.query.artist === "string" ? req.query.artist : undefined;
  const duration = typeof req.query.duration === "string" ? parseFloat(req.query.duration) : undefined;

  if (!id || !id.trim()) {
    return res.status(400).json({ success: false, error: "Parameter 'id' is required" });
  }

  try {
    const lyrics = await fetchSongLyrics(id, track, artist, duration);
    if (!lyrics) {
      return res.status(404).json({
        success: false,
        error: "Lyrics not available for this song",
      });
    }

    res.setHeader(
      "Cache-Control",
      "public, max-age=3600, stale-while-revalidate=86400"
    );
    res.json({
      success: true,
      data: lyrics,
    });
  } catch (error: any) {
    console.error(`Error in /api/lyrics for '${id}':`, error);
    res.status(500).json({
      success: false,
      error: "Failed to fetch lyrics",
      detail: error.message || "Unknown error",
    });
  }
});

// API: Translate Song Lyrics using Google Translate + Romanization/Cara Baca
app.post("/api/lyrics/translate", async (req: Request, res: Response) => {
  try {
    const { songId, targetLang = "id", lines = [], plainText } = req.body || {};

    if (!targetLang || targetLang === "none") {
      return res.json({
        success: true,
        data: {
          translations: Array.isArray(lines) ? lines.map(() => "") : [],
          romanizations: [],
          sourceLanguage: "auto",
          targetLanguage: "none",
        },
      });
    }

    let textsToTranslate: string[] = [];
    if (Array.isArray(lines) && lines.length > 0) {
      textsToTranslate = lines.map((l: any) => (typeof l === "string" ? l : l.text || ""));
    } else if (typeof plainText === "string" && plainText.trim()) {
      textsToTranslate = plainText.split("\n");
    } else if (songId) {
      const lyrics = await fetchSongLyrics(songId);
      if (lyrics) {
        textsToTranslate = lyrics.lines.length > 0
          ? lyrics.lines.map((l) => l.text)
          : (lyrics.plainLyrics?.split("\n") || []);
      }
    }

    if (textsToTranslate.length === 0) {
      return res.status(400).json({
        success: false,
        error: "No texts or lyrics provided to translate",
      });
    }

    const analysis = analyzeScript(textsToTranslate);
    const [translationRes, romanizations] = await Promise.all([
      translateLyrics(textsToTranslate, targetLang),
      analysis.hasRomanization
        ? romanizeTexts(textsToTranslate, analysis)
        : Promise.resolve(textsToTranslate.map(() => "")),
    ]);

    // Cache translated results in browser
    res.setHeader("Cache-Control", "public, max-age=7200, stale-while-revalidate=86400");
    res.json({
      success: true,
      data: {
        translations: translationRes.translations,
        romanizations,
        sourceLanguage: translationRes.sourceLanguage || analysis.detectedLang,
        targetLanguage: targetLang,
        hasRomanization: analysis.hasRomanization,
        romanizationType: analysis.romanizationType,
        scriptLabel: analysis.scriptLabel,
      },
    });
  } catch (err: any) {
    console.error("Error in /api/lyrics/translate:", err);
    res.status(500).json({
      success: false,
      error: "Translation failed",
      detail: err.message || "Unknown error",
    });
  }
});

// GET convenience endpoint for /api/lyrics/:id/translate
app.get("/api/lyrics/:id/translate", async (req: Request, res: Response) => {
  const { id } = req.params;
  const targetLang = typeof req.query.target === "string" ? req.query.target : "id";

  if (!id) {
    return res.status(400).json({ success: false, error: "Song ID is required" });
  }

  try {
    const lyrics = await fetchSongLyrics(id);
    if (!lyrics) {
      return res.status(404).json({ success: false, error: "Lyrics not found for this song" });
    }

    const texts = lyrics.lines.length > 0
      ? lyrics.lines.map((l) => l.text)
      : (lyrics.plainLyrics?.split("\n") || []);

    const analysis = analyzeScript(texts);
    const [translationRes, romanizations] = await Promise.all([
      translateLyrics(texts, targetLang),
      analysis.hasRomanization
        ? romanizeTexts(texts, analysis)
        : Promise.resolve(texts.map(() => "")),
    ]);

    res.setHeader("Cache-Control", "public, max-age=7200, stale-while-revalidate=86400");
    res.json({
      success: true,
      data: {
        translations: translationRes.translations,
        romanizations,
        sourceLanguage: translationRes.sourceLanguage || analysis.detectedLang,
        targetLanguage: targetLang,
        hasRomanization: analysis.hasRomanization,
        romanizationType: analysis.romanizationType,
        scriptLabel: analysis.scriptLabel,
      },
    });
  } catch (err: any) {
    console.error(`Error in /api/lyrics/${id}/translate:`, err);
    res.status(500).json({
      success: false,
      error: "Translation failed",
      detail: err.message || "Unknown error",
    });
  }
});

// Catch-all for undefined /api routes: Always return JSON, never HTML
app.use("/api/*", (req: Request, res: Response) => {
  res.status(404).json({
    success: false,
    error: "API endpoint not found",
  });
});

// Redirect legacy /track and /song URLs to home
app.get(["/track/*", "/song/*", "/track", "/song"], (req: Request, res: Response) => {
  res.redirect(301, "/");
});

// SEO: robots.txt
app.get("/robots.txt", (req: Request, res: Response) => {
  const host = req.get("host") || "localhost:3000";
  const protocol = req.protocol === "https" || req.headers["x-forwarded-proto"] === "https" ? "https" : "http";
  const baseUrl = `${protocol}://${host}`;

  const robotsContent = [
    "User-agent: *",
    "Allow: /",
    "Disallow: /api/",
    "Disallow: /download/",
    "",
    `Sitemap: ${baseUrl}/sitemap.xml`,
    "",
  ].join("\n");

  res.setHeader("Cache-Control", "public, max-age=86400");
  res.type("text/plain").send(robotsContent);
});

// SEO: sitemap.xml sourced from sitemap-data.json with optional dynamic top artists
app.get("/sitemap.xml", async (req: Request, res: Response) => {
  const host = req.get("host") || "localhost:3000";
  const protocol =
    req.protocol === "https" || req.headers["x-forwarded-proto"] === "https"
      ? "https"
      : "http";
  const baseUrl = `${protocol}://${host}`;
  const today = new Date().toISOString().split("T")[0];

  interface SitemapEntry {
    loc: string;
    lastmod: string;
    changefreq: string;
    priority: string;
  }

  const entriesMap = new Map<string, SitemapEntry>();

  // 1. Read manual entries from sitemap-data.json
  let includeDynamic = true;
  const sitemapJsonPath = path.resolve(process.cwd(), "sitemap-data.json");
  try {
    if (fs.existsSync(sitemapJsonPath)) {
      const fileRaw = fs.readFileSync(sitemapJsonPath, "utf-8");
      const parsed = JSON.parse(fileRaw);

      if (typeof parsed.includeDynamicTopArtists === "boolean") {
        includeDynamic = parsed.includeDynamicTopArtists;
      }

      const manualUrls = Array.isArray(parsed.urls)
        ? parsed.urls
        : Array.isArray(parsed)
        ? parsed
        : [];

      for (const item of manualUrls) {
        if (!item || (!item.path && !item.loc && !item.url)) continue;
        const rawPath = String(item.path || item.loc || item.url).trim();
        if (!rawPath) continue;

        // Resolve absolute URL
        const loc = rawPath.startsWith("http://") || rawPath.startsWith("https://")
          ? rawPath
          : `${baseUrl}${rawPath.startsWith("/") ? "" : "/"}${rawPath}`;

        const lastmod = item.lastmod && String(item.lastmod).trim()
          ? String(item.lastmod).trim()
          : today;
        const changefreq = item.changefreq || (rawPath === "/" ? "daily" : "weekly");
        const priority = typeof item.priority === "number"
          ? item.priority.toFixed(1)
          : String(item.priority || (rawPath === "/" ? "1.0" : "0.8"));

        entriesMap.set(loc, { loc, lastmod, changefreq, priority });
      }
    }
  } catch (err) {
    console.warn("Error reading sitemap-data.json:", err);
  }

  // Ensure root / is always present if not defined in json
  if (!entriesMap.has(`${baseUrl}/`)) {
    entriesMap.set(`${baseUrl}/`, {
      loc: `${baseUrl}/`,
      lastmod: today,
      changefreq: "daily",
      priority: "1.0",
    });
  }

  // 2. Dynamically include top trending artists if enabled
  if (includeDynamic) {
    try {
      const top = await getHomeTopSongs();
      const seenArtists = new Set<string>();

      for (const s of top) {
        if (s.artist_name && !seenArtists.has(s.artist_name.toLowerCase())) {
          seenArtists.add(s.artist_name.toLowerCase());
          const artistId = s.artist_id || (s.artists && s.artists[0]?.id);
          const artistSlug = slugify(s.artist_name) || "artist";
          const artistLoc = artistId
            ? `${baseUrl}/artist/${artistId}/${artistSlug}`
            : `${baseUrl}/artist/${artistSlug}`;

          if (!entriesMap.has(artistLoc)) {
            entriesMap.set(artistLoc, {
              loc: artistLoc,
              lastmod: today,
              changefreq: "weekly",
              priority: "0.8",
            });
          }
        }
      }
    } catch {
      // Fallback gracefully if ytmusic API has transient issue
    }
  }

  // 3. Render clean XML
  const xmlUrls = Array.from(entriesMap.values())
    .map(
      (entry) => `  <url>
    <loc>${entry.loc}</loc>
    <lastmod>${entry.lastmod}</lastmod>
    <changefreq>${entry.changefreq}</changefreq>
    <priority>${entry.priority}</priority>
  </url>`
    )
    .join("\n");

  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${xmlUrls}
</urlset>`;

  res.setHeader("Cache-Control", "public, max-age=1800");
  res.type("application/xml").send(sitemap.trim());
});

// Setup Vite or Static serving with dynamic SEO SSR meta tag injection
async function startServer() {
  const STATIC_ASSET_REGEX =
    /\.(js|mjs|cjs|ts|tsx|jsx|css|json|ico|png|jpg|jpeg|gif|svg|webp|woff|woff2|ttf|eot|map|webmanifest)$/i;

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "custom",
    });
    app.use(vite.middlewares);

    app.get("*", async (req: Request, res: Response, next: NextFunction) => {
      if (
        req.path.startsWith("/api") ||
        req.path.startsWith("/@") ||
        req.path.startsWith("/src") ||
        req.path.startsWith("/node_modules") ||
        STATIC_ASSET_REGEX.test(req.path)
      ) {
        return next();
      }

      try {
        const url = req.originalUrl;
        let template = fs.readFileSync(path.resolve(process.cwd(), "index.html"), "utf-8");
        template = await vite.transformIndexHtml(url, template);
        let pageMeta;
        try {
          pageMeta = await resolvePageMeta(req);
        } catch (metaErr) {
          console.warn("Error resolving page SEO meta:", metaErr);
        }
        const html = pageMeta ? injectMetaIntoHtml(template, pageMeta) : template;
        res.status(200).set({
          "Content-Type": "text/html; charset=utf-8",
          "X-Robots-Tag": "index, follow, max-image-preview:large",
        }).end(html);
      } catch (e: any) {
        vite.ssrFixStacktrace(e);
        next(e);
      }
    });
  } else {
    const distPath = path.join(process.cwd(), "dist");
    const indexHtmlPath = path.join(distPath, "index.html");
    let indexHtmlTemplate = "";
    try {
      indexHtmlTemplate = fs.readFileSync(indexHtmlPath, "utf-8");
    } catch {
      // Will read per request
    }

    // Static assets (hashed JS, CSS, images) cached for 1 year immutable
    app.use(
      "/assets",
      express.static(path.join(distPath, "assets"), {
        maxAge: "1y",
        immutable: true,
      })
    );

    // Other public files
    app.use(
      express.static(distPath, {
        maxAge: "1h",
        index: false,
      })
    );

    app.get("*", async (req: Request, res: Response, next: NextFunction) => {
      if (req.path.startsWith("/api") || STATIC_ASSET_REGEX.test(req.path)) return next();
      try {
        const template = indexHtmlTemplate || fs.readFileSync(indexHtmlPath, "utf-8");
        let pageMeta;
        try {
          pageMeta = await resolvePageMeta(req);
        } catch (metaErr) {
          console.warn("Error resolving page SEO meta:", metaErr);
        }
        const html = pageMeta ? injectMetaIntoHtml(template, pageMeta) : template;
        res.status(200).set({
          "Content-Type": "text/html; charset=utf-8",
          "Cache-Control": "public, max-age=60, stale-while-revalidate=300",
          "X-Robots-Tag": "index, follow, max-image-preview:large",
        }).end(html);
      } catch {
        res.sendFile(indexHtmlPath);
      }
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
    // Trigger background warm-up
    warmupYtMusic();
  });
}

startServer();
