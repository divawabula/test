import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Volume2,
  VolumeX,
  ListMusic,
  ChevronUp,
  ChevronDown,
  X,
  Mic2,
} from "lucide-react";
import { useAudioPlayer } from "../context/AudioPlayerContext";
import { formatThumbnailUrl } from "../utils/thumbnail";
import { getArtistUrl } from "../utils/seo";
import KaraokeModal from "./KaraokeModal";

export default function AudioPlayer() {
  const {
    currentSong,
    isPlaying,
    currentTime,
    duration,
    volume,
    isMuted,
    queue,
    queueIndex,
    isBuffering,
    togglePlay,
    nextSong,
    prevSong,
    seek,
    setVolume,
    toggleMute,
    playSong,
    removeFromQueue,
    isLyricsOpen,
    toggleLyrics,
    closeLyrics,
  } = useAudioPlayer();

  const [showQueue, setShowQueue] = useState(false);
  const [isMobileExpanded, setIsMobileExpanded] = useState(false);
  const navigate = useNavigate();

  if (!currentSong) {
    return null;
  }

  const artistUrl = getArtistUrl(
    currentSong.artist_id || currentSong.artists?.[0]?.id,
    currentSong.artist_name
  );

  const handlePlayerBackgroundClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const target = e.target as HTMLElement | null;
    if (!target) return;

    // Do not trigger background navigation if clicked inside interactive controls
    if (
      target.closest("button") ||
      target.closest("input") ||
      target.closest("a") ||
      target.closest("[data-interactive='true']")
    ) {
      return;
    }

    if (artistUrl && artistUrl !== "/") {
      navigate(artistUrl);
    }
  };

  // Format seconds into m:ss
  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return "0:00";
    const minutes = Math.floor(secs / 60);
    const seconds = Math.floor(secs % 60);
    return `${minutes}:${seconds.toString().padStart(2, "0")}`;
  };

  const handleSeekChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    seek(val);
  };

  const progressPercent = duration > 0 ? Math.min(100, (currentTime / duration) * 100) : 0;

  return (
    <>
      {/* Fixed bottom Neo-Brutalist Player Bar */}
      <div
        id="global-audio-player"
        onClick={handlePlayerBackgroundClick}
        className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t-2 border-black select-none cursor-pointer"
        role="region"
        aria-label="Audio Player"
        title={artistUrl ? `Buka halaman artis: ${currentSong.artist_name}` : undefined}
      >
        {/* Progress Bar (Scrubber) at top of player - Clean & Harmonious */}
        <div
          data-interactive="true"
          className="relative w-full h-2 bg-neutral-200 border-b border-black cursor-pointer group select-none"
        >
          <div
            className="h-full bg-[#FFE600] border-r-2 border-black relative"
            style={{ width: `${progressPercent}%` }}
          >
            {/* Scrubber thumb indicator */}
            <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 w-3 h-3 bg-black border border-[#FFE600] pointer-events-none" />
          </div>
          <input
            type="range"
            min={0}
            max={duration || 100}
            step={0.5}
            value={currentTime}
            onChange={handleSeekChange}
            aria-label="Track progress"
            className="absolute -top-2 -bottom-2 inset-x-0 w-full opacity-0 cursor-pointer z-10"
          />
        </div>

        <div className="max-w-7xl mx-auto px-3.5 sm:px-6 py-2">
          <div className="flex items-center justify-between gap-3 sm:gap-6">
            {/* 1. Track Info */}
            <div className="flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1 sm:w-72 md:w-80 sm:flex-initial">
              <div
                onClick={togglePlay}
                data-interactive="true"
                className="relative w-10 h-10 flex-shrink-0 border-2 border-black bg-black overflow-hidden cursor-pointer group"
                title={isPlaying ? "Pause" : "Play"}
              >
                <img
                  src={formatThumbnailUrl(currentSong.thumbnail, 100, 100)}
                  alt={`Cover art for ${currentSong.title}`}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src =
                      "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=120&auto=format&fit=crop&q=80";
                  }}
                />
              </div>

              <div className="min-w-0 flex-1 pr-1">
                <div className="flex items-center gap-1.5 min-w-0">
                  <span
                    className="font-black text-sm sm:text-sm text-black truncate block leading-tight"
                    title={currentSong.title}
                  >
                    {currentSong.title}
                  </span>
                  {isBuffering && (
                    <span className="text-[8px] uppercase font-bold bg-neutral-200 px-1 border border-black flex-shrink-0">
                      Buffering
                    </span>
                  )}
                </div>

                <div className="text-xs sm:text-xs font-semibold text-neutral-600 truncate mt-0.5">
                  <Link
                    to={getArtistUrl(currentSong.artist_id || currentSong.artists?.[0]?.id, currentSong.artist_name)}
                    title={`View artist profile for ${currentSong.artist_name}`}
                    className="hover:text-black hover:underline cursor-pointer"
                  >
                    {currentSong.artist_name}
                  </Link>
                </div>
              </div>
            </div>

            {/* 2. Center: Controls & Time (Desktop compact layout) */}
            <div className="hidden sm:flex flex-col items-center justify-center gap-0.5 flex-1 max-w-md" data-interactive="true">
              <div className="flex items-center gap-2.5 md:gap-3">
                {/* Prev Button */}
                <button
                  onClick={prevSong}
                  disabled={queue.length <= 1}
                  id="player-prev-btn"
                  className="p-1 sm:p-1.5 border-2 border-black bg-white hover:bg-neutral-100 disabled:opacity-30 disabled:hover:bg-white cursor-pointer transition-transform active:translate-x-0.5 active:translate-y-0.5"
                  aria-label="Previous song"
                >
                  <SkipBack className="w-3.5 h-3.5 fill-current text-black" />
                </button>

                {/* Play / Pause Button */}
                <button
                  onClick={togglePlay}
                  id="player-play-pause-btn"
                  className="p-1.5 sm:p-2 border-2 border-black bg-[#FFE600] hover:bg-black hover:text-[#FFE600] transition-colors cursor-pointer active:translate-x-0.5 active:translate-y-0.5"
                  aria-label={isPlaying ? "Pause" : "Play"}
                >
                  {isPlaying ? (
                    <Pause className="w-4 h-4 fill-current" />
                  ) : (
                    <Play className="w-4 h-4 fill-current ml-0.5" />
                  )}
                </button>

                {/* Next Button */}
                <button
                  onClick={nextSong}
                  disabled={queue.length <= 1}
                  id="player-next-btn"
                  className="p-1.5 sm:p-1.5 border-2 border-black bg-white hover:bg-neutral-100 disabled:opacity-30 disabled:hover:bg-white cursor-pointer transition-transform active:translate-x-0.5 active:translate-y-0.5"
                  aria-label="Next song"
                >
                  <SkipForward className="w-3.5 h-3.5 fill-current text-black" />
                </button>
              </div>

              {/* Time display on Desktop */}
              <div className="flex items-center gap-1.5 text-[10px] font-mono font-bold text-neutral-500">
                <span>{formatTime(currentTime)}</span>
                <span>/</span>
                <span>{formatTime(duration)}</span>
              </div>
            </div>

            {/* 3. Mobile Compact Controls (Thicker, tactile touch targets) */}
            <div className="flex sm:hidden items-center gap-1.5 flex-shrink-0" data-interactive="true">
              {/* Prev */}
              <button
                onClick={prevSong}
                disabled={queue.length <= 1}
                className="p-1.5 border-2 border-black bg-white active:bg-neutral-100 disabled:opacity-30 cursor-pointer"
                aria-label="Previous song"
              >
                <SkipBack className="w-3.5 h-3.5 fill-current text-black" />
              </button>

              {/* Play / Pause (Primary Action) */}
              <button
                onClick={togglePlay}
                id="player-play-pause-mobile-btn"
                className="p-1.5 border-2 border-black bg-[#FFE600] active:bg-black active:text-[#FFE600] transition-colors cursor-pointer active:translate-x-0.5 active:translate-y-0.5"
                aria-label={isPlaying ? "Pause" : "Play"}
              >
                {isPlaying ? (
                  <Pause className="w-4 h-4 fill-current" />
                ) : (
                  <Play className="w-4 h-4 fill-current ml-0.5" />
                )}
              </button>

              {/* Next */}
              <button
                onClick={nextSong}
                disabled={queue.length <= 1}
                className="p-1.5 border-2 border-black bg-white active:bg-neutral-100 disabled:opacity-30 cursor-pointer"
                aria-label="Next song"
              >
                <SkipForward className="w-3.5 h-3.5 fill-current text-black" />
              </button>

              {/* Lyrics Button with Mic icon (Mobile) */}
              <button
                type="button"
                onClick={toggleLyrics}
                id="player-lyrics-mobile-btn"
                className={`p-1.5 border-2 border-black relative cursor-pointer ${
                  isLyricsOpen ? "bg-[#FFE600] text-black" : "bg-white text-black"
                }`}
                aria-label="Toggle karaoke lyrics"
                title="Lirik Karaoke"
              >
                <Mic2 className="w-3.5 h-3.5" />
              </button>

              {/* Queue Button with Badge */}
              <button
                onClick={() => setShowQueue(!showQueue)}
                className={`p-1.5 border-2 border-black relative cursor-pointer ${
                  showQueue ? "bg-black text-[#FFE600]" : "bg-white text-black"
                }`}
                aria-label="Toggle song queue"
              >
                <ListMusic className="w-3.5 h-3.5" />
                {queue.length > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 bg-[#FFE600] text-black text-[9px] font-black w-4 h-4 rounded-full border border-black flex items-center justify-center">
                    {queue.length}
                  </span>
                )}
              </button>

              {/* Mobile details expander toggle */}
              <button
                onClick={() => setIsMobileExpanded(!isMobileExpanded)}
                className={`p-1.5 border-2 border-black transition-colors cursor-pointer ${
                  isMobileExpanded ? "bg-black text-white" : "bg-white text-black"
                }`}
                aria-label={isMobileExpanded ? "Collapse player details" : "Expand player details"}
              >
                {isMobileExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronUp className="w-3.5 h-3.5" />}
              </button>
            </div>

            {/* 4. Desktop Right: Volume, Lyrics & Queue */}
            <div className="hidden sm:flex items-center justify-end gap-2 sm:gap-2.5 sm:w-72 md:w-80 flex-initial" data-interactive="true">
              {/* Volume Slider (Desktop - default 100%) */}
              <div className="flex items-center gap-1.5">
                <button
                  onClick={toggleMute}
                  id="player-mute-btn"
                  className="p-1 border border-black bg-white hover:bg-neutral-100 cursor-pointer"
                  aria-label={isMuted ? "Unmute" : "Mute"}
                >
                  {isMuted || volume === 0 ? (
                    <VolumeX className="w-3.5 h-3.5 text-black" />
                  ) : (
                    <Volume2 className="w-3.5 h-3.5 text-black" />
                  )}
                </button>
                <input
                  type="range"
                  min={0}
                  max={1}
                  step={0.05}
                  value={isMuted ? 0 : volume}
                  onChange={(e) => setVolume(parseFloat(e.target.value))}
                  aria-label="Volume slider"
                  className="w-14 md:w-18 h-1 bg-neutral-200 border border-black cursor-pointer accent-[#FFE600]"
                />
                <span className="text-[9px] font-mono font-bold text-neutral-600 w-7 text-right">
                  {isMuted ? "0%" : `${Math.round(volume * 100)}%`}
                </span>
              </div>

              {/* Lyrics Karaoke Button (Desktop) - Icon Only */}
              <button
                type="button"
                onClick={toggleLyrics}
                id="player-lyrics-btn"
                className={`p-1.5 border-2 border-black cursor-pointer transition-transform active:translate-x-0.5 active:translate-y-0.5 ${
                  isLyricsOpen ? "bg-[#FFE600] text-black" : "bg-white text-black hover:bg-neutral-100"
                }`}
                aria-label="Toggle karaoke lyrics"
                title="Karaoke Lyrics"
              >
                <Mic2 className="w-4 h-4" />
              </button>

              {/* Queue Drawer Button - Icon Only */}
              <button
                onClick={() => setShowQueue(!showQueue)}
                id="player-queue-btn"
                className={`p-1.5 border-2 border-black cursor-pointer transition-transform active:translate-x-0.5 active:translate-y-0.5 relative ${
                  showQueue ? "bg-black text-[#FFE600]" : "bg-white text-black hover:bg-neutral-100"
                }`}
                aria-label="Toggle song queue"
                title="Playing Queue"
              >
                <ListMusic className="w-4 h-4" />
                {queue.length > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 bg-[#FFE600] text-black text-[9px] font-black w-4 h-4 rounded-full border border-black flex items-center justify-center leading-none">
                    {queue.length}
                  </span>
                )}
              </button>
            </div>
          </div>

          {/* Mobile Expanded Drawer: Time display & Volume Control */}
          {isMobileExpanded && (
            <div
              data-interactive="true"
              className="sm:hidden pt-2.5 mt-2 border-t-2 border-dashed border-neutral-300 space-y-2 animate-in fade-in slide-in-from-bottom duration-150"
            >
              <div className="flex items-center justify-between text-xs font-bold">
                <div className="flex items-center gap-2 font-mono text-neutral-700">
                  <span className="text-black font-black">{formatTime(currentTime)}</span>
                  <span>/</span>
                  <span>{formatTime(duration)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={toggleMute}
                    className="p-1 border border-black bg-white cursor-pointer"
                    aria-label={isMuted ? "Unmute" : "Mute"}
                  >
                    {isMuted || volume === 0 ? (
                      <VolumeX className="w-3.5 h-3.5 text-black" />
                    ) : (
                      <Volume2 className="w-3.5 h-3.5 text-black" />
                    )}
                  </button>
                  <input
                    type="range"
                    min={0}
                    max={1}
                    step={0.05}
                    value={isMuted ? 0 : volume}
                    onChange={(e) => setVolume(parseFloat(e.target.value))}
                    aria-label="Volume slider"
                    className="w-24 h-2 bg-neutral-200 border border-black accent-[#FFE600]"
                  />
                  <span className="text-[10px] font-mono font-bold text-neutral-600 w-8 text-right">
                    {isMuted ? "0%" : `${Math.round(volume * 100)}%`}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Karaoke Lyrics Modal */}
      <KaraokeModal
        isOpen={isLyricsOpen}
        onClose={closeLyrics}
        song={currentSong}
        currentTime={currentTime}
        duration={duration}
        isPlaying={isPlaying}
        onTogglePlay={togglePlay}
        onSeek={seek}
        onNext={nextSong}
        onPrev={prevSong}
        canPrev={queue.length > 1}
        canNext={queue.length > 1}
        volume={volume}
        isMuted={isMuted}
        onToggleMute={toggleMute}
      />

      {/* Queue Drawer Modal / Popover */}
      {showQueue && (
        <div
          id="queue-drawer"
          className="fixed bottom-[64px] sm:bottom-[60px] left-2 right-2 sm:left-auto sm:right-6 sm:w-96 max-h-[65vh] z-50 bg-white border-2 border-black flex flex-col"
        >
          {/* Header */}
          <div className="p-3 border-b-2 border-black bg-[#FFE600] flex items-center justify-between">
            <div className="flex items-center gap-2 font-black text-sm">
              <ListMusic className="w-4 h-4" />
              <span>Playing Queue ({queue.length})</span>
            </div>
            <button
              onClick={() => setShowQueue(false)}
              className="p-1 border border-black bg-white hover:bg-black hover:text-white cursor-pointer"
              aria-label="Close queue"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Queue Items List */}
          <div className="overflow-y-auto flex-1 divide-y divide-neutral-200 max-h-[50vh]">
            {queue.length === 0 ? (
              <div className="p-6 text-center text-xs font-bold text-neutral-500">
                Queue is empty
              </div>
            ) : (
              queue.map((song, idx) => {
                const isItemCurrent = idx === queueIndex;
                return (
                  <div
                    key={`${song.id}-${idx}`}
                    className={`flex items-center justify-between p-2.5 hover:bg-neutral-50 cursor-pointer ${
                      isItemCurrent ? "bg-[#FFF9C4]" : ""
                    }`}
                    onClick={() => playSong(song, queue)}
                  >
                    <div className="flex items-center gap-2.5 min-w-0 flex-1">
                      <div className="w-8 h-8 flex-shrink-0 border border-black overflow-hidden">
                        <img
                          src={formatThumbnailUrl(song.thumbnail, 100, 100)}
                          alt={song.title}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className={`text-xs font-black truncate ${isItemCurrent ? "text-black" : "text-neutral-800"}`}>
                          {song.title}
                        </p>
                        <p className="text-[11px] font-semibold text-neutral-500 truncate">
                          {song.artist_name}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 flex-shrink-0 ml-2">
                      <span className="text-[10px] font-mono font-bold text-neutral-500">
                        {song.duration}
                      </span>
                      {queue.length > 1 && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            removeFromQueue(idx);
                          }}
                          className="p-1 hover:bg-red-100 text-neutral-500 hover:text-red-600 border border-transparent hover:border-black"
                          aria-label={`Remove ${song.title} from queue`}
                        >
                          <X className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </>
  );
}
