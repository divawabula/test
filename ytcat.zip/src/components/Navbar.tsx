import { useState, FormEvent, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Cat, Search, X } from "lucide-react";
import SearchAutocomplete from "./SearchAutocomplete";
import { getSearchNavigationUrl } from "../utils/youtube";

export default function Navbar() {
  const location = useLocation();
  const navigate = useNavigate();
  const isHomeOrSearchPage = location.pathname === "/" || location.pathname.startsWith("/search");
  const [searchTerm, setSearchTerm] = useState("");
  const [isMobileSearchOpen, setIsMobileSearchOpen] = useState(false);

  // Close mobile search on route changes and sync search input
  useEffect(() => {
    setIsMobileSearchOpen(false);
    if (location.pathname.startsWith("/search/")) {
      const raw = decodeURIComponent(location.pathname.replace(/^\/search\//, "")).replace(/[-_+]/g, " ");
      setSearchTerm(raw);
    } else if (location.pathname === "/search") {
      const q = new URLSearchParams(location.search).get("q") || "";
      setSearchTerm(q);
    } else if (location.pathname === "/") {
      setSearchTerm("");
    }
  }, [location.pathname, location.search]);

  const handleSubmit = (eOrQuery?: FormEvent | string) => {
    if (eOrQuery && typeof eOrQuery === "object" && "preventDefault" in eOrQuery) {
      eOrQuery.preventDefault();
    }
    const target = typeof eOrQuery === "string" ? eOrQuery : searchTerm;
    const query = target.trim();
    if (query) {
      navigate(getSearchNavigationUrl(query));
      setIsMobileSearchOpen(false);
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b-2 border-black" id="main-header">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-3 sm:gap-4">
          {/* Logo (always visible on mobile and desktop) */}
          <Link
            to="/"
            id="nav-logo"
            className="flex items-center gap-2 sm:gap-2.5 font-black text-xl tracking-tight text-black group flex-shrink-0"
          >
            <div className="w-9 h-9 sm:w-10 sm:h-10 bg-[#FFE600] border-2 border-black flex items-center justify-center font-black group-hover:rotate-6 transition-transform">
              <Cat className="w-5 h-5 sm:w-6 sm:h-6 text-black" strokeWidth={2.2} />
            </div>
            <div className="flex flex-col">
              <span className="leading-none text-base sm:text-lg font-black uppercase tracking-tight">
                YT<span className="text-[#FF2A6D]">cat</span>
              </span>
              <span className="text-[9px] sm:text-[10px] font-bold tracking-wider text-neutral-600">
                YTMusic Downloader
              </span>
            </div>
          </Link>

          {/* Desktop Search Bar Form & Mobile Toggle - Only shown outside Home and Search pages */}
          {!isHomeOrSearchPage && (
            <>
              {/* Desktop Search Bar Form */}
              <form
                onSubmit={handleSubmit}
                role="search"
                aria-label="Quick Song Search"
                id="header-search-form"
                className="hidden sm:block flex-1 max-w-xs sm:max-w-md ml-auto"
              >
                <div className="relative flex items-center w-full border-2 border-black bg-neutral-50 focus-within:bg-white transition-all">
                  <SearchAutocomplete
                    id="header-search-input"
                    value={searchTerm}
                    onChange={setSearchTerm}
                    onSubmit={(val) => handleSubmit(val)}
                    placeholder="Search songs or paste YouTube link..."
                    variant="compact"
                    ariaLabel="Search songs or YouTube link"
                  />

                  <button
                    type="submit"
                    id="header-search-submit-btn"
                    aria-label="Start search"
                    className="px-2.5 py-1.5 sm:py-2 bg-[#FFE600] border-l-2 border-black font-black text-xs uppercase hover:bg-black hover:text-[#FFE600] transition-colors flex items-center justify-center cursor-pointer shrink-0"
                  >
                    <Search className="w-3.5 h-3.5" />
                  </button>
                </div>
              </form>

              {/* Mobile Search Toggle Icon Button */}
              <button
                type="button"
                id="mobile-search-toggle-btn"
                onClick={() => setIsMobileSearchOpen((prev) => !prev)}
                aria-label={isMobileSearchOpen ? "Close search" : "Open search"}
                aria-expanded={isMobileSearchOpen}
                className={`sm:hidden p-2 border-2 border-black font-bold transition-all cursor-pointer ml-auto flex items-center justify-center active:translate-x-0.5 active:translate-y-0.5 ${
                  isMobileSearchOpen
                    ? "bg-black text-[#FFE600]"
                    : "bg-[#FFE600] text-black hover:bg-black hover:text-[#FFE600]"
                }`}
              >
                {isMobileSearchOpen ? <X className="w-4 h-4" /> : <Search className="w-4 h-4" />}
              </button>
            </>
          )}
        </div>
      </div>

      {/* Mobile Search Bar Dropdown */}
      {!isHomeOrSearchPage && isMobileSearchOpen && (
        <div
          id="mobile-search-bar"
          className="sm:hidden border-t-2 border-black bg-white px-4 py-3 shadow-[0_4px_0_0_#000]"
        >
          <form
            onSubmit={handleSubmit}
            role="search"
            aria-label="Mobile Search"
            id="mobile-search-form"
            className="w-full"
          >
            <div className="relative flex items-center w-full border-2 border-black bg-[#F4F4F0] focus-within:bg-white transition-all">
              <SearchAutocomplete
                id="mobile-search-input"
                value={searchTerm}
                onChange={setSearchTerm}
                onSubmit={(val) => handleSubmit(val)}
                placeholder="Search songs or paste YouTube link..."
                variant="compact"
                autoFocus
                ariaLabel="Search songs or YouTube link"
              />

              <button
                type="submit"
                id="mobile-search-submit-btn"
                aria-label="Start search"
                className="px-3.5 py-2 bg-[#FFE600] border-l-2 border-black font-black text-xs uppercase hover:bg-black hover:text-[#FFE600] transition-colors flex items-center justify-center cursor-pointer shrink-0"
              >
                Search
              </button>
            </div>
          </form>
        </div>
      )}
    </header>
  );
}

