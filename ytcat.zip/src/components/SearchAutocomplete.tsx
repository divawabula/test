import React, { useState, useEffect, useRef, useCallback } from "react";
import { Search, X, ArrowUpRight } from "lucide-react";
import { apiFetch } from "../utils/apiClient";

// In-memory cache for ultra-fast, lightweight text autocomplete without redundant network requests
const querySuggestionsCache = new Map<string, string[]>();

interface SearchAutocompleteProps {
  id: string;
  value: string;
  onChange: (value: string) => void;
  onSubmit: (value: string) => void;
  placeholder?: string;
  className?: string;
  autoFocus?: boolean;
  variant?: "default" | "compact";
  ariaLabel?: string;
}

export default function SearchAutocomplete({
  id,
  value,
  onChange,
  onSubmit,
  placeholder = "Search songs, artists, or paste YouTube link...",
  className = "",
  autoFocus = false,
  variant = "default",
  ariaLabel = "Search songs or YouTube link",
}: SearchAutocompleteProps) {
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [queries, setQueries] = useState<string[]>([]);
  const [selectedIndex, setSelectedIndex] = useState<number>(-1);

  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const debounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const isUserTypingRef = useRef<boolean>(false);

  // Fetch lightweight text suggestions with 180ms debounce and in-memory cache
  useEffect(() => {
    // Only search suggestions if the change was initiated by direct user keystroke typing
    if (!isUserTypingRef.current) {
      setIsOpen(false);
      setSelectedIndex(-1);
      return;
    }

    const trimmed = value.trim();

    // Reset if empty
    if (!trimmed) {
      setQueries([]);
      setIsOpen(false);
      setSelectedIndex(-1);
      return;
    }

    // Do not suggest for direct YouTube URLs
    if (/(?:youtu\.be\/|youtube\.com\/)/i.test(trimmed)) {
      setQueries([]);
      setIsOpen(false);
      return;
    }

    const cacheKey = trimmed.toLowerCase();

    // Instant cache lookup
    if (querySuggestionsCache.has(cacheKey)) {
      const cached = querySuggestionsCache.get(cacheKey)!;
      setQueries(cached);
      setIsOpen(cached.length > 0);
      setSelectedIndex(-1);
      return;
    }

    // Cancel prior in-flight request and timer
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    const controller = new AbortController();
    abortControllerRef.current = controller;

    debounceTimerRef.current = setTimeout(async () => {
      try {
        const json = await apiFetch<any>(
          `/api/suggestions?q=${encodeURIComponent(trimmed)}`,
          { signal: controller.signal }
        );
        // Only open if the user is still actively typing
        if (isUserTypingRef.current && json && json.success && json.data) {
          const list: string[] = Array.isArray(json.data.queries)
            ? json.data.queries
            : [];
          querySuggestionsCache.set(cacheKey, list);
          setQueries(list);
          setIsOpen(list.length > 0);
        }
      } catch (err: any) {
        if (err.name !== "AbortError") {
          // silently handle network error
        }
      }
    }, 180);

    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
      controller.abort();
    };
  }, [value]);

  // Close on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        containerRef.current &&
        !containerRef.current.contains(event.target as Node)
      ) {
        isUserTypingRef.current = false;
        setIsOpen(false);
        setSelectedIndex(-1);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleSelectQuery = useCallback(
    (queryText: string) => {
      // User picked a keyword: stop typing mode and immediately close suggestions
      isUserTypingRef.current = false;
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
        debounceTimerRef.current = null;
      }
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
        abortControllerRef.current = null;
      }
      setIsOpen(false);
      setSelectedIndex(-1);
      onChange(queryText);
      onSubmit(queryText);
    },
    [onChange, onSubmit]
  );

  // Keyboard navigation (ArrowDown, ArrowUp, Enter, Escape)
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!isOpen || queries.length === 0) {
      if (e.key === "Enter") {
        e.preventDefault();
        isUserTypingRef.current = false;
        if (debounceTimerRef.current) {
          clearTimeout(debounceTimerRef.current);
        }
        if (abortControllerRef.current) {
          abortControllerRef.current.abort();
        }
        setIsOpen(false);
        onSubmit(value);
      }
      return;
    }

    if (e.key === "ArrowDown") {
      e.preventDefault();
      setSelectedIndex((prev) => (prev + 1 >= queries.length ? 0 : prev + 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setSelectedIndex((prev) => (prev - 1 < 0 ? queries.length - 1 : prev - 1));
    } else if (e.key === "Enter") {
      e.preventDefault();
      isUserTypingRef.current = false;
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
      setIsOpen(false);
      if (selectedIndex >= 0 && selectedIndex < queries.length) {
        handleSelectQuery(queries[selectedIndex]);
      } else {
        onSubmit(value);
      }
    } else if (e.key === "Escape") {
      e.preventDefault();
      isUserTypingRef.current = false;
      setIsOpen(false);
      setSelectedIndex(-1);
    }
  };

  const handleClear = () => {
    isUserTypingRef.current = false;
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    onChange("");
    setQueries([]);
    setIsOpen(false);
    setSelectedIndex(-1);
    inputRef.current?.focus();
  };

  const isCompact = variant === "compact";

  return (
    <div ref={containerRef} className={`relative flex-1 ${className}`}>
      {/* Input Field Container */}
      <div className="relative flex items-center w-full">
        <div className="absolute left-0 pl-3 flex items-center pointer-events-none text-neutral-500">
          <Search className={isCompact ? "w-3.5 h-3.5" : "w-4 h-4"} />
        </div>

        <input
          ref={inputRef}
          id={id}
          type="text"
          value={value}
          onChange={(e) => {
            isUserTypingRef.current = true;
            onChange(e.target.value);
          }}
          onFocus={() => {
            if (isUserTypingRef.current && value.trim() && queries.length > 0) {
              setIsOpen(true);
            }
          }}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          aria-label={ariaLabel}
          aria-autocomplete="list"
          aria-expanded={isOpen}
          autoComplete="off"
          autoFocus={autoFocus}
          className={
            isCompact
              ? "w-full py-1.5 sm:py-2 text-xs sm:text-sm font-bold bg-transparent focus:outline-none text-black placeholder-neutral-500 pl-8 pr-8"
              : "w-full pl-10 pr-10 py-2.5 border-2 border-black bg-[#F4F4F0] text-sm font-bold text-black placeholder-neutral-500 focus:outline-none focus:bg-white transition-colors"
          }
        />

        {value && (
          <button
            type="button"
            onClick={handleClear}
            className={
              isCompact
                ? "absolute right-2 top-1/2 -translate-y-1/2 p-0.5 text-neutral-400 hover:text-black cursor-pointer"
                : "absolute inset-y-0 right-0 pr-3.5 flex items-center text-neutral-500 hover:text-black cursor-pointer"
            }
            aria-label="Clear search input"
          >
            <X className={isCompact ? "w-3.5 h-3.5" : "w-4 h-4"} />
          </button>
        )}
      </div>

      {/* Autocomplete Dropdown - Text only, flat Neo-Brutalism (no box shadow) */}
      {isOpen && queries.length > 0 && (
        <div
          id={`${id}-suggestions`}
          role="listbox"
          aria-label="Search suggestions"
          className="absolute left-0 right-0 top-full mt-1.5 bg-white border-2 border-black z-50 overflow-hidden"
        >
          <div className="py-1">
            {queries.map((queryText, idx) => {
              const isSelected = selectedIndex === idx;

              return (
                <div
                  key={`query-${idx}`}
                  role="option"
                  aria-selected={isSelected}
                  onClick={() => handleSelectQuery(queryText)}
                  className={`flex items-center justify-between px-3 py-2 text-xs sm:text-sm font-bold cursor-pointer transition-colors ${
                    isSelected
                      ? "bg-[#FFE600] text-black font-black"
                      : "hover:bg-[#FFE600] text-neutral-900 hover:text-black hover:font-black"
                  }`}
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <Search className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
                    <span className="truncate">{queryText}</span>
                  </div>

                  <button
                    type="button"
                    tabIndex={-1}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleSelectQuery(queryText);
                    }}
                    title={`Search "${queryText}"`}
                    className="text-neutral-400 hover:text-black p-1 shrink-0"
                  >
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
