import React, { createContext, useContext, useState, useEffect, useRef, useCallback, useMemo } from "react";
import { Song, AudioPlayerContextType } from "../types";

declare global {
  interface Window {
    YT: any;
    onYouTubeIframeAPIReady: () => void;
  }
}

const AudioPlayerContext = createContext<AudioPlayerContextType | null>(null);

export function AudioPlayerProvider({ children }: { children: React.ReactNode }) {
  const [currentSong, setCurrentSong] = useState<Song | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [volume, setVolumeState] = useState<number>(1.0);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [queue, setQueue] = useState<Song[]>([]);
  const [queueIndex, setQueueIndex] = useState<number>(0);
  const [isBuffering, setIsBuffering] = useState<boolean>(false);
  const [isLyricsOpen, setIsLyricsOpen] = useState<boolean>(false);

  const openLyrics = useCallback(() => {
    setIsLyricsOpen(true);
  }, []);

  const closeLyrics = useCallback(() => {
    setIsLyricsOpen(false);
  }, []);

  const toggleLyrics = useCallback(() => {
    setIsLyricsOpen((prev) => !prev);
  }, []);

  const playerRef = useRef<any>(null);
  const isPlayerReadyRef = useRef<boolean>(false);
  const pendingSongIdRef = useRef<string | null>(null);
  const timerRef = useRef<any>(null);
  const durationRef = useRef<number>(0);

  useEffect(() => {
    durationRef.current = duration;
  }, [duration]);

  // Initialize YouTube IFrame API
  useEffect(() => {
    // Check if script already injected
    if (!window.YT) {
      const tag = document.createElement("script");
      tag.src = "https://www.youtube.com/iframe_api";
      tag.async = true;
      const firstScriptTag = document.getElementsByTagName("script")[0];
      firstScriptTag.parentNode?.insertBefore(tag, firstScriptTag);
    }

    const initPlayer = () => {
      if (!window.YT || !window.YT.Player) return;

      const container = document.getElementById("yt-audio-driver");
      if (!container) return;

      playerRef.current = new window.YT.Player("yt-audio-driver", {
        height: "1",
        width: "1",
        playerVars: {
          autoplay: 1,
          controls: 0,
          disablekb: 1,
          fs: 0,
          modestbranding: 1,
          playsinline: 1,
          rel: 0,
        },
        events: {
          onReady: (event: any) => {
            isPlayerReadyRef.current = true;
            event.target.setVolume(volume * 100);
            if (typeof event.target.setPlaybackQuality === "function") {
              try {
                event.target.setPlaybackQuality("hd1080");
              } catch {}
            }
            if (pendingSongIdRef.current) {
              event.target.loadVideoById({
                videoId: pendingSongIdRef.current,
                suggestedQuality: "hd1080",
              });
              pendingSongIdRef.current = null;
            }
          },
          onPlaybackQualityChange: (event: any) => {
            // Keep stream locked to highest bitrate audio
            if (event.data && event.data !== "hd1080" && event.data !== "highres") {
              try {
                event.target.setPlaybackQuality("hd1080");
              } catch {}
            }
          },
          onStateChange: (event: any) => {
            // YT.PlayerState: -1 (unstarted), 0 (ended), 1 (playing), 2 (paused), 3 (buffering), 5 (video cued)
            if (event.data === 1) {
              setIsPlaying(true);
              setIsBuffering(false);
              const dur = playerRef.current?.getDuration() || 0;
              if (dur > 0) setDuration(dur);
            } else if (event.data === 2) {
              setIsPlaying(false);
              setIsBuffering(false);
            } else if (event.data === 3) {
              setIsBuffering(true);
            } else if (event.data === 0) {
              setIsPlaying(false);
              // Auto advance to next song in queue
              handleNextSong();
            }
          },
          onError: (event: any) => {
            console.warn("YouTube Player error:", event.data);
            setIsBuffering(false);
            setIsPlaying(false);
          },
        },
      });
    };

    if (window.YT && window.YT.Player) {
      initPlayer();
    } else {
      window.onYouTubeIframeAPIReady = initPlayer;
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  // Optimized Timer for tracking current time
  useEffect(() => {
    if (isPlaying) {
      timerRef.current = setInterval(() => {
        if (playerRef.current && typeof playerRef.current.getCurrentTime === "function") {
          try {
            const cur = playerRef.current.getCurrentTime() || 0;
            setCurrentTime(cur);
            const dur = playerRef.current.getDuration() || 0;
            if (dur > 0 && Math.abs(dur - durationRef.current) > 1) {
              setDuration(dur);
            }
          } catch {
            // ignore cross-domain or unready errors
          }
        }
      }, 350);
    } else {
      if (timerRef.current) clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying]);

  const playSong = useCallback((song: Song, customQueue?: Song[]) => {
    setCurrentSong(song);
    setCurrentTime(0);
    setDuration(song.duration_seconds || 210);
    setIsBuffering(true);

    if (customQueue && customQueue.length > 0) {
      setQueue(customQueue);
      const idx = customQueue.findIndex((s) => s.id === song.id);
      setQueueIndex(idx >= 0 ? idx : 0);
    } else {
      setQueue((prevQueue) => {
        const exists = prevQueue.some((s) => s.id === song.id);
        if (!exists) {
          const newQ = [...prevQueue, song];
          setQueueIndex(newQ.length - 1);
          return newQ;
        } else {
          setQueueIndex(prevQueue.findIndex((s) => s.id === song.id));
          return prevQueue;
        }
      });
    }

    if (playerRef.current && isPlayerReadyRef.current && typeof playerRef.current.loadVideoById === "function") {
      playerRef.current.loadVideoById({
        videoId: song.id,
        suggestedQuality: "hd1080",
      });
      if (typeof playerRef.current.setPlaybackQuality === "function") {
        try {
          playerRef.current.setPlaybackQuality("hd1080");
        } catch {}
      }
      playerRef.current.playVideo();
    } else {
      pendingSongIdRef.current = song.id;
    }
  }, []);

  const togglePlay = useCallback(() => {
    if (!currentSong) return;

    if (isPlaying) {
      if (playerRef.current && typeof playerRef.current.pauseVideo === "function") {
        playerRef.current.pauseVideo();
      }
      setIsPlaying(false);
    } else {
      if (playerRef.current && typeof playerRef.current.playVideo === "function") {
        playerRef.current.playVideo();
      }
      setIsPlaying(true);
    }
  }, [currentSong, isPlaying]);

  const pause = useCallback(() => {
    if (playerRef.current && typeof playerRef.current.pauseVideo === "function") {
      playerRef.current.pauseVideo();
    }
    setIsPlaying(false);
  }, []);

  const resume = useCallback(() => {
    if (playerRef.current && typeof playerRef.current.playVideo === "function") {
      playerRef.current.playVideo();
    }
    setIsPlaying(true);
  }, []);

  const handleNextSong = useCallback(() => {
    setQueue((prevQueue) => {
      setQueueIndex((prevIndex) => {
        if (prevQueue.length === 0) return 0;
        const nextIndex = (prevIndex + 1) % prevQueue.length;
        const nextTrack = prevQueue[nextIndex];
        if (nextTrack) {
          setCurrentSong(nextTrack);
          setCurrentTime(0);
          setDuration(nextTrack.duration_seconds || 210);
          if (playerRef.current && isPlayerReadyRef.current && typeof playerRef.current.loadVideoById === "function") {
            playerRef.current.loadVideoById({
              videoId: nextTrack.id,
              suggestedQuality: "hd1080",
            });
            if (typeof playerRef.current.setPlaybackQuality === "function") {
              try {
                playerRef.current.setPlaybackQuality("hd1080");
              } catch {}
            }
            playerRef.current.playVideo();
          }
        }
        return nextIndex;
      });
      return prevQueue;
    });
  }, []);

  const handlePrevSong = useCallback(() => {
    if (currentTime > 3) {
      if (playerRef.current && typeof playerRef.current.seekTo === "function") {
        playerRef.current.seekTo(0, true);
      }
      setCurrentTime(0);
      return;
    }

    setQueue((prevQueue) => {
      setQueueIndex((prevIndex) => {
        if (prevQueue.length === 0) return 0;
        const prevIdx = prevIndex > 0 ? prevIndex - 1 : prevQueue.length - 1;
        const prevTrack = prevQueue[prevIdx];
        if (prevTrack) {
          setCurrentSong(prevTrack);
          setCurrentTime(0);
          setDuration(prevTrack.duration_seconds || 210);
          if (playerRef.current && isPlayerReadyRef.current && typeof playerRef.current.loadVideoById === "function") {
            playerRef.current.loadVideoById({
              videoId: prevTrack.id,
              suggestedQuality: "hd1080",
            });
            if (typeof playerRef.current.setPlaybackQuality === "function") {
              try {
                playerRef.current.setPlaybackQuality("hd1080");
              } catch {}
            }
            playerRef.current.playVideo();
          }
        }
        return prevIdx;
      });
      return prevQueue;
    });
  }, [currentTime]);

  // Synchronize browser MediaSession (Lockscreen player on Android, iOS, Windows, macOS)
  useEffect(() => {
    if (typeof window === "undefined" || !("mediaSession" in navigator) || !currentSong) return;

    try {
      navigator.mediaSession.metadata = new window.MediaMetadata({
        title: currentSong.title,
        artist: currentSong.artist_name,
        album: "YTCAT",
        artwork: [
          { src: currentSong.thumbnail, sizes: "128x128", type: "image/jpeg" },
          { src: currentSong.thumbnail, sizes: "256x256", type: "image/jpeg" },
          { src: currentSong.thumbnail, sizes: "512x512", type: "image/jpeg" },
        ],
      });

      navigator.mediaSession.playbackState = isPlaying ? "playing" : "paused";

      navigator.mediaSession.setActionHandler("play", () => {
        if (playerRef.current && typeof playerRef.current.playVideo === "function") {
          playerRef.current.playVideo();
        }
        setIsPlaying(true);
      });
      navigator.mediaSession.setActionHandler("pause", () => {
        if (playerRef.current && typeof playerRef.current.pauseVideo === "function") {
          playerRef.current.pauseVideo();
        }
        setIsPlaying(false);
      });
      navigator.mediaSession.setActionHandler("nexttrack", () => {
        handleNextSong();
      });
      navigator.mediaSession.setActionHandler("previoustrack", () => {
        handlePrevSong();
      });
      navigator.mediaSession.setActionHandler("seekto", (details) => {
        if (details.seekTime !== undefined && details.seekTime !== null) {
          if (playerRef.current && typeof playerRef.current.seekTo === "function") {
            playerRef.current.seekTo(details.seekTime, true);
          }
          setCurrentTime(details.seekTime);
        }
      });
    } catch (err) {
      console.warn("Failed to update MediaSession:", err);
    }
  }, [currentSong, isPlaying, handleNextSong, handlePrevSong]);

  // Update MediaSession playback position
  useEffect(() => {
    if (typeof window === "undefined" || !("mediaSession" in navigator) || !navigator.mediaSession.setPositionState) return;
    if (duration > 0) {
      try {
        navigator.mediaSession.setPositionState({
          duration: duration,
          playbackRate: 1,
          position: Math.min(currentTime, duration),
        });
      } catch {}
    }
  }, [currentTime, duration]);

  const seek = useCallback((timeInSeconds: number) => {
    setCurrentTime(timeInSeconds);
    if (playerRef.current && typeof playerRef.current.seekTo === "function") {
      playerRef.current.seekTo(timeInSeconds, true);
    }
  }, []);

  const setVolume = useCallback((vol: number) => {
    const clamped = Math.max(0, Math.min(1, vol));
    setVolumeState(clamped);
    setIsMuted(clamped === 0);
    if (playerRef.current && typeof playerRef.current.setVolume === "function") {
      playerRef.current.setVolume(clamped * 100);
      if (clamped > 0 && typeof playerRef.current.unMute === "function") {
        playerRef.current.unMute();
      }
    }
  }, []);

  const toggleMute = useCallback(() => {
    setIsMuted((prev) => {
      const nextMuted = !prev;
      if (playerRef.current) {
        if (nextMuted && typeof playerRef.current.mute === "function") {
          playerRef.current.mute();
        } else if (!nextMuted && typeof playerRef.current.unMute === "function") {
          playerRef.current.unMute();
          playerRef.current.setVolume(volume * 100);
        }
      }
      return nextMuted;
    });
  }, [volume]);

  const addToQueue = useCallback((song: Song) => {
    setQueue((prev) => {
      if (prev.some((s) => s.id === song.id)) {
        return prev;
      }
      return [...prev, song];
    });
  }, []);

  const removeFromQueue = useCallback((indexOrId: number | string) => {
    setQueue((prev) => {
      if (typeof indexOrId === "string") {
        return prev.filter((s) => s.id !== indexOrId);
      }
      return prev.filter((_, i) => i !== indexOrId);
    });
  }, []);

  const clearQueue = useCallback(() => {
    setQueue(currentSong ? [currentSong] : []);
    setQueueIndex(0);
  }, [currentSong]);

  const contextValue = useMemo<AudioPlayerContextType>(
    () => ({
      currentSong,
      isPlaying,
      currentTime,
      duration,
      volume,
      isMuted,
      queue,
      queueIndex,
      isBuffering,
      isLyricsOpen,
      openLyrics,
      closeLyrics,
      toggleLyrics,
      setIsLyricsOpen,
      playSong,
      togglePlay,
      pause,
      resume,
      nextSong: handleNextSong,
      prevSong: handlePrevSong,
      seek,
      setVolume,
      toggleMute,
      addToQueue,
      removeFromQueue,
      clearQueue,
    }),
    [
      currentSong,
      isPlaying,
      currentTime,
      duration,
      volume,
      isMuted,
      queue,
      queueIndex,
      isBuffering,
      isLyricsOpen,
      openLyrics,
      closeLyrics,
      toggleLyrics,
      setIsLyricsOpen,
      playSong,
      togglePlay,
      pause,
      resume,
      handleNextSong,
      handlePrevSong,
      seek,
      setVolume,
      toggleMute,
      addToQueue,
      removeFromQueue,
      clearQueue,
    ]
  );

  return (
    <AudioPlayerContext.Provider value={contextValue}>
      {children}
      {/* Hidden driver container for YouTube Audio */}
      <div
        id="yt-audio-driver-wrap"
        style={{
          position: "fixed",
          top: -9999,
          left: -9999,
          width: 1,
          height: 1,
          opacity: 0,
          pointerEvents: "none",
          zIndex: -1,
        }}
        aria-hidden="true"
      >
        <div id="yt-audio-driver" />
      </div>
    </AudioPlayerContext.Provider>
  );
}

export function useAudioPlayer() {
  const context = useContext(AudioPlayerContext);
  if (!context) {
    throw new Error("useAudioPlayer must be used within an AudioPlayerProvider");
  }
  return context;
}
