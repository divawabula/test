import { Suspense, lazy } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AudioPlayerProvider } from "./context/AudioPlayerContext";
import Navbar from "./components/Navbar";
import ChromeAudioAlert from "./components/ChromeAudioAlert";
import AudioPlayer from "./components/AudioPlayer";
import LoadingSkeleton from "./components/LoadingSkeleton";
import { Cat } from "lucide-react";

const HomePage = lazy(() => import("./pages/HomePage"));
const SearchPage = lazy(() => import("./pages/SearchPage"));
const ArtistPage = lazy(() => import("./pages/ArtistPage"));

function PageLoadingFallback() {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
      <LoadingSkeleton count={6} />
    </div>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AudioPlayerProvider>
        <div className="min-h-screen flex flex-col bg-[#F4F4F0] text-black selection:bg-[#FFE600]">
          {/* Main App Header */}
          <Navbar />

          {/* Global Alert: Recommendation to use Google Chrome for audio player */}
          <div className="max-w-5xl mx-auto px-4 sm:px-6 pt-4 w-full">
            <ChromeAudioAlert />
          </div>

          {/* Single Page Content */}
          <main className="flex-1">
            <Suspense fallback={<PageLoadingFallback />}>
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/search" element={<SearchPage />} />
                <Route path="/search/:searchQuery" element={<SearchPage />} />
                <Route path="/artist/:artistId/:slug" element={<ArtistPage />} />
                <Route path="/artist/:idOrName" element={<ArtistPage />} />
                <Route path="*" element={<HomePage />} />
              </Routes>
            </Suspense>
          </main>

          {/* Global Persistent Audio Player */}
          <AudioPlayer />

          {/* Neo-Brutalist Footer */}
          <footer className="border-t-2 border-black bg-white py-6 mb-24 sm:mb-20">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-bold text-neutral-600">
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 bg-[#FFE600] border border-black flex items-center justify-center">
                  <Cat className="w-3.5 h-3.5 text-black" strokeWidth={2.2} />
                </div>
                <span className="text-black font-black uppercase">YTCAT</span>
                <span>•</span>
                <span>2026</span>
              </div>

              <div className="flex items-center gap-4">
                <a href="#top" className="hover:underline hover:text-black">
                  Top Songs
                </a>
                
              </div>
            </div>
          </footer>
        </div>
      </AudioPlayerProvider>
    </BrowserRouter>
  );
}
