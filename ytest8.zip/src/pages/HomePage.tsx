import { useState, useEffect, useCallback, FormEvent } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { Flame, RefreshCw, Music2, Search, X } from "lucide-react";
import { Song, ApiResponse } from "../types";
import SongListItem from "../components/SongListItem";
import LoadingSkeleton from "../components/LoadingSkeleton";
import ErrorMessage from "../components/ErrorMessage";
import SEO from "../components/SEO";
import SearchAutocomplete from "../components/SearchAutocomplete";
import { getClientCache, setClientCache } from "../utils/apiCache";
import { apiFetch } from "../utils/apiClient";
import { getSearchNavigationUrl, isYouTubeUrl } from "../utils/youtube";

const HOME_CACHE_KEY = "/api/home";

export default function HomePage() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  // Redirect legacy /?q=... to /search?q=...
  const queryParam = searchParams.get("q");
  useEffect(() => {
    if (queryParam) {
      navigate(`/search?q=${encodeURIComponent(queryParam)}`, { replace: true });
    }
  }, [queryParam, navigate]);

  // Hero search bar input state
  const [searchInput, setSearchInput] = useState("");

  // Top Songs state
  const [topSongs, setTopSongs] = useState<Song[]>(() => {
    const cached = getClientCache<Song[]>(HOME_CACHE_KEY, 300_000);
    return cached || [];
  });
  const [loadingTop, setLoadingTop] = useState<boolean>(() => topSongs.length === 0);
  const [topError, setTopError] = useState<string | null>(null);

  // Fetch Top Songs
  const fetchTopSongs = useCallback(async (isRefresh = false) => {
    const cached = getClientCache<Song[]>(HOME_CACHE_KEY, 300_000);
    if (cached && cached.length > 0 && !isRefresh) {
      setTopSongs(cached);
      setLoadingTop(false);
      return;
    }

    setLoadingTop(true);
    setTopError(null);

    try {
      const json = await apiFetch<ApiResponse<Song[]>>("/api/home", {
        skipDedupe: isRefresh,
      });
      if (json && json.success && Array.isArray(json.data)) {
        const filtered = json.data.filter((s) => s.type?.toLowerCase() === "song").slice(0, 25);
        setTopSongs(filtered);
        setClientCache(HOME_CACHE_KEY, filtered);
      } else {
        throw new Error((json && json.error) || "Failed to retrieve top songs");
      }
    } catch (err: any) {
      console.error("Failed to fetch top songs:", err);
      setTopError(err.message || "Failed to load top songs");
    } finally {
      setLoadingTop(false);
    }
  }, []);

  useEffect(() => {
    fetchTopSongs(false);
  }, [fetchTopSongs]);

  const handleSearchSubmit = (eOrQuery?: FormEvent | string) => {
    if (eOrQuery && typeof eOrQuery === "object" && "preventDefault" in eOrQuery) {
      eOrQuery.preventDefault();
    }
    const targetQuery = typeof eOrQuery === "string" ? eOrQuery : searchInput;
    const clean = targetQuery.trim();
    if (clean) {
      navigate(getSearchNavigationUrl(clean));
    }
  };

  const isYtUrlInput = isYouTubeUrl(searchInput);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-8 pb-32">
      <SEO
        title="YTcat – Play & Download YouTube Music to MP3, M4A, WebM with Lyrics"
        description="Play, stream, and download YouTube songs with synchronized karaoke lyrics. Free online YouTube audio converter to high-quality MP3, M4A, and WebM formats on YTcat."
        canonicalUrl="/"
        type="website"
      />

      {/* Hero & In-Page Search Feature */}
      <section className="mb-6" aria-labelledby="home-hero-heading" id="search-section">
        <div className="border-2 border-black bg-white p-4 sm:p-6 w-full">
          <h1
            id="home-hero-heading"
            className="block text-lg sm:text-xl md:text-2xl lg:text-3xl font-black text-black tracking-tight mb-1.5 break-words"
          >
            Free YouTube Audio Downloader & Player
          </h1>
          <p className="block text-xs sm:text-sm md:text-base font-semibold text-neutral-600 mb-4 leading-relaxed break-words">
            Fast and free online service to stream and download YouTube audio tracks in M4A, WebM, and MP3 formats with synced karaoke lyrics.
          </p>

          {/* Quick Search Form - Navigates to dedicated SearchPage */}
          <form onSubmit={handleSearchSubmit} className="flex flex-col gap-2" id="home-search-form">
            <div className="flex flex-col sm:flex-row gap-2">
              <SearchAutocomplete
                id="home-search-input"
                value={searchInput}
                onChange={setSearchInput}
                onSubmit={(val) => handleSearchSubmit(val)}
                placeholder="Search songs, artists, or paste YouTube link..."
              />

              <button
                type="submit"
                id="home-search-submit-btn"
                className="px-6 py-2.5 bg-[#FFE600] border-2 border-black font-black text-sm hover:bg-black hover:text-[#FFE600] transition-colors flex items-center justify-center gap-2 cursor-pointer active:translate-x-0.5 active:translate-y-0.5"
              >
                <Search className="w-4 h-4" />
                <span>Search</span>
              </button>
            </div>

            {isYtUrlInput && (
              <div className="flex items-center gap-1.5 text-xs font-bold text-black bg-[#F4F4F0] border border-black px-2.5 py-1.5 w-fit" id="home-yt-url-badge">
                <span className="inline-block w-2 h-2 rounded-full bg-red-600 animate-pulse" />
                <span>YouTube link detected • Press <strong>Search</strong> to open song</span>
              </div>
            )}
          </form>
        </div>
      </section>

      {/* Top Songs Header / Controls */}
      <section className="mb-4" aria-label="Top Songs Controls">
        <div className="flex items-center justify-between gap-3 p-3 border-2 border-black bg-white">
          <div className="flex items-center gap-2">
            <h2 className="font-black text-sm sm:text-base text-black">
              Top Songs (Global Charts)
            </h2>
          </div>

          <div className="flex items-center gap-2.5 flex-shrink-0">
            <button
              onClick={() => fetchTopSongs(true)}
              disabled={loadingTop}
              id="refresh-songs-btn"
              aria-label="Refresh top songs"
              title="Refresh top songs"
              className="p-1.5 border-2 border-black bg-white hover:bg-neutral-100 disabled:opacity-50 cursor-pointer transition-transform active:translate-x-0.5 active:translate-y-0.5"
            >
              <RefreshCw className={`w-4 h-4 ${loadingTop ? "animate-spin" : ""}`} />
            </button>
          </div>
        </div>
      </section>

      {/* Top Songs List */}
      <main id="song-list-container">
        {loadingTop && <LoadingSkeleton count={8} />}

        {topError && !loadingTop && (
          <ErrorMessage
            message={topError}
            onRetry={() => fetchTopSongs(true)}
          />
        )}

        {!loadingTop && !topError && topSongs.length === 0 && (
          <div className="p-10 border-2 border-black bg-white text-center">
            <Music2 className="w-12 h-12 mx-auto text-neutral-400 mb-3" />
            <h3 className="text-lg font-black uppercase mb-1">
              No Songs Available
            </h3>
            <p className="text-sm font-semibold text-neutral-600 mb-4">
              Failed to load top songs. Please try refreshing.
            </p>
            <button
              onClick={() => fetchTopSongs(true)}
              className="px-4 py-2 border-2 border-black bg-[#FFE600] font-black text-sm cursor-pointer hover:bg-black hover:text-[#FFE600]"
            >
              Refresh
            </button>
          </div>
        )}

        {!loadingTop && !topError && topSongs.length > 0 && (
          <div className="space-y-2.5" role="feed" aria-label="Top Songs List">
            {topSongs.map((song, index) => (
              <SongListItem
                key={song.id}
                song={song}
                index={index}
                playlistQueue={topSongs}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
