import React, { useEffect, useState, useCallback, useMemo } from "react";
import { useParams, Link } from "react-router-dom";
import {
  Shuffle,
  Share2,
  Check,
  ArrowLeft,
  Disc,
  Cat,
  AlertCircle,
  Music2,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { ArtistDetail } from "../types";
import { useAudioPlayer } from "../context/AudioPlayerContext";
import SongListItem from "../components/SongListItem";
import LoadingSkeleton from "../components/LoadingSkeleton";
import SEO from "../components/SEO";
import { getArtistUrl } from "../utils/seo";
import { apiFetch } from "../utils/apiClient";

// Client-side cache to make back/forward navigation instant without re-fetching
const artistClientCache = new Map<string, ArtistDetail>();

export default function ArtistPage() {
  const { artistId, idOrName, slug } = useParams<{ artistId?: string; idOrName?: string; slug?: string }>();
  const targetId = artistId || idOrName || "";
  const { playSong } = useAudioPlayer();

  const [artist, setArtist] = useState<ArtistDetail | null>(() => {
    if (!targetId) return null;
    return artistClientCache.get(targetId.toLowerCase()) || null;
  });
  const [loading, setLoading] = useState<boolean>(() => !artist);
  const [error, setError] = useState<string | null>(null);
  const [showFullDesc, setShowFullDesc] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  const fetchArtist = useCallback(async (param: string) => {
    const cached = artistClientCache.get(param.toLowerCase());
    if (cached) {
      setArtist(cached);
      setLoading(false);
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const json = await apiFetch<any>(`/api/artist/${encodeURIComponent(param)}`);

      if (!json || !json.success || !json.data) {
        throw new Error((json && json.error) || "Failed to load artist profile");
      }

      const data: ArtistDetail = json.data;
      setArtist(data);
      artistClientCache.set(param.toLowerCase(), data);
      if (data.id) artistClientCache.set(data.id.toLowerCase(), data);
      if (data.name) artistClientCache.set(data.name.toLowerCase(), data);
    } catch (err: any) {
      console.error("Error fetching artist:", err);
      setError(err.message || "An error occurred while loading artist");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (targetId) {
      fetchArtist(targetId);
    }
  }, [targetId, fetchArtist]);

  // Update document title for Client-Side SEO
  useEffect(() => {
    if (artist) {
      document.title = `Download Song ${artist.name} Full Album Mp3 M4a Webm | YTcat`;
    } else {
      document.title = "Download Song Artist Full Album Mp3 M4a Webm | YTcat";
    }
  }, [artist]);

  // Only display tracks with type === "song"
  const songs = useMemo(() => {
    return (artist?.songs || []).filter((s) => s.type?.toLowerCase() === "song");
  }, [artist]);

  // Play songs in shuffled order
  const handleShuffle = () => {
    if (!songs || songs.length === 0) return;
    const shuffled = [...songs].sort(() => Math.random() - 0.5);
    playSong(shuffled[0], shuffled);
  };

  // Copy artist page link with clean canonical URL
  const handleShare = () => {
    const shareUrl = artist
      ? `${window.location.origin}${getArtistUrl(artist.id, artist.name)}`
      : window.location.href;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(shareUrl).then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 2500);
      });
    }
  };

  const canonicalUrl = artist
    ? getArtistUrl(artist.id, artist.name)
    : targetId ? `/artist/${encodeURIComponent(targetId)}` : "/";

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6 pb-32">
      <SEO
        title={
          artist
            ? `Download Song ${artist.name} Full Album Mp3 M4a Webm | YTcat`
            : "Download Song Artist Full Album Mp3 M4a Webm | YTcat"
        }
        description={
          artist
            ? `Download song ${artist.name} full album in MP3, M4A, and WebM format with synchronized lyrics and fast playback on YTcat.`
            : "Download song full album in MP3, M4A, and WebM on YTcat."
        }
        canonicalUrl={canonicalUrl}
        image={artist?.thumbnail}
        type="music.song"
      />

      {/* 1. Breadcrumb Navigation for SEO & Accessibility */}
      <nav aria-label="Breadcrumb" className="flex items-center gap-2 text-xs font-bold text-neutral-600">
        <Link
          to="/"
          className="inline-flex items-center gap-1 hover:text-black hover:underline transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Home</span>
        </Link>
        {artist && (
          <>
            <span>/</span>
            <span className="text-black font-black truncate max-w-[200px] sm:max-w-md">
              {artist.name}
            </span>
          </>
        )}
      </nav>

      {/* 2. Loading Skeleton State */}
      {loading && (
        <div className="space-y-6 animate-pulse" aria-busy="true" aria-label="Loading artist profile...">
          {/* Header Skeleton */}
          <div className="border-2 border-black bg-white p-6 flex flex-col sm:flex-row items-center sm:items-start gap-6">
            <div className="w-28 h-28 sm:w-36 sm:h-36 bg-neutral-200 border-2 border-black flex-shrink-0" />
            <div className="flex-1 space-y-3 w-full text-center sm:text-left">
              <div className="h-8 bg-neutral-200 border border-black w-3/4 mx-auto sm:mx-0" />
              <div className="h-4 bg-neutral-200 border border-black w-1/3 mx-auto sm:mx-0" />
              <div className="h-12 bg-neutral-100 border border-black w-full" />
              <div className="flex gap-3 justify-center sm:justify-start pt-2">
                <div className="h-10 w-28 bg-neutral-200 border border-black" />
                <div className="h-10 w-28 bg-neutral-200 border border-black" />
              </div>
            </div>
          </div>

          {/* Song Skeletons matching Home */}
          <LoadingSkeleton count={6} />
        </div>
      )}

      {/* 3. Error State */}
      {!loading && error && (
        <div
          role="alert"
          className="border-2 border-black bg-[#FFE5E5] p-6 text-center space-y-4"
        >
          <div className="inline-flex p-3 bg-red-500 text-white border-2 border-black">
            <AlertCircle className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-black text-black uppercase">Failed to Load Artist</h2>
          <p className="text-sm font-semibold text-neutral-800 max-w-md mx-auto">{error}</p>
          <div className="flex items-center justify-center gap-3 pt-2">
            <button
              onClick={() => idOrName && fetchArtist(idOrName)}
              className="px-4 py-2 border-2 border-black bg-[#FFE600] font-black text-xs uppercase hover:bg-black hover:text-[#FFE600] transition-colors cursor-pointer active:translate-x-0.5 active:translate-y-0.5"
            >
              Try Again
            </button>
            <Link
              to="/"
              className="px-4 py-2 border-2 border-black bg-white font-black text-xs uppercase hover:bg-black hover:text-white transition-colors cursor-pointer"
            >
              Back to Home
            </Link>
          </div>
        </div>
      )}

      {/* 4. Loaded Artist Profile & Catalog */}
      {!loading && artist && (
        <div className="space-y-6">
          {/* Artist Hero Profile Card */}
          <header className="border-2 border-black bg-white overflow-hidden">
            <div className="p-6 sm:p-8 flex flex-col sm:flex-row items-center sm:items-start gap-6">
              {/* High-res Avatar */}
              <div className="relative flex-shrink-0">
                <img
                  src={artist.thumbnail}
                  alt={`Profile photo of ${artist.name}`}
                  className="w-28 h-28 sm:w-36 sm:h-36 object-cover border-2 border-black bg-neutral-100"
                  loading="eager"
                  decoding="async"
                  width={144}
                  height={144}
                  onError={(e) => {
                    (e.target as HTMLImageElement).src =
                      "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=200&auto=format&fit=crop&q=80";
                  }}
                />
                <div className="absolute -bottom-2 -right-2 bg-[#FFE600] text-black border-2 border-black p-1">
                  <Cat className="w-4 h-4" strokeWidth={2.2} />
                </div>
              </div>

              {/* Artist Info & Meta */}
              <div className="flex-1 text-center sm:text-left min-w-0 space-y-3">
                <h1 className="text-2xl sm:text-4xl font-black text-black uppercase tracking-tight break-words">
                  {artist.name}
                </h1>

                {/* Description if present */}
                {artist.description && (
                  <div className="text-xs sm:text-sm font-semibold text-neutral-700 max-w-2xl text-left bg-neutral-50 p-3 border-2 border-black">
                    <p className={showFullDesc ? "" : "line-clamp-2"}>
                      {artist.description}
                    </p>
                    {artist.description.length > 120 && (
                      <button
                        onClick={() => setShowFullDesc(!showFullDesc)}
                        className="text-xs font-black text-black underline mt-1 inline-flex items-center gap-0.5 cursor-pointer"
                      >
                        <span>{showFullDesc ? "Show Less" : "Read More"}</span>
                        {showFullDesc ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                      </button>
                    )}
                  </div>
                )}

                {/* Quick Actions Bar */}
                <div className="flex items-center justify-center sm:justify-start gap-2 sm:gap-3 pt-2 flex-wrap">
                  {/* Shuffle */}
                  <button
                    onClick={handleShuffle}
                    id="artist-shuffle-btn"
                    disabled={songs.length === 0}
                    className="px-3.5 py-2 bg-white text-black border-2 border-black font-black text-xs sm:text-sm uppercase flex items-center gap-1.5 hover:bg-black hover:text-white transition-transform active:translate-x-0.5 active:translate-y-0.5 cursor-pointer disabled:opacity-50"
                  >
                    <Shuffle className="w-4 h-4" />
                    
                  </button>

                  {/* Share Link */}
                  <button
                    onClick={handleShare}
                    id="artist-share-btn"
                    title="Copy Artist Page Link"
                    className="px-3 py-2 bg-white text-black border-2 border-black font-black text-xs uppercase flex items-center gap-1.5 hover:bg-black hover:text-white transition-transform active:translate-x-0.5 active:translate-y-0.5 cursor-pointer"
                  >
                    {copied ? (
                      <>
                        <Check className="w-4 h-4 text-green-600" />
          
                      </>
                    ) : (
                      <>
                        <Share2 className="w-4 h-4" />
                        
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </header>

          {/* Discography / Song Catalog Section */}
          <section aria-label={`Song list for ${artist.name}`} className="space-y-4">
            {/* Songs List */}
            {songs.length === 0 ? (
              <div className="p-10 border-2 border-black bg-white text-center">
                <Music2 className="w-12 h-12 mx-auto text-neutral-400 mb-3" />
                <h3 className="text-lg font-black uppercase mb-1">
                  No Songs Available
                </h3>
                <p className="text-sm font-semibold text-neutral-600">
                  No songs are currently available for this artist.
                </p>
              </div>
            ) : (
              <div id="artist-songs-list" className="space-y-2.5" role="feed" aria-label="Songs List">
                {songs.map((song, index) => (
                  <SongListItem
                    key={song.id}
                    song={song}
                    index={index}
                    playlistQueue={songs}
                  />
                ))}
              </div>
            )}
          </section>
        </div>
      )}
    </div>
  );
}
