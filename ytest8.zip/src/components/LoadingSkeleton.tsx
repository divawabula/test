export default function LoadingSkeleton({ count = 8 }: { count?: number }) {
  return (
    <div className="space-y-3" role="status" aria-label="Loading songs">
      {Array.from({ length: count }).map((_, i) => (
        <div
          key={i}
          className="flex items-center justify-between p-3.5 sm:p-4 border-2 border-black bg-white animate-pulse"
        >
          <div className="flex items-center gap-3 sm:gap-4 flex-1">
            <div className="w-12 h-12 sm:w-14 sm:h-14 bg-neutral-200 border-2 border-black flex-shrink-0" />
            <div className="flex-1 space-y-2 pr-4">
              <div className="h-4 bg-neutral-300 border border-black w-3/5" />
              <div className="h-3 bg-neutral-200 border border-neutral-400 w-2/5" />
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-12 h-4 bg-neutral-200 border border-black hidden sm:block" />
            <div className="w-8 h-8 bg-neutral-200 border-2 border-black" />
          </div>
        </div>
      ))}
      <span className="sr-only">Loading songs...</span>
    </div>
  );
}
