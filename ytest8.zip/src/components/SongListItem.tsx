import React, { memo, useState } from "react";
import { Link } from "react-router-dom";
import { Play, Pause, Disc, User, Clock, Download, ExternalLink } from "lucide-react";
import { Song } from "../types";
import { useAudioPlayer } from "../context/AudioPlayerContext";
import { formatThumbnailUrl } from "../utils/thumbnail";
import DownloadCard from "./DownloadCard";
import { getArtistUrl } from "../utils/seo";

interface SongListItemProps {
  key?: string | number;
  song: Song;
  index?: number;
  playlistQueue?: Song[];
}

function SongListItemComponent({ song, playlistQueue }: SongListItemProps) {
  const { currentSong, isPlaying, playSong, togglePlay } = useAudioPlayer();
  const [showDownloadCard, setShowDownloadCard] = useState<boolean>(false);

  const isCurrent = currentSong?.id === song.id;
  const isCurrentPlaying = isCurrent && isPlaying;

  const handlePlayAction = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    if (isCurrent) {
      togglePlay();
    } else {
      playSong(song, playlistQueue);
    }
  };

  const handleToggleDownload = (e: React.MouseEvent) => {
    e.stopPropagation();
    setShowDownloadCard((prev) => !prev);
  };

  return (
    <div className="flex flex-col">
      <div
        id={`song-item-${song.id}`}
        className={`group relative flex items-center justify-between p-2.5 sm:p-3.5 border-2 border-black transition-all ${
          isCurrent ? "bg-[#FFE600]" : "bg-white"
        }`}
      >
        {/* Left side: Cover, Titles */}
        <div className="flex items-center gap-3 sm:gap-4 min-w-0 flex-1">
          {/* Thumbnail with Play Overlay */}
          <div className="relative w-12 h-12 sm:w-14 sm:h-14 flex-shrink-0 border-2 border-black bg-neutral-200 overflow-hidden">
            <img
              src={formatThumbnailUrl(song.thumbnail, 100, 100)}
              alt={`Cover art for ${song.title} by ${song.artist_name}`}
              className="w-full h-full object-cover"
              loading="lazy"
              decoding="async"
              width={56}
              height={56}
              onError={(e) => {
                (e.target as HTMLImageElement).src =
                  "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=120&auto=format&fit=crop&q=80";
              }}
            />
            <button
              type="button"
              onClick={handlePlayAction}
              id={`play-overlay-btn-${song.id}`}
              aria-label={isCurrentPlaying ? `Pause ${song.title}` : `Play ${song.title}`}
              className={`absolute inset-0 flex items-center justify-center bg-black/60 transition-opacity cursor-pointer ${
                isCurrent ? "opacity-100" : "opacity-0 group-hover:opacity-100"
              }`}
            >
              {isCurrentPlaying ? (
                <Pause className="w-6 h-6 text-[#FFE600] fill-current" />
              ) : (
                <Play className="w-6 h-6 text-white fill-current ml-0.5" />
              )}
            </button>

            {/* Mobile Duration inside Cover Art at the bottom */}
            {song.duration && (
              <span
                className="sm:hidden absolute bottom-0 inset-x-0 bg-black/85 text-white text-[9px] font-black text-center py-0.5 leading-none tracking-tight pointer-events-none z-10"
                aria-label={`Duration: ${song.duration}`}
              >
                {song.duration}
              </span>
            )}
          </div>

          {/* Song Info */}
          <div className="min-w-0 flex-1 pr-2">
            <div className="flex items-center gap-2">
              <span
                onClick={(e) => {
                  e.stopPropagation();
                  handlePlayAction();
                }}
                className="font-black text-sm sm:text-base text-black truncate hover:underline hover:text-neutral-800 cursor-pointer"
                title={`Play ${song.title}`}
              >
                {song.title}
              </span>
            </div>

            <div className="flex items-center gap-2 text-xs sm:text-sm font-semibold text-neutral-700 mt-0.5 min-w-0 overflow-hidden">
              <Link
                to={getArtistUrl(song.artist_id || song.artists?.[0]?.id, song.artist_name)}
                onClick={(e) => e.stopPropagation()}
                title={`View artist profile for ${song.artist_name}`}
                className="group/artist truncate flex-shrink-0 max-w-[190px] sm:max-w-[260px] inline-flex items-center gap-1 text-neutral-800 hover:text-black hover:underline transition-colors"
              >
                <User className="w-3 h-3 flex-shrink-0 text-neutral-500 group-hover/artist:text-black transition-colors" />
                <span className="truncate">{song.artist_name}</span>
                <ExternalLink className="w-3 h-3 flex-shrink-0 text-neutral-500 group-hover/artist:text-black transition-colors" />
              </Link>

              {song.album && song.album.name ? (
                <div className="hidden sm:inline-flex items-center gap-1.5 text-neutral-600 truncate min-w-0">
                  <span className="text-neutral-400 flex-shrink-0">•</span>
                  <Disc className="w-3 h-3 flex-shrink-0 text-neutral-400" />
                  <span className="truncate max-w-[180px] md:max-w-[260px]" title={song.album.name}>
                    {song.album.name}
                  </span>
                </div>
              ) : null}
            </div>
          </div>
        </div>

        {/* Right side: Duration, Play action, and Download button */}
        <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
          <div className="hidden sm:flex items-center gap-1 text-xs font-bold text-neutral-600 mr-1">
            <Clock className="w-3.5 h-3.5 text-neutral-400" />
            <span>{song.duration}</span>
          </div>

          {/* Play Button */}
          <button
            onClick={handlePlayAction}
            id={`play-btn-${song.id}`}
            aria-label={isCurrentPlaying ? `Pause ${song.title}` : `Play ${song.title}`}
            title={isCurrentPlaying ? "Pause" : "Play"}
            className={`p-2 border-2 border-black font-black text-xs transition-transform active:translate-x-0.5 active:translate-y-0.5 cursor-pointer ${
              isCurrentPlaying
                ? "bg-black text-[#FFE600]"
                : "bg-[#FFE600] text-black hover:bg-black hover:text-white"
            }`}
          >
            {isCurrentPlaying ? <Pause className="w-4 h-4 fill-current" /> : <Play className="w-4 h-4 fill-current" />}
          </button>

          {/* Download Button Icon beside the Play Button (Toggles Card below) */}
          <button
            type="button"
            onClick={handleToggleDownload}
            id={`download-btn-${song.id}`}
            aria-label={`Download ${song.title}`}
            aria-expanded={showDownloadCard}
            title={showDownloadCard ? "Close download panel" : `Open download options for ${song.title}`}
            className={`p-2 border-2 border-black font-black text-xs transition-colors flex items-center justify-center cursor-pointer active:translate-x-0.5 active:translate-y-0.5 ${
              showDownloadCard
                ? "bg-black text-[#FFE600]"
                : "bg-white text-black hover:bg-black hover:text-[#FFE600]"
            }`}
          >
            <Download className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Expandable Download Card right below the selected list item */}
      {showDownloadCard && (
        <DownloadCard
          song={song}
          onClose={() => setShowDownloadCard(false)}
        />
      )}
    </div>
  );
}

export default memo(SongListItemComponent);
