import { useEffect } from "react";
import { useLocation } from "react-router-dom";

interface SEOProps {
  title: string;
  description: string;
  keywords?: string;
  image?: string;
  type?: "website" | "music.song" | "profile" | "music.group";
  jsonLd?: Record<string, any> | Record<string, any>[];
  canonicalUrl?: string;
}

export default function SEO({
  title,
  description,
  keywords = "YTcat, play youtube music, download youtube songs, youtube music downloader, convert youtube to mp3, convert youtube to m4a, convert youtube to webm, youtube lyrics, synced karaoke lyrics, free music stream",
  image = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=1200&auto=format&fit=crop&q=80",
  type = "website",
  jsonLd,
  canonicalUrl,
}: SEOProps) {
  const location = useLocation();

  useEffect(() => {
    // Dynamic Title
    const formattedTitle = title.includes("YTcat")
      ? title
      : `${title} | YTcat`;
    document.title = formattedTitle;

    const origin = window.location.origin;
    const finalCanonical = canonicalUrl
      ? canonicalUrl.startsWith("http")
        ? canonicalUrl
        : `${origin}${canonicalUrl}`
      : `${origin}${location.pathname}${location.search}`;

    // Helper to set or create meta tag
    const setMetaTag = (attributeName: string, attributeValue: string, content: string) => {
      let element = document.querySelector(`meta[${attributeName}="${attributeValue}"]`);
      if (!element) {
        element = document.createElement("meta");
        element.setAttribute(attributeName, attributeValue);
        document.head.appendChild(element);
      }
      element.setAttribute("content", content);
    };

    // Description & Keywords
    setMetaTag("name", "description", description);
    setMetaTag("name", "keywords", keywords);

    // Canonical
    let canonical = document.querySelector('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement("link");
      canonical.setAttribute("rel", "canonical");
      document.head.appendChild(canonical);
    }
    canonical.setAttribute("href", finalCanonical);

    // Open Graph
    setMetaTag("property", "og:title", formattedTitle);
    setMetaTag("property", "og:description", description);
    setMetaTag("property", "og:type", type);
    setMetaTag("property", "og:url", finalCanonical);
    setMetaTag("property", "og:image", image);
    setMetaTag("property", "og:site_name", "YTcat");

    // Twitter Card
    setMetaTag("name", "twitter:card", "summary_large_image");
    setMetaTag("name", "twitter:title", formattedTitle);
    setMetaTag("name", "twitter:description", description);
    setMetaTag("name", "twitter:image", image);

    // Structured Data JSON-LD
    const jsonLdScriptId = "app-seo-jsonld";
    let scriptTag = document.getElementById(jsonLdScriptId) as HTMLScriptElement | null;
    if (!scriptTag) {
      scriptTag = document.createElement("script");
      scriptTag.id = jsonLdScriptId;
      scriptTag.type = "application/ld+json";
      document.head.appendChild(scriptTag);
    }

    const defaultSchemas = [
      {
        "@context": "https://schema.org",
        "@type": "WebApplication",
        name: "YTcat",
        alternateName: "YTcat Music Hub",
        applicationCategory: "MusicApplication",
        operatingSystem: "All",
        description: description,
        url: origin,
        offers: {
          "@type": "Offer",
          price: "0",
          priceCurrency: "USD",
        },
        featureList: [
          "Play YouTube Music",
          "Synchronized Karaoke Lyrics",
          "YouTube to MP3 Converter",
          "YouTube to M4A Converter",
          "YouTube to WebM Converter",
          "Artist Discography",
          "High Quality Audio Streaming",
        ],
      },
      {
        "@context": "https://schema.org",
        "@type": "WebSite",
        name: "YTcat",
        url: origin,
        potentialAction: {
          "@type": "SearchAction",
          target: `${origin}/search?q={search_term_string}`,
          "query-input": "required name=search_term_string",
        },
      },
    ];

    scriptTag.textContent = JSON.stringify(jsonLd || defaultSchemas);
  }, [title, description, keywords, image, type, jsonLd, canonicalUrl, location]);

  return null;
}
