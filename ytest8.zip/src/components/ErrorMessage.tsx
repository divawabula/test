import { AlertTriangle, RefreshCw } from "lucide-react";

interface ErrorMessageProps {
  message?: string;
  onRetry?: () => void;
}

export default function ErrorMessage({
  message = "Failed to load music data. Please try again.",
  onRetry,
}: ErrorMessageProps) {
  return (
    <div
      role="alert"
      className="p-6 border-2 border-black bg-[#FF5E5B] text-black text-center my-6 max-w-xl mx-auto"
    >
      <div className="flex items-center justify-center gap-2 font-black text-lg mb-2">
        <AlertTriangle className="w-6 h-6 text-black stroke-[2.5]" />
        <span>Connection Error</span>
      </div>
      <p className="text-sm font-semibold mb-4">{message}</p>
      {onRetry && (
        <button
          onClick={onRetry}
          className="inline-flex items-center gap-2 px-5 py-2.5 bg-white border-2 border-black font-black text-sm hover:bg-black hover:text-white transition-colors cursor-pointer"
        >
          <RefreshCw className="w-4 h-4" />
          <span>Try Again</span>
        </button>
      )}
    </div>
  );
}
