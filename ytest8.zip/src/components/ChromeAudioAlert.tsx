import { useState } from "react";
import { Chrome, X } from "lucide-react";

export default function ChromeAudioAlert() {
  const [dismissed, setDismissed] = useState<boolean>(() => {
    try {
      return localStorage.getItem("dismissed_chrome_audio_alert") === "true";
    } catch {
      return false;
    }
  });

  const handleDismiss = () => {
    setDismissed(true);
    try {
      localStorage.setItem("dismissed_chrome_audio_alert", "true");
    } catch {
      // ignore
    }
  };

  if (dismissed) return null;

  return (
    <div
      id="chrome-audio-alert-card"
      role="alert"
      aria-live="polite"
      className="border-2 border-black bg-[#FFE600] text-black px-3.5 sm:px-4 py-2 sm:py-2.5 flex items-center justify-between gap-3 transition-all"
    >
      <div className="flex items-center gap-2.5 min-w-0">
        <div className="w-6 h-6 bg-white border-2 border-black flex items-center justify-center shrink-0">
          <Chrome className="w-3.5 h-3.5 text-black" />
        </div>
        <p className="text-xs sm:text-sm font-black leading-snug">
          Use Google Chrome browser for optimal performance and smooth playback of the audio player.
        </p>
      </div>

      <button
        type="button"
        id="chrome-audio-alert-dismiss-btn"
        onClick={handleDismiss}
        aria-label="Dismiss Chrome notice"
        className="p-1 border border-black bg-white hover:bg-black hover:text-white transition-colors shrink-0 cursor-pointer text-black"
      >
        <X className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}
