export interface ArtistReference {
  id: string | null;
  name: string;
}

export interface AlbumReference {
  id: string | null;
  name: string;
}

export interface Song {
  id: string;
  title: string;
  type: "song" | "video" | string;
  artists: ArtistReference[];
  artist_name: string;
  artist_id: string | null;
  album: AlbumReference | null;
  duration: string;
  duration_seconds: number;
  thumbnail: string;
  year?: string | number | null;
  views?: string | null;
  slug: string;
}

export interface LyricLine {
  time: number;
  text: string;
  romanization?: string;
  translation?: string;
}

export type RomanizationType = "Romaji" | "Pinyin" | "Romanisasi" | "Transliterasi" | "None";

export interface SongLyricsData {
  songId: string;
  trackName: string;
  artistName: string;
  isSynced: boolean;
  lines: LyricLine[];
  plainLyrics: string | null;
  plainRomanization?: string | null;
  plainTranslation?: string | null;
  syncedLyrics: string | null;
  source: string;
  hasRomanization?: boolean;
  romanizationType?: RomanizationType;
  scriptLabel?: string;
  detectedLang?: string;
}

export interface TranslationLanguage {
  code: string;
  name: string;
  nativeName?: string;
  flag?: string;
}

export const SUPPORTED_TRANSLATION_LANGUAGES: TranslationLanguage[] = [
  { code: "id", name: "Indonesian", nativeName: "Indonesia", flag: "🇮🇩" },
  { code: "en", name: "English", nativeName: "English", flag: "🇬🇧" },
  { code: "ja", name: "Japanese", nativeName: "日本語", flag: "🇯🇵" },
  { code: "ko", name: "Korean", nativeName: "한국어", flag: "🇰🇷" },
  { code: "es", name: "Spanish", nativeName: "Español", flag: "🇪🇸" },
  { code: "fr", name: "French", nativeName: "Français", flag: "🇫🇷" },
  { code: "de", name: "German", nativeName: "Deutsch", flag: "🇩🇪" },
  { code: "zh-CN", name: "Chinese (Simplified)", nativeName: "简体中文", flag: "🇨🇳" },
  { code: "zh-TW", name: "Chinese (Traditional)", nativeName: "繁體中文", flag: "🇹🇼" },
  { code: "ar", name: "Arabic", nativeName: "العربية", flag: "🇸🇦" },
  { code: "ru", name: "Russian", nativeName: "Русский", flag: "🇷🇺" },
  { code: "pt", name: "Portuguese", nativeName: "Português", flag: "🇧🇷" },
  { code: "it", name: "Italian", nativeName: "Italiano", flag: "🇮🇹" },
  { code: "nl", name: "Dutch", nativeName: "Nederlands", flag: "🇳🇱" },
  { code: "tr", name: "Turkish", nativeName: "Türkçe", flag: "🇹🇷" },
  { code: "th", name: "Thai", nativeName: "ไทย", flag: "🇹🇭" },
  { code: "vi", name: "Vietnamese", nativeName: "Tiếng Việt", flag: "🇻🇳" },
  { code: "hi", name: "Hindi", nativeName: "हिन्दी", flag: "🇮🇳" },
  { code: "tl", name: "Filipino (Tagalog)", nativeName: "Tagalog", flag: "🇵🇭" },
  { code: "ms", name: "Malay", nativeName: "Bahasa Melayu", flag: "🇲🇾" },
  { code: "jw", name: "Javanese", nativeName: "Basa Jawa", flag: "🇮🇩" },
  { code: "su", name: "Sundanese", nativeName: "Basa Sunda", flag: "🇮🇩" },
  { code: "pl", name: "Polish", nativeName: "Polski", flag: "🇵🇱" },
  { code: "uk", name: "Ukrainian", nativeName: "Українська", flag: "🇺🇦" },
  { code: "sv", name: "Swedish", nativeName: "Svenska", flag: "🇸🇪" },
];

export interface SongDetail extends Song {
  lyrics: string | null;
  lyrics_source: string | null;
  related_songs: Song[];
}

export interface ArtistDetail {
  id: string;
  name: string;
  thumbnail: string;
  banner?: string | null;
  subscribers?: string | null;
  description: string | null;
  slug: string;
  songs: Song[];
  total_songs: number;
}

export interface SearchSongSuggestion {
  id: string;
  title: string;
  artist: string;
  thumbnail: string;
}

export interface SearchSuggestionsData {
  queries: string[];
  songs: SearchSongSuggestion[];
}

export interface ApiResponse<T> {
  success: boolean;
  data: T;
  source?: "cache" | "network";
  total?: number;
  query?: string;
  error?: string;
  detail?: string;
}

export interface AudioPlayerContextType {
  currentSong: Song | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  queue: Song[];
  queueIndex: number;
  isBuffering: boolean;
  playSong: (song: Song, customQueue?: Song[]) => void;
  togglePlay: () => void;
  pause: () => void;
  resume: () => void;
  nextSong: () => void;
  prevSong: () => void;
  seek: (timeInSeconds: number) => void;
  setVolume: (volume: number) => void;
  toggleMute: () => void;
  addToQueue: (song: Song) => void;
  removeFromQueue: (indexOrId: number | string) => void;
  clearQueue: () => void;
}
