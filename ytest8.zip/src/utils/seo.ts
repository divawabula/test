/**
 * Technical SEO URL & Slug Helpers
 * Generates clean, lowercase, hyphen-separated, human-readable slugs and canonical URLs
 */

/**
 * Converts any text into an SEO-friendly URL slug:
 * - Lowercase
 * - Strips Latin combining diacritics while preserving Unicode characters (Japanese, CJK, etc.)
 * - Replaces spaces/underscores/punctuation with single hyphens
 * - Trims leading and trailing hyphens
 */
export function slugify(text?: string | null): string {
  if (!text) return "";
  return text
    .toString()
    .normalize("NFD") // Decompose accented characters (é -> e + accent)
    .replace(/[\u0300-\u036f]/g, "") // Remove Latin combining diacritical marks
    .normalize("NFC") // Recompose Unicode characters (e.g., Japanese dakuten/handakuten)
    .toLowerCase()
    .trim()
    .replace(/[^\p{L}\p{N}\s-]/gu, " ") // Preserve all Unicode letters & numbers across all alphabets
    .replace(/[\s_]+/g, "-") // Replace spaces and underscores with hyphen
    .replace(/-+/g, "-") // Replace multiple consecutive hyphens with single hyphen
    .replace(/^-+|-+$/g, ""); // Trim hyphens from start and end
}

/**
 * Generates an SEO-friendly URL for an Artist:
 * Pattern: /artist/[idartist]/[slug nama artist]
 * User requirement: "di page artist song list berdasarkan id artist. url /artist/[idartist]/[slug nama artist]"
 */
export function getArtistUrl(artistIdOrName?: string | null, artistName?: string | null): string {
  if (!artistIdOrName && !artistName) return "/";

  // If both ID and Name are provided and differ:
  if (artistIdOrName && artistName && artistIdOrName.trim().toLowerCase() !== artistName.trim().toLowerCase()) {
    const cleanId = artistIdOrName.trim();
    const slug = slugify(artistName) || "artist";
    return `/artist/${encodeURIComponent(cleanId)}/${slug}`;
  }

  const value = (artistIdOrName || artistName || "").trim();
  // If the value is a YouTube browse/channel ID (e.g. UC...)
  const isChannelId = /^(UC[a-zA-Z0-9_-]{20,}|FEmusic_[a-zA-Z0-9_-]+)/.test(value);
  if (isChannelId) {
    const slug = slugify(artistName || "") || "artist";
    return `/artist/${encodeURIComponent(value)}/${slug}`;
  }

  // Fallback if only name is available
  const slug = slugify(value) || "artist";
  return `/artist/${slug}`;
}

/**
 * Generates an SEO-friendly URL for a Search query:
 * E.g. /search/lagu-pop-indonesia
 */
export function getSearchUrl(query: string): string {
  const clean = query.trim();
  return `/search/${encodeURIComponent(clean)}`;
}
