/**
 * Checks if the given string resembles a YouTube URL
 */
export function isYouTubeUrl(input?: string | null): boolean {
  if (!input || typeof input !== "string") return false;
  const trimmed = input.trim();
  return /(?:https?:\/\/)?(?:www\.|music\.|m\.)?(?:youtu\.be\/|youtube\.com\/)/i.test(trimmed);
}

/**
 * Extracts an 11-character YouTube video ID from various YouTube URL formats
 * or accepts a direct 11-character video ID.
 */
export function extractYouTubeVideoId(input?: string | null): string | null {
  if (!input || typeof input !== "string") return null;
  const trimmed = input.trim();

  // 1. youtu.be/<id>, shorts/<id>, embed/<id>, v/<id>
  const shortMatch = trimmed.match(
    /(?:youtu\.be\/|youtube\.com\/(?:shorts|embed|v)\/)([a-zA-Z0-9_-]{11})/i
  );
  if (shortMatch && shortMatch[1]) {
    return shortMatch[1];
  }

  // 2. watch?v=<id> or ?v=<id> or &v=<id>
  const watchMatch = trimmed.match(/[?&]v=([a-zA-Z0-9_-]{11})(?:[&?]|$)/i);
  if (watchMatch && watchMatch[1]) {
    return watchMatch[1];
  }

  // 3. Loose URL match
  const generalMatch = trimmed.match(
    /(?:youtu\.be\/|youtube\.com\/).*([a-zA-Z0-9_-]{11})/i
  );
  if (generalMatch && generalMatch[1]) {
    return generalMatch[1];
  }

  // 4. Standalone 11-character ID if it strictly matches YouTube ID format
  if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) {
    return trimmed;
  }

  return null;
}

/**
 * Builds the appropriate navigation path for a search query.
 * Always preserves the exact search terms verbatim (including Japanese, CJK,
 * Unicode scripts, punctuation like "。", quotes, and symbols) using `/search?q=...`.
 */
export function getSearchNavigationUrl(query: string): string {
  const clean = query.trim();
  if (!clean) return "/search";

  return `/search?q=${encodeURIComponent(clean)}`;
}
