/**
 * Utility to format image thumbnails, especially from Google User Content (yt3.googleusercontent.com).
 * Converts dimension parameters (e.g., =w500-h500-l90-rj) to specified dimensions (defaulting to w100-h100).
 */
export function formatThumbnailUrl(
  url?: string | null,
  width = 100,
  height = 100
): string {
  if (!url) {
    return "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=120&auto=format&fit=crop&q=80";
  }

  if (
    url.includes("yt3.googleusercontent.com") ||
    url.includes("googleusercontent.com") ||
    url.includes("ggpht.com")
  ) {
    if (url.includes("=")) {
      return url.replace(/=[^/]*$/, `=w${width}-h${height}-l90-rj`);
    }
    return `${url}=w${width}-h${height}-l90-rj`;
  }

  return url;
}
