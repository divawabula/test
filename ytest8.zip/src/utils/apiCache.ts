/**
 * High-performance client-side in-memory & session SWR cache
 * Enables 0ms page navigation transitions without loading spinners for revisited content.
 */

import { apiFetch } from "./apiClient";

interface CacheItem<T> {
  data: T;
  timestamp: number;
}

const memoryCache = new Map<string, CacheItem<any>>();

export function getClientCache<T>(key: string, maxAgeMs = 300_000): T | null {
  const item = memoryCache.get(key);
  if (!item) return null;

  if (Date.now() - item.timestamp > maxAgeMs) {
    memoryCache.delete(key);
    return null;
  }

  // Prevent serving stale erroneous Unknown responses
  if (
    item.data &&
    typeof item.data === "object" &&
    ((item.data as any).title === "Unknown Title" || (item.data as any).title === "Unknown Track")
  ) {
    memoryCache.delete(key);
    return null;
  }

  return item.data as T;
}

export function setClientCache<T>(key: string, data: T): void {
  // Do not cache incomplete / unknown song details
  if (
    data &&
    typeof data === "object" &&
    ((data as any).title === "Unknown Title" || (data as any).title === "Unknown Track")
  ) {
    return;
  }

  memoryCache.set(key, {
    data,
    timestamp: Date.now(),
  });

  // Limit memory size
  if (memoryCache.size > 200) {
    const oldestKey = memoryCache.keys().next().value;
    if (oldestKey) {
      memoryCache.delete(oldestKey);
    }
  }
}

export async function fetchWithCache<T>(
  url: string,
  options?: {
    maxAgeMs?: number;
    onCachedHit?: (data: T) => void;
  }
): Promise<T> {
  const maxAge = options?.maxAgeMs ?? 300_000;
  const cached = getClientCache<T>(url, maxAge);

  if (cached) {
    if (options?.onCachedHit) {
      options.onCachedHit(cached);
    }
    return cached;
  }

  const json = await apiFetch<any>(url);
  if (json && json.success && json.data) {
    setClientCache(url, json.data);
    return json.data as T;
  }
  throw new Error((json && json.error) || "Failed to fetch data");
}
