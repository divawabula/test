/**
 * Client-side Symmetric Encryption (AES-256-GCM) Utility
 * Powered natively by Web Crypto API (crypto.subtle)
 */

export interface EncryptedPayload {
  encrypted: true;
  algorithm: "AES-256-GCM";
  iv: string; // 12-byte hex
  data: string; // hex (ciphertext + 16-byte auth tag)
  timestamp?: number;
}

export const CLIENT_API_SECRET_KEY =
  (typeof import.meta !== "undefined" && (import.meta as any).env?.VITE_API_ENCRYPTION_KEY) ||
  "ytcat-secure-symmetric-aes256-payload-key-2026";

function hexToBytes(hex: string): Uint8Array {
  const cleanHex = hex.trim();
  const len = cleanHex.length;
  const bytes = new Uint8Array(len / 2);
  for (let i = 0; i < len; i += 2) {
    bytes[i / 2] = parseInt(cleanHex.substring(i, i + 2), 16);
  }
  return bytes;
}

function bytesToHex(bytes: Uint8Array): string {
  let hex = "";
  for (let i = 0; i < bytes.length; i++) {
    hex += bytes[i].toString(16).padStart(2, "0");
  }
  return hex;
}

let cachedCryptoKey: CryptoKey | null = null;

async function getCryptoKey(): Promise<CryptoKey> {
  if (cachedCryptoKey) return cachedCryptoKey;

  const encoder = new TextEncoder();
  const keyBytes = encoder.encode(CLIENT_API_SECRET_KEY);
  const hashBuffer = await window.crypto.subtle.digest("SHA-256", keyBytes);

  cachedCryptoKey = await window.crypto.subtle.importKey(
    "raw",
    hashBuffer,
    { name: "AES-GCM" },
    false,
    ["encrypt", "decrypt"]
  );

  return cachedCryptoKey;
}

/**
 * Checks if an object is an AES-256-GCM encrypted payload.
 */
export function isEncryptedPayload(data: any): data is EncryptedPayload {
  return (
    data !== null &&
    typeof data === "object" &&
    data.encrypted === true &&
    typeof data.iv === "string" &&
    typeof data.data === "string"
  );
}

/**
 * Decrypts an AES-256-GCM encrypted payload in the browser using Web Crypto API.
 */
export async function decryptPayload<T = any>(payload: { iv: string; data: string }): Promise<T> {
  const key = await getCryptoKey();
  const iv = hexToBytes(payload.iv);
  const combined = hexToBytes(payload.data);

  const decryptedBuffer = await window.crypto.subtle.decrypt(
    {
      name: "AES-GCM",
      iv,
      tagLength: 128, // 16-byte authentication tag
    },
    key,
    combined
  );

  const text = new TextDecoder().decode(decryptedBuffer);
  return JSON.parse(text) as T;
}

/**
 * Encrypts data using AES-256-GCM in the browser.
 */
export async function encryptPayload(data: any): Promise<EncryptedPayload> {
  const key = await getCryptoKey();
  const iv = window.crypto.getRandomValues(new Uint8Array(12));
  const plaintext = new TextEncoder().encode(JSON.stringify(data));

  const encryptedBuffer = await window.crypto.subtle.encrypt(
    {
      name: "AES-GCM",
      iv,
      tagLength: 128,
    },
    key,
    plaintext
  );

  return {
    encrypted: true,
    algorithm: "AES-256-GCM",
    iv: bytesToHex(iv),
    data: bytesToHex(new Uint8Array(encryptedBuffer)),
    timestamp: Date.now(),
  };
}
