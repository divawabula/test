import CryptoJS from "crypto-js";

// Master encryption & signing key matching server security
export const API_ENCRYPTION_KEY =
  ((import.meta as any).env?.VITE_API_ENCRYPTION_KEY as string) ||
  "ytcat_sec_99f482a17b8c4d2e_v2_protected";

/**
 * Generate HMAC security headers required to fetch YTCAT protected API endpoints
 */
export function generateSecurityHeaders(urlOrPath: string): Record<string, string> {
  // Extract path portion (e.g. "/api/search?q=test" -> "/api/search")
  let path = urlOrPath;
  try {
    if (urlOrPath.startsWith("http://") || urlOrPath.startsWith("https://")) {
      const parsed = new URL(urlOrPath);
      path = parsed.pathname;
    } else {
      path = urlOrPath.split("?")[0];
    }
  } catch {
    path = urlOrPath.split("?")[0];
  }

  const time = Date.now();
  const token = CryptoJS.HmacSHA256(
    `${path}|${time}`,
    API_ENCRYPTION_KEY
  ).toString();

  return {
    "x-ytcat-token": token,
    "x-ytcat-time": time.toString(),
  };
}

/**
 * Decrypt AES-256 encrypted ciphertext returned by YTCAT API
 */
export function decryptPayload<T = any>(ciphertext: string): T {
  if (!ciphertext || typeof ciphertext !== "string") {
    throw new Error("Invalid ciphertext received from API");
  }

  const bytes = CryptoJS.AES.decrypt(ciphertext, API_ENCRYPTION_KEY);
  const decryptedStr = bytes.toString(CryptoJS.enc.Utf8);

  if (!decryptedStr) {
    throw new Error("Failed to decrypt API response. Decryption key mismatch.");
  }

  return JSON.parse(decryptedStr) as T;
}
