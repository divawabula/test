import { decryptPayload, isEncryptedPayload } from "./crypto";

// In-flight request deduplication map for GET requests.
// Prevents duplicate concurrent network requests caused by React StrictMode,
// parallel component mounts, or rapid re-renders.
const inFlightRequests = new Map<string, Promise<any>>();

export interface ApiFetchOptions extends RequestInit {
  skipDedupe?: boolean;
}

/**
 * Universal API fetcher with automatic AES-256 Symmetric Decryption
 * and automatic in-flight promise deduplication for concurrent GET requests.
 */
export async function apiFetch<T = any>(
  input: RequestInfo | URL,
  init?: ApiFetchOptions
): Promise<T> {
  const method = (init?.method || "GET").toUpperCase();
  const isGet = method === "GET";
  const urlKey = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;

  // If an identical GET request is already in-flight, reuse its active promise
  if (isGet && !init?.skipDedupe && inFlightRequests.has(urlKey)) {
    return inFlightRequests.get(urlKey)!;
  }

  const fetchPromise = (async () => {
    try {
      const res = await fetch(input, init);

      if (!res.ok) {
        try {
          const errorJson = await res.json();
          const decrypted = isEncryptedPayload(errorJson)
            ? await decryptPayload(errorJson)
            : errorJson;
          throw new Error(
            decrypted.error || decrypted.detail || `Request failed with status ${res.status}`
          );
        } catch (parseErr: any) {
          if (parseErr.message && !parseErr.message.includes("status")) {
            throw parseErr;
          }
          throw new Error(`HTTP error ${res.status}`);
        }
      }

      const rawJson = await res.json();

      if (isEncryptedPayload(rawJson)) {
        return await decryptPayload<T>(rawJson);
      }

      return rawJson as T;
    } finally {
      if (isGet) {
        inFlightRequests.delete(urlKey);
      }
    }
  })();

  if (isGet && !init?.skipDedupe) {
    inFlightRequests.set(urlKey, fetchPromise);
  }

  return fetchPromise;
}
