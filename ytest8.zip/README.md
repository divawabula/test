# 🎵 YouTube Music Player

Aplikasi pemutar musik modern berbasis **YouTube Music** dengan gaya desain **Neo-Brutalism**. Aplikasi ini mengintegrasikan frontend React 19 dengan backend hybrid (Node.js Express + Python FastAPI) yang ditenagai oleh pustaka `ytmusicapi` untuk menyajikan lagu-lagu resmi (*official audio tracks*), pencarian cepat, profil artis, lirik lagu, antrean putar (*queue*), dan audio player persisten.

---

## 🚀 Fitur Utama

- **Katalog Top Songs Murni**: Menampilkan daftar lagu teratas global yang difilter khusus untuk tipe `"song"` (audio track resmi), bebas dari klip video musik biasa.
- **Pencarian Cepat (*Instant Search*)**: Cari lagu, artis, atau album dari jutaan katalog YouTube Music secara langsung.
- **Audio Player Persisten**:
  - Pemutar audio tetap aktif dan berjalan mulus saat Anda berpindah antar-halaman.
  - **Volume Default 100%** dengan slider presisi dan tombol mute.
  - Dukungan kontrol playback (Play, Pause, Previous, Next, Shuffle, Repeat).
  - Tampilan **Mobile-Friendly & Responsif**: Judul lagu tetap terbaca utuh tanpa tertutup tombol navigasi.
  - Pengaturan antrean (*Queue List*) interaktif untuk menambah, menghapus, atau melompat ke lagu berikutnya.
- **Halaman Detail Lagu & Lirik**: Tampilkan lirik lagu lengkap jika tersedia serta daftar lagu terkait (*related songs*).
- **Halaman Profil Artis**: Menjelajahi diskografi dan lagu-lagu populer dari penyanyi favorit.
- **Optimasi SEO & Caching**: Dilengkapi in-memory caching pada backend, dynamic sitemap (`/sitemap.xml`), dan robots.txt.

---

## 🏗️ Arsitektur Sistem

Aplikasi ini menggunakan arsitektur *full-stack*:

```text
├── src/                # Frontend React 19 (Vite, Tailwind CSS, Lucide Icons)
│   ├── components/     # AudioPlayer, SongListItem, Header, Skeleton, dll.
│   ├── context/        # AudioPlayerContext (State playback & antrean)
│   ├── pages/          # HomePage, SearchPage, SongDetailPage, ArtistPage
│   └── types.ts        # Definisi antarmuka TypeScript
├── backend/
│   └── api.py          # Microservice Python FastAPI (ytmusicapi & TTL Caching)
├── server.ts           # Server Express utama (Proksi API, spawn Python, SSR/Static)
├── requirements.txt    # Dependensi Python
└── package.json        # Dependensi Node.js
```

---

## 📋 Prasyarat Sistem

Sebelum memulai instalasi, pastikan sistem Anda telah terpasang:

1. **Node.js**: Versi `18.x` atau lebih baru (`node -v`)
2. **NPM** atau **Bun / Yarn / PNPM**: Pengelola paket Node (`npm -v`)
3. **Python**: Versi `3.9` atau lebih baru (`python3 --version`)
4. **Pip**: Pengelola paket Python (`python3 -m pip --version`)

---

## 🛠️ Langkah Penginstalan

### 1. Kloning Repositori
Unduh atau kloning repositori ini ke komputer lokal Anda:
```bash
git clone <URL_REPOSITORI_ANDA>
cd <NAMA_DIREKTORI_PROYEK>
```

### 2. Instal Dependensi Python
Backend pemrosesan musik membutuhkan beberapa pustaka Python (`fastapi`, `uvicorn`, dan `ytmusicapi`):

```bash
# Menggunakan requirements.txt
python3 -m pip install -r requirements.txt
```

*(Opsional - menggunakan Virtual Environment):*
```bash
python3 -m venv venv
source venv/bin/activate  # Di Linux/macOS
# atau: venv\Scripts\activate  (Di Windows)
pip install -r requirements.txt
```

### 3. Instal Dependensi Node.js
Instal semua modul frontend dan server backend:
```bash
npm install
```

### 4. Konfigurasi Lingkungan (Opsional)
Salin berkas konfigurasi contoh jika diperlukan:
```bash
cp .env.example .env
```
*(Catatan: Aplikasi dapat langsung berjalan untuk fitur pemutaran YouTube Music tanpa memerlukan API key eksternal tambahan).*

---

## 💻 Menjalankan Aplikasi

### Mode Pengembangan (Development)
Jalankan perintah berikut:
```bash
npm run dev
```

> **Catatan Alur Otomatis:**
> Perintah `npm run dev` menjalankan `server.ts` yang akan:
> 1. Otomatis menyalakan microservice Python FastAPI di latar belakang pada `http://127.0.0.1:8001`.
> 2. Menjalankan Vite middleware dan server Express pada port `3000`.
> 3. Membuka akses aplikasi di peramban Anda melalui:
>    **`http://localhost:3000`**

### Mode Produksi (Production Build & Start)
Untuk mengompilasi dan menjalankan versi produksi yang dioptimalkan:

```bash
# 1. Kompilasi bundle React dan server Express
npm run build

# 2. Jalankan server produksi
npm run start
```
Aplikasi akan aktif di `http://localhost:3000`.

---

## 📖 Panduan Penggunaan

### 1. Menjelajah & Memutar Lagu
- Buka beranda untuk melihat daftar **Top Songs**.
- Klik tombol **Play** pada cover lagu atau klik baris lagu untuk langsung memutarnya di player bawah.
- Judul lagu dapat diklik untuk membuka halaman detail lengkap dan lirik.
- Nama artis dapat diklik untuk masuk ke halaman profil artis dan mendengarkan katalog lagu lainnya.

### 2. Mencari Lagu
- Gunakan kolom pencarian di bagian atas atau menu **Search**.
- Masukkan judul lagu, nama penyanyi, atau grup musik.
- Hasil pencarian akan langsung muncul; Anda dapat langsung memutar lagu atau menambahkannya ke antrean.

### 3. Mengontrol Audio Player
- **Play / Pause**: Tombol utama berwarna kuning terang di bagian tengah player (atau kanan pada layar mobile).
- **Volume**: Secara default disetel ke **100%**. Anda dapat menggeser slider volume atau menekan ikon speaker untuk Mute/Unmute.
- **Layar Ponsel (Mobile View)**:
  - Tata letak dirancang agar judul lagu tetap tampil jelas tanpa terpotong.
  - Tekan ikon panah (chevron) untuk membuka panel tambahan durasi waktu dan slider volume.
- **Queue (Antrean)**: Tekan tombol **Queue** (ikon daftar musik) untuk melihat daftar lagu yang sedang mengantre, menghapus lagu tertentu, atau melompat ke lagu berikutnya.

---

## 🔌 Dokumentasi Endpoint API

Server menyediakan endpoint API internal yang dapat diakses:

| Metode | Endpoint | Deskripsi |
| :--- | :--- | :--- |
| `GET` | `/api/health` | Status kesehatan server Express dan backend Python |
| `GET` | `/api/home` | Mengambil daftar Top Songs Global resmi |
| `GET` | `/api/search?q=:query` | Mencari lagu berdasarkan kata kunci |
| `GET` | `/api/song/:id` | Detail lagu, lirik, dan rekomendasi terkait |
| `GET` | `/api/artist/:id` | Informasi artis dan daftar lagu populer artis |
| `GET` | `/sitemap.xml` | XML sitemap dinamis untuk optimasi mesin pencari |

---

## ❓ FAQ & Troubleshooting

1. **Error: `python3` atau modul `fastapi` tidak ditemukan saat `npm run dev`**
   - Pastikan Python 3 terinstal dan dapat diakses melalui terminal (`python3 --version`).
   - Jalankan `python3 -m pip install -r requirements.txt`.

2. **Lagu tidak bersuara saat pertama kali diputar di browser?**
   - Kebijakan browser modern membatasi *autoplay* sebelum interaksi pertama pengguna. Cukup klik tombol **Play** atau klik salah satu lagu untuk memulai audio.

3. **Port 3000 atau 8001 sudah digunakan aplikasi lain?**
   - Pastikan tidak ada proses lain yang berjalan di port `3000` (Express) atau port `8001` (Python). Hentikan proses lama atau gunakan port yang tersedia.

---

## 📄 Lisensi
Didistribusikan di bawah lisensi terbuka untuk tujuan eksplorasi dan pengembangan.
