import { Log } from "youtubei.js";
import { getSongDetails, getInnertube } from "./ytmusic";
import { analyzeScript, romanizeTexts, RomanizationType } from "./translation";

// Silence non-fatal YouTubeJS parser warnings
Log.setLevel(Log.Level.ERROR);

export interface LyricLine {
  time: number; // in seconds
  text: string;
  romanization?: string;
}

export interface SongLyricsData {
  songId: string;
  trackName: string;
  artistName: string;
  isSynced: boolean;
  lines: LyricLine[];
  plainLyrics: string | null;
  plainRomanization?: string | null;
  syncedLyrics: string | null;
  source: string;
  hasRomanization?: boolean;
  romanizationType?: RomanizationType;
  scriptLabel?: string;
  detectedLang?: string;
}

async function enrichWithRomanization(lyricsData: SongLyricsData): Promise<SongLyricsData> {
  try {
    const lineTexts = lyricsData.lines.map((l) => l.text);
    const plainLines = lyricsData.plainLyrics ? lyricsData.plainLyrics.split("\n") : [];
    const allTexts = lineTexts.length > 0 ? lineTexts : plainLines;

    const analysis = analyzeScript(allTexts);
    lyricsData.hasRomanization = analysis.hasRomanization;
    lyricsData.romanizationType = analysis.romanizationType;
    lyricsData.scriptLabel = analysis.scriptLabel;
    lyricsData.detectedLang = analysis.detectedLang;

    if (analysis.hasRomanization) {
      if (lyricsData.lines.length > 0) {
        const romanized = await romanizeTexts(lineTexts, analysis);
        for (let i = 0; i < lyricsData.lines.length; i++) {
          lyricsData.lines[i].romanization = romanized[i] || "";
        }
      }
      if (plainLines.length > 0) {
        const romanizedPlain = await romanizeTexts(plainLines, analysis);
        lyricsData.plainRomanization = romanizedPlain.join("\n");
      }
    }
  } catch (err) {
    console.warn("Error enriching lyrics with romanization:", err);
  }
  return lyricsData;
}

// In-Memory cache for lyrics (24 hours fresh)
const lyricsCache = new Map<string, { data: SongLyricsData; timestamp: number }>();

function parseLrc(lrc: string): LyricLine[] {
  if (!lrc) return [];
  const lines = lrc.split("\n");
  const result: LyricLine[] = [];
  const timeRegex = /\[(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?\]/g;

  for (const rawLine of lines) {
    const trimmed = rawLine.trim();
    if (!trimmed) continue;

    const matches = [...trimmed.matchAll(timeRegex)];
    if (matches.length > 0) {
      const text = trimmed.replace(timeRegex, "").trim();
      for (const m of matches) {
        const min = parseInt(m[1], 10);
        const sec = parseInt(m[2], 10);
        const ms = m[3] ? parseFloat("0." + m[3]) : 0;
        const totalSec = min * 60 + sec + ms;
        result.push({ time: totalSec, text });
      }
    }
  }

  return result.sort((a, b) => a.time - b.time);
}

function cleanTitle(title: string): string {
  return (title || "")
    .replace(/\s*[\(\[](official\s*video|official\s*audio|official\s*music\s*video|official|lyrics?|lyric\s*video|mv|visualizer|audio|hd|4k|remix|cover)[\)\]]/gi, "")
    .replace(/\s*[-–|].*$/g, "") // remove trailing "- Official Video", etc.
    .trim();
}

function cleanArtist(artist: string): string {
  return (artist || "")
    .replace(/\s*[\(\[](feat|ft\.).*?[\)\]]/gi, "")
    .replace(/\s*,\s*.*$/g, "") // take primary artist if multiple
    .trim();
}

export async function fetchSongLyrics(
  songId: string,
  rawTrackName?: string,
  rawArtistName?: string,
  durationSeconds?: number
): Promise<SongLyricsData | null> {
  const cleanId = (songId || "").trim();
  if (!cleanId) return null;

  const cacheKey = `lyrics_${cleanId}`;
  const cached = lyricsCache.get(cacheKey);
  if (cached && Date.now() - cached.timestamp < 86_400_000) {
    return cached.data;
  }

  let trackName = rawTrackName || "";
  let artistName = rawArtistName || "";

  // If missing track or artist, fetch details
  if (!trackName || !artistName) {
    try {
      const details = await getSongDetails(cleanId);
      if (details) {
        if (!trackName) trackName = details.title;
        if (!artistName) artistName = details.artist_name;
        if (!durationSeconds && details.duration_seconds) {
          durationSeconds = details.duration_seconds;
        }
      }
    } catch (e) {
      console.warn("Could not fetch song details for lyrics:", e);
    }
  }

  const cleanedTrack = cleanTitle(trackName) || trackName;
  const cleanedArt = cleanArtist(artistName) || artistName;

  // 1. Try LRCLIB exact get
  try {
    const params = new URLSearchParams({
      track_name: cleanedTrack,
      artist_name: cleanedArt,
    });
    if (durationSeconds && durationSeconds > 0) {
      params.append("duration", Math.round(durationSeconds).toString());
    }

    const res = await fetch(`https://lrclib.net/api/get?${params}`, {
      headers: { "User-Agent": "YTcat-Music-Player (https://github.com/)" },
      signal: AbortSignal.timeout(4000),
    });

    if (res.ok) {
      const data: any = await res.json();
      if (data.syncedLyrics || data.plainLyrics) {
        const parsedLines = parseLrc(data.syncedLyrics || "");
        const lyricsData: SongLyricsData = {
          songId: cleanId,
          trackName: data.trackName || trackName,
          artistName: data.artistName || artistName,
          isSynced: parsedLines.length > 0,
          lines: parsedLines,
          plainLyrics: data.plainLyrics || null,
          syncedLyrics: data.syncedLyrics || null,
          source: "lrclib",
        };
        await enrichWithRomanization(lyricsData);
        lyricsCache.set(cacheKey, { data: lyricsData, timestamp: Date.now() });
        return lyricsData;
      }
    }
  } catch (err: any) {
    // Continue to search
  }

  // 2. Try LRCLIB search query
  try {
    const q = `${cleanedTrack} ${cleanedArt}`.trim();
    const res = await fetch(
      `https://lrclib.net/api/search?q=${encodeURIComponent(q)}`,
      {
        headers: { "User-Agent": "YTcat-Music-Player (https://github.com/)" },
        signal: AbortSignal.timeout(4000),
      }
    );

    if (res.ok) {
      const items: any[] = await res.json();
      if (Array.isArray(items) && items.length > 0) {
        // Pick best matching item (prioritize syncedLyrics)
        const best = items.find((it) => it.syncedLyrics) || items[0];
        const parsedLines = parseLrc(best.syncedLyrics || "");
        const lyricsData: SongLyricsData = {
          songId: cleanId,
          trackName: best.trackName || trackName,
          artistName: best.artistName || artistName,
          isSynced: parsedLines.length > 0,
          lines: parsedLines,
          plainLyrics: best.plainLyrics || null,
          syncedLyrics: best.syncedLyrics || null,
          source: "lrclib_search",
        };
        await enrichWithRomanization(lyricsData);
        lyricsCache.set(cacheKey, { data: lyricsData, timestamp: Date.now() });
        return lyricsData;
      }
    }
  } catch (err: any) {
    // Continue to YouTube Music
  }

  // 3. Fallback: YouTube Music getLyrics via Innertube
  try {
    const yt = await getInnertube();
    const ytmLyrics = await yt.music.getLyrics(cleanId);
    const plain = ytmLyrics?.description?.text || ytmLyrics?.description?.toString();
    if (plain) {
      const lyricsData: SongLyricsData = {
        songId: cleanId,
        trackName,
        artistName,
        isSynced: false,
        lines: [],
        plainLyrics: plain,
        syncedLyrics: null,
        source: "ytmusic",
      };
      await enrichWithRomanization(lyricsData);
      lyricsCache.set(cacheKey, { data: lyricsData, timestamp: Date.now() });
      return lyricsData;
    }
  } catch (err: any) {
    // Non-fatal: Lyrics not available on YouTube Music for this track
  }

  return null;
}
