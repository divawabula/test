import { Innertube, Log } from "youtubei.js";
import { Song, ArtistReference, AlbumReference, ArtistDetail } from "../src/types";

// Silence non-fatal YouTubeJS parser warnings (e.g., YouTube returning MessageRenderer for songs without lyrics)
Log.setLevel(Log.Level.ERROR);

// Singleton Innertube instance with promise-deduplication
let innertubeInstance: Innertube | null = null;
let innertubePromise: Promise<Innertube> | null = null;

export async function getInnertube(): Promise<Innertube> {
  if (innertubeInstance) {
    return innertubeInstance;
  }
  if (!innertubePromise) {
    innertubePromise = Innertube.create({
      generate_session_locally: true,
    })
      .then((instance) => {
        innertubeInstance = instance;
        return instance;
      })
      .catch((err) => {
        innertubePromise = null; // allow retry on failure
        throw err;
      });
  }
  return innertubePromise;
}

// In-Memory Stale-While-Revalidate TTL Cache
interface CacheEntry<T> {
  timestamp: number;
  data: T;
  revalidating?: boolean;
}

const cacheStore = new Map<string, CacheEntry<any>>();
const inFlightRequests = new Map<string, Promise<any>>();

/**
 * Deduplicate simultaneous identical in-flight network requests
 */
function dedupeRequest<T>(key: string, fetcher: () => Promise<T>): Promise<T> {
  const existing = inFlightRequests.get(key);
  if (existing) {
    return existing as Promise<T>;
  }

  const promise = fetcher().finally(() => {
    inFlightRequests.delete(key);
  });

  inFlightRequests.set(key, promise);
  return promise;
}

function getFromCache<T>(key: string, ttlSeconds = 300): { data: T; isStale: boolean } | null {
  const entry = cacheStore.get(key);
  if (!entry) return null;

  const ageSeconds = (Date.now() - entry.timestamp) / 1000;
  if (ageSeconds < ttlSeconds) {
    return { data: entry.data as T, isStale: false };
  }
  // Stale-while-revalidate window: allow up to 4x TTL as stale
  if (ageSeconds < ttlSeconds * 4) {
    return { data: entry.data as T, isStale: true };
  }

  cacheStore.delete(key);
  return null;
}

function setToCache<T>(key: string, data: T): void {
  cacheStore.set(key, {
    timestamp: Date.now(),
    data,
    revalidating: false,
  });

  // LRU Prune if cache grows beyond 600 items
  if (cacheStore.size > 600) {
    const now = Date.now();
    let count = 0;
    for (const [k, v] of cacheStore.entries()) {
      if ((now - v.timestamp) / 1000 > 1800 || count > 100) {
        cacheStore.delete(k);
      }
      count++;
    }
  }
}

export function extractYouTubeId(input?: string | null): string | null {
  if (!input || typeof input !== "string") return null;
  const trimmed = input.trim();

  // 1. Short links, shorts, embed, v
  // e.g. youtu.be/<id>, youtube.com/shorts/<id>, youtube.com/embed/<id>, youtube.com/v/<id>
  const shortMatch = trimmed.match(
    /(?:youtu\.be\/|youtube\.com\/(?:shorts|embed|v)\/)([a-zA-Z0-9_-]{11})/i
  );
  if (shortMatch && shortMatch[1]) {
    return shortMatch[1];
  }

  // 2. watch?v=<id> or ?v=<id> or &v=<id>
  const watchMatch = trimmed.match(/[?&]v=([a-zA-Z0-9_-]{11})(?:[&?]|$)/i);
  if (watchMatch && watchMatch[1]) {
    return watchMatch[1];
  }

  // 3. Fallback generic match containing youtu.be or youtube.com with 11-char ID
  const generalMatch = trimmed.match(
    /(?:youtu\.be\/|youtube\.com\/).*([a-zA-Z0-9_-]{11})/i
  );
  if (generalMatch && generalMatch[1]) {
    return generalMatch[1];
  }

  // 4. Standalone 11-character ID if it strictly looks like a video ID
  if (/^[a-zA-Z0-9_-]{11}$/.test(trimmed)) {
    return trimmed;
  }

  return null;
}

export function slugify(text?: string | null): string {
  if (!text) return "";
  return text
    .toString()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .normalize("NFC")
    .toLowerCase()
    .trim()
    .replace(/[^\p{L}\p{N}\s-]/gu, " ")
    .replace(/[\s_]+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-+|-+$/g, "");
}

export function formatYt3Thumbnail(url: string, width = 100, height = 100): string {
  if (!url) return url;
  if (
    url.includes("yt3.googleusercontent.com") ||
    url.includes("googleusercontent.com") ||
    url.includes("ggpht.com")
  ) {
    if (url.includes("=")) {
      return url.replace(/=[^/]*$/, `=w${width}-h${height}-l90-rj`);
    }
    return `${url}=w${width}-h${height}-l90-rj`;
  }
  return url;
}

function getBestThumbnailUrl(
  thumbnails: any[] | undefined,
  videoId?: string,
  targetWidth = 100,
  targetHeight = 100
): string {
  if (Array.isArray(thumbnails) && thumbnails.length > 0) {
    const valid = thumbnails.filter((t) => t && (t.url || typeof t === "string"));
    const validUrls: string[] = valid.map((t) => (typeof t === "string" ? t : t.url));

    // 1. PRIORITIZE yt3.googleusercontent.com (or googleusercontent.com / ggpht.com)
    const yt3Match = validUrls.find(
      (u) =>
        u &&
        (u.includes("yt3.googleusercontent.com") ||
          u.includes("googleusercontent.com") ||
          u.includes("ggpht.com"))
    );

    if (yt3Match) {
      return formatYt3Thumbnail(yt3Match, targetWidth, targetHeight);
    }

    // 2. Otherwise pick the highest resolution
    const sorted = valid.sort((a, b) => (b.width || 0) - (a.width || 0));
    if (sorted[0]?.url) {
      return sorted[0].url;
    }
  }

  if (videoId) {
    return `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;
  }
  return "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=120&auto=format&fit=crop&q=80";
}

function parseDurationSeconds(durationStr?: string): number {
  if (!durationStr || typeof durationStr !== "string" || !durationStr.includes(":")) {
    return 210;
  }
  const parts = durationStr.split(":").map((p) => parseInt(p, 10));
  if (parts.length === 2 && !isNaN(parts[0]) && !isNaN(parts[1])) {
    return parts[0] * 60 + parts[1];
  }
  if (parts.length === 3 && !isNaN(parts[0]) && !isNaN(parts[1]) && !isNaN(parts[2])) {
    return parts[0] * 3600 + parts[1] * 60 + parts[2];
  }
  return 210;
}

function normalizeSongFromItem(item: any): Song | null {
  if (!item) return null;
  const id = item.id || item.video_id || item.videoId || item.endpoint?.payload?.videoId;
  if (!id || typeof id !== "string") return null;

  const rawTitle = item.title?.text || item.title?.toString() || item.name || "Unknown Title";
  const title = String(rawTitle).trim();

  // Filter out unwanted video items if necessary
  const titleLower = title.toLowerCase();
  if (
    titleLower.includes("official music video") ||
    titleLower.includes("official video") ||
    titleLower.includes("video klip") ||
    titleLower.includes("[mv]") ||
    titleLower.includes("(mv)")
  ) {
    // Keep or skip if strictly music tracks are desired
  }

  // Artists extraction
  const rawArtists = item.artists || (item.author ? [item.author] : []);
  const artists: ArtistReference[] = [];

  if (Array.isArray(rawArtists)) {
    for (const a of rawArtists) {
      if (a) {
        const aName = a.name || a.text || (typeof a === "string" ? a : "");
        const cleanName = String(aName).trim();
        if (cleanName && cleanName.toLowerCase() !== "unknown artist") {
          const aId = a.channel_id || a.id || a.endpoint?.payload?.browseId || null;
          artists.push({
            id: aId ? String(aId) : null,
            name: cleanName,
          });
        }
      }
    }
  } else if (typeof rawArtists === "string" && rawArtists.trim() && rawArtists.trim().toLowerCase() !== "unknown artist") {
    artists.push({ id: null, name: rawArtists.trim() });
  }

  // Album extraction
  let album: AlbumReference | null = null;
  if (item.album) {
    const albName = item.album.name || item.album.text || (typeof item.album === "string" ? item.album : null);
    const albId = item.album.id || item.album.endpoint?.payload?.browseId || null;
    if (albName) {
      album = {
        id: albId ? String(albId) : null,
        name: String(albName).trim(),
      };
    }
  }

  // Fallback extraction from flex_columns or subtitle for artists, album, and year
  if (artists.length === 0 || !album) {
    const runsList: any[] = [];
    if (Array.isArray(item.flex_columns) && item.flex_columns.length > 1) {
      for (let i = 1; i < item.flex_columns.length; i++) {
        const col = item.flex_columns[i];
        const colRuns = col?.title?.runs || col?.runs;
        if (Array.isArray(colRuns) && colRuns.length > 0) {
          runsList.push(...colRuns);
          break; // The first non-title column is the primary subtitle line
        }
      }
    }
    if (runsList.length === 0 && Array.isArray(item.subtitle?.runs)) {
      runsList.push(...item.subtitle.runs);
    }

    if (runsList.length > 0) {
      const segments: any[][] = [[]];
      for (const r of runsList) {
        const t = r?.text ? String(r.text) : "";
        if (t === " • " || t.trim() === "•") {
          segments.push([]);
        } else {
          segments[segments.length - 1].push(r);
        }
      }

      let artistSegIndex = 0;
      if (
        segments[0] &&
        segments[0].map((r: any) => r.text).join("").trim().toLowerCase() === "song" &&
        segments.length > 1
      ) {
        artistSegIndex = 1;
      }

      if (artists.length === 0) {
        const artistSeg = segments[artistSegIndex] || [];
        if (artistSeg.length > 0) {
          const segText = artistSeg.map((r: any) => r.text).join("").trim();
          if (
            segText &&
            !/^\d+:\d+(:\d+)?$/.test(segText) &&
            !/\b(plays|views|subscribers)\b/i.test(segText)
          ) {
            const firstRun = artistSeg[0];
            const browseId = firstRun?.endpoint?.payload?.browseId || null;
            artists.push({
              id: browseId ? String(browseId) : null,
              name: segText,
            });
          }
        }
      }

      if (!album) {
        for (let i = 0; i < segments.length; i++) {
          if (i === artistSegIndex) continue;
          const seg = segments[i];
          for (const r of seg) {
            const pageType = r.endpoint?.payload?.browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType;
            const browseId = r.endpoint?.payload?.browseId;
            if (pageType === "MUSIC_PAGE_TYPE_ALBUM" || (browseId && browseId.startsWith("MPREb_"))) {
              const albumName = seg.map((x: any) => x.text).join("").trim();
              if (albumName) {
                album = {
                  id: browseId || null,
                  name: albumName,
                };
              }
              break;
            }
          }
          if (album) break;
        }

        // Secondary fallback for album if no explicit pageType endpoint:
        if (!album && segments.length >= 3 && artistSegIndex === 0) {
          const candSeg = segments[1];
          const candText = candSeg.map((r: any) => r.text).join("").trim();
          if (
            candText &&
            !/^\d+:\d+(:\d+)?$/.test(candText) &&
            !/\b(plays|views|subscribers)\b/i.test(candText) &&
            !/^(19\d\d|20\d\d)$/.test(candText)
          ) {
            album = {
              id: null,
              name: candText,
            };
          }
        }
      }
    }
  }

  const firstArtist = artists[0] || { id: null, name: "Unknown Artist" };
  const artistName = artists.map((a) => a.name).join(", ") || "Unknown Artist";

  // Duration
  let duration = "3:30";
  let durationSeconds = 210;
  if (item.duration) {
    if (typeof item.duration === "object") {
      duration = item.duration.text || item.duration.toString() || "3:30";
      durationSeconds = item.duration.seconds || parseDurationSeconds(duration);
    } else if (typeof item.duration === "string") {
      duration = item.duration;
      durationSeconds = parseDurationSeconds(duration);
    } else if (typeof item.duration === "number") {
      durationSeconds = item.duration;
      const m = Math.floor(durationSeconds / 60);
      const s = durationSeconds % 60;
      duration = `${m}:${s.toString().padStart(2, "0")}`;
    }
  }

  // Year extraction
  let year: string | null = null;
  if (item.year) {
    year = String(item.year).trim();
  } else if (item.album?.year) {
    year = String(item.album.year).trim();
  }

  if (!year && item.flex_columns) {
    for (const col of item.flex_columns) {
      const runs = col?.title?.runs;
      if (Array.isArray(runs)) {
        for (const run of runs) {
          const t = run?.text ? String(run.text).trim() : "";
          if (/^(19\d\d|20\d\d)$/.test(t)) {
            year = t;
            break;
          }
        }
      }
      if (year) break;
    }
  }

  if (!year) {
    const titleMatch = title.match(/\b(19\d\d|20\d\d)\b/);
    if (titleMatch) {
      const yVal = parseInt(titleMatch[1], 10);
      if (yVal >= 1950 && yVal <= 2030) {
        year = titleMatch[1];
      }
    }
  }

  // Thumbnails
  const thumbList = item.thumbnail?.contents || item.thumbnails || (Array.isArray(item.thumbnail) ? item.thumbnail : []);
  const thumbnail = getBestThumbnailUrl(thumbList, id, 100, 100);

  // Detect type: song vs video
  const musicVideoType =
    item.endpoint?.payload?.watchEndpointMusicSupportedConfigs?.watchEndpointMusicConfig?.musicVideoType ||
    item.navigation_endpoint?.payload?.watchEndpointMusicSupportedConfigs?.watchEndpointMusicConfig?.musicVideoType;

  let itemType: "song" | "video" = "song";
  if (
    item.item_type === "video" ||
    item.type === "video" ||
    (musicVideoType && musicVideoType !== "MUSIC_VIDEO_TYPE_ATV")
  ) {
    itemType = "video";
  }

  return {
    id,
    title,
    type: itemType,
    artists,
    artist_name: artistName,
    artist_id: firstArtist.id,
    album,
    duration,
    duration_seconds: durationSeconds,
    thumbnail,
    year,
    views: item.views?.text || item.view_count || null,
    slug: slugify(title),
  };
}

/**
 * Fetch Top Songs with Parallel Query Resolution & Stale-While-Revalidate
 */
export async function getHomeTopSongs(): Promise<Song[]> {
  const cacheKey = "home_top_songs_25_native_v3";
  const cached = getFromCache<Song[]>(cacheKey, 900); // 15 min fresh TTL

  // If fresh, return immediately
  if (cached && !cached.isStale && cached.data.length >= 20) {
    return cached.data.slice(0, 25);
  }

  // If stale, serve stale immediately and revalidate in background
  if (cached && cached.isStale && cached.data.length >= 20) {
    // Trigger background update without awaiting
    dedupeRequest(cacheKey, fetchTopSongsFromNetwork).catch(() => {});
    return cached.data.slice(0, 25);
  }

  // Otherwise fetch from network with deduplication
  return dedupeRequest(cacheKey, fetchTopSongsFromNetwork);
}

async function fetchTopSongsFromNetwork(): Promise<Song[]> {
  const yt = await getInnertube();
  const songs: Song[] = [];
  const seenIds = new Set<string>();

  const queries = [
    "Top Songs Global",
    "Billboard Hot 100",
    "Top Hits",
    "Global Top 50 Songs",
  ];

  // Execute queries in parallel for high speed
  const searchResults = await Promise.allSettled(
    queries.map((q) => yt.music.search(q, { type: "song" }))
  );

  for (const result of searchResults) {
    if (result.status === "fulfilled" && result.value?.songs?.contents) {
      for (const item of result.value.songs.contents) {
        const song = normalizeSongFromItem(item);
        if (song && !seenIds.has(song.id)) {
          seenIds.add(song.id);
          songs.push(song);
          if (songs.length >= 35) break;
        }
      }
    }
  }

  // Fallback if needed
  if (songs.length < 20) {
    try {
      const fallbackRes = await yt.music.search("Trending pop hits", { type: "song" });
      const items = fallbackRes.songs?.contents || [];
      for (const item of items) {
        const song = normalizeSongFromItem(item);
        if (song && !seenIds.has(song.id)) {
          seenIds.add(song.id);
          songs.push(song);
          if (songs.length >= 25) break;
        }
      }
    } catch (err) {
      console.error("Error fetching fallback songs:", err);
    }
  }

  const finalSongs = songs.slice(0, 25);
  if (finalSongs.length > 0) {
    setToCache("home_top_songs_25_native_v2", finalSongs);
  }
  return finalSongs;
}

/**
 * Search Songs with Deduplication, YouTube URL support, and Caching (25 items)
 */
export async function searchSongs(query: string): Promise<Song[]> {
  const cleanQ = query.trim();
  const directVideoId = extractYouTubeId(cleanQ);

  if (directVideoId) {
    const directCacheKey = `search_yt_url_v1_${directVideoId}`;
    const cachedDirect = getFromCache<Song[]>(directCacheKey, 600);
    if (cachedDirect && cachedDirect.data.length > 0) {
      return cachedDirect.data;
    }

    return dedupeRequest(directCacheKey, async () => {
      try {
        const directSong = await getSongDetails(directVideoId);
        if (directSong) {
          const results: Song[] = [directSong];
          const seenIds = new Set<string>([directSong.id]);

          // Enrich with related/recommended songs using the song title and artist
          try {
            const yt = await getInnertube();
            const relSearchQuery = `${directSong.title} ${directSong.artist_name || ""}`
              .replace(/\(Official Music Video\)|\(Official Video\)|\(Official Audio\)|\[Official Video\]|\[Official Music Video\]/gi, "")
              .trim();
            const searchRes = await yt.music.search(relSearchQuery, { type: "song" });
            const items = searchRes.songs?.contents || [];
            for (const item of items) {
              const s = normalizeSongFromItem(item);
              if (s && !seenIds.has(s.id)) {
                seenIds.add(s.id);
                results.push(s);
                if (results.length >= 25) break;
              }
            }
          } catch (relErr) {
            console.warn("Could not fetch related songs for direct YouTube URL:", relErr);
          }

          setToCache(directCacheKey, results);
          return results;
        }
      } catch (err) {
        console.warn(`Error resolving direct YouTube URL '${cleanQ}':`, err);
      }

      return performStandardSearch(cleanQ);
    });
  }

  return performStandardSearch(cleanQ);
}

async function performStandardSearch(query: string): Promise<Song[]> {
  const cleanQ = query.trim().toLowerCase();
  const cacheKey = `search_v25_${cleanQ}`;
  const cached = getFromCache<Song[]>(cacheKey, 600);
  if (cached && cached.data.length >= 25) {
    return cached.data.slice(0, 25);
  }

  return dedupeRequest(cacheKey, async () => {
    const yt = await getInnertube();
    const res = await yt.music.search(query, { type: "song" });
    const items = res.songs?.contents || [];

    const songs: Song[] = [];
    const seenIds = new Set<string>();

    for (const item of items) {
      const song = normalizeSongFromItem(item);
      if (song && !seenIds.has(song.id)) {
        seenIds.add(song.id);
        songs.push(song);
        if (songs.length >= 25) break;
      }
    }

    // Fetch continuation if results are less than 25
    if (songs.length < 25 && res.has_continuation) {
      try {
        const cont = await res.getContinuation();
        const moreItems: any[] = (cont.contents as any)?.contents || [];
        for (const item of moreItems) {
          const song = normalizeSongFromItem(item);
          if (song && !seenIds.has(song.id)) {
            seenIds.add(song.id);
            songs.push(song);
            if (songs.length >= 25) break;
          }
        }
      } catch (contErr) {
        console.warn("Could not fetch search continuation:", contErr);
      }
    }

    const finalSongs = songs.slice(0, 25);
    setToCache(cacheKey, finalSongs);
    return finalSongs;
  });
}

/**
 * Fetch Artist details and all related songs with caching (1 hour fresh, 24h stale)
 */
export async function getArtistDetails(idOrQuery: string): Promise<ArtistDetail | null> {
  const cleanParam = decodeURIComponent(idOrQuery).trim();
  if (!cleanParam) return null;

  const isChannelId = /^(UC[a-zA-Z0-9_-]{20,}|FEmusic_[a-zA-Z0-9_-]+)/.test(cleanParam);
  const cacheKey = isChannelId ? `artist_detail_id_${cleanParam}` : `artist_detail_v2_${slugify(cleanParam)}`;
  const cached = getFromCache<ArtistDetail>(cacheKey, 3600); // 1 hr fresh
  if (cached && !cached.isStale && cached.data.songs && cached.data.songs.length > 0) {
    return cached.data;
  }

  if (cached && cached.isStale && cached.data.songs && cached.data.songs.length > 0) {
    // SWR background update
    dedupeRequest(cacheKey, () => fetchArtistFromNetwork(cleanParam)).catch(() => {});
    return cached.data;
  }

  return dedupeRequest(cacheKey, () => fetchArtistFromNetwork(cleanParam));
}

async function fetchArtistFromNetwork(param: string): Promise<ArtistDetail | null> {
  const yt = await getInnertube();
  let artistId = param;
  let searchedArtistItem: any = null;

  // If param does not look like a YouTube channel/artist browse ID (starts with UC or FEmusic_),
  // perform a music search for the artist first.
  const isLikelyId = /^(UC[a-zA-Z0-9_-]{20,}|FEmusic_artist_[a-zA-Z0-9_-]+)/.test(param);
  if (!isLikelyId) {
    try {
      const searchName = param.replace(/[-_+]/g, " ").trim();
      let searchRes = await yt.music.search(searchName, { type: "artist" });
      let found = searchRes.artists?.contents?.[0];
      if (!found && searchName !== param) {
        searchRes = await yt.music.search(param, { type: "artist" });
        found = searchRes.artists?.contents?.[0];
      }
      if (found && (found.id || (found as any).endpoint?.payload?.browseId)) {
        artistId = found.id || (found as any).endpoint?.payload?.browseId;
        searchedArtistItem = found;
      }
    } catch (searchErr) {
      console.warn(`Could not search artist by name '${param}':`, searchErr);
    }
  }

  let artistData: any = null;
  try {
    artistData = await yt.music.getArtist(artistId);
  } catch (err: any) {
    console.warn(`yt.music.getArtist failed for ID '${artistId}':`, err?.message || err);
    if (!searchedArtistItem) {
      try {
        const searchRes = await yt.music.search(param, { type: "artist" });
        const found = searchRes.artists?.contents?.[0];
        if (found && (found.id || (found as any).endpoint?.payload?.browseId)) {
          artistId = found.id || (found as any).endpoint?.payload?.browseId;
          searchedArtistItem = found;
          artistData = await yt.music.getArtist(artistId);
        }
      } catch {
        // ignore
      }
    }
  }

  // Name extraction
  const artistName =
    artistData?.header?.title?.text ||
    artistData?.header?.title?.toString() ||
    artistData?.name ||
    searchedArtistItem?.name ||
    param;

  // Thumbnail & Banner
  const headerThumbs =
    artistData?.header?.thumbnail?.contents ||
    artistData?.header?.thumbnails ||
    (Array.isArray(artistData?.header?.thumbnail) ? artistData?.header?.thumbnail : []) ||
    searchedArtistItem?.thumbnail?.contents ||
    [];

  const thumbnail = getBestThumbnailUrl(headerThumbs, undefined, 400, 400);

  let banner: string | null = null;
  if (Array.isArray(headerThumbs) && headerThumbs.length > 0) {
    const wide = headerThumbs.find((t: any) => t && t.width && t.width > 800);
    if (wide?.url) banner = wide.url;
  }

  // Description & Audience/Subscribers
  const description =
    artistData?.header?.description?.text ||
    artistData?.header?.description?.toString() ||
    null;

  const subscribers =
    artistData?.header?.subscribers?.text ||
    artistData?.header?.subscriber_count?.text ||
    searchedArtistItem?.subtitle?.text ||
    null;

  // Songs extraction
  const songs: Song[] = [];
  const seenIds = new Set<string>();

  // 1. Try artist.getAllSongs()
  if (artistData && typeof artistData.getAllSongs === "function") {
    try {
      const all = await artistData.getAllSongs();
      const allItems = all?.contents || [];
      for (const item of allItems) {
        const song = normalizeSongFromItem(item);
        if (song && !seenIds.has(song.id)) {
          seenIds.add(song.id);
          songs.push(song);
        }
      }
    } catch (e) {
      console.warn("getAllSongs error:", e);
    }
  }

  // 2. If fewer than 20 songs, extract from artist.sections (e.g. Top songs, albums, etc.)
  if (songs.length < 20 && Array.isArray(artistData?.sections)) {
    for (const sec of artistData.sections) {
      const items = sec?.contents || [];
      for (const item of items) {
        const song = normalizeSongFromItem(item);
        if (song && !seenIds.has(song.id)) {
          seenIds.add(song.id);
          songs.push(song);
        }
      }
    }
  }

  // 3. If still fewer than 25 songs, supplement with yt.music.search(artistName, { type: 'song' })
  if (songs.length < 25) {
    try {
      const songSearch = await yt.music.search(`${artistName}`, { type: "song" });
      const searchItems = songSearch?.songs?.contents || [];
      for (const item of searchItems) {
        const song = normalizeSongFromItem(item);
        if (song && !seenIds.has(song.id)) {
          seenIds.add(song.id);
          songs.push(song);
          if (songs.length >= 50) break;
        }
      }
    } catch (err) {
      console.warn("Artist song search supplement error:", err);
    }
  }

  if (!artistData && songs.length === 0) {
    return null;
  }

  // Filter only type === "song" so discography exclusively contains audio song tracks
  const songTracks = songs.filter((s) => s.type === "song");

  const result: ArtistDetail = {
    id: artistId,
    name: artistName,
    thumbnail,
    banner,
    subscribers,
    description,
    slug: slugify(artistName),
    songs: songTracks,
    total_songs: songTracks.length,
  };

  const cacheKey = `artist_detail_v2_${slugify(param)}`;
  setToCache(cacheKey, result);
  // Also cache under resolved artistId and artist slug
  if (artistId) setToCache(`artist_detail_v2_${slugify(artistId)}`, result);
  if (artistName) setToCache(`artist_detail_v2_${slugify(artistName)}`, result);

  return result;
}

async function fetchOEmbedFallback(videoId: string): Promise<{ title?: string; author?: string; thumbnail?: string } | null> {
  try {
    const res = await fetch(`https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=${videoId}&format=json`, {
      signal: AbortSignal.timeout(4000),
    });
    if (res.ok) {
      const data: any = await res.json();
      return {
        title: data.title,
        author: data.author_name,
        thumbnail: data.thumbnail_url,
      };
    }
  } catch {
    // Ignore fallback errors
  }
  return null;
}

/**
 * Fetch a single song's details with caching for SEO pre-rendering & direct track view
 */
export async function getSongDetails(songId: string): Promise<Song | null> {
  const cleanId = songId.trim();
  if (!cleanId) return null;

  // 1. Check in home top songs
  try {
    const top = await getHomeTopSongs();
    const found = top.find((s) => s.id === cleanId);
    if (found && found.title !== "Unknown Title") return found;
  } catch {
    // Continue to dedicated lookup
  }

  // 2. Check dedicated song cache
  const cacheKey = `song_detail_v2_${cleanId}`;
  const cached = getFromCache<Song>(cacheKey, 3600);
  if (cached && !cached.isStale && cached.data.title !== "Unknown Title") return cached.data;

  return dedupeRequest(cacheKey, async () => {
    try {
      const yt = await getInnertube();
      let info: any = null;
      try {
        info = await yt.music.getInfo(cleanId);
      } catch {
        try {
          info = await yt.getInfo(cleanId);
        } catch {
          // ignore
        }
      }

      const basic = info?.basic_info;
      let title = basic?.title || "";
      let artistName = basic?.author || "";
      let thumbnail = getBestThumbnailUrl(basic?.thumbnail, cleanId);

      // If innertube basic_info is missing title/artist (common on some licensed music videos),
      // seamlessly fall back to official YouTube oEmbed API
      if (!title || title === "Unknown Title" || !artistName || artistName === "Unknown Artist") {
        const oembed = await fetchOEmbedFallback(cleanId);
        if (oembed) {
          if ((!title || title === "Unknown Title") && oembed.title) {
            title = oembed.title;
          }
          if ((!artistName || artistName === "Unknown Artist") && oembed.author) {
            artistName = oembed.author;
          }
          if (!thumbnail && oembed.thumbnail) {
            thumbnail = oembed.thumbnail;
          }
        }
      }

      if (!title) title = "Unknown Title";
      if (!artistName) artistName = "Unknown Artist";

      const durationSeconds = basic?.duration || 210;
      const minutes = Math.floor(durationSeconds / 60);
      const seconds = durationSeconds % 60;
      const duration = `${minutes}:${seconds < 10 ? "0" : ""}${seconds}`;

      const song: Song = {
        id: cleanId,
        title,
        type: "song",
        artists: [{ name: artistName, id: basic?.channel_id || null }],
        artist_name: artistName,
        artist_id: basic?.channel_id || null,
        album: null,
        duration,
        duration_seconds: durationSeconds,
        thumbnail,
        year: basic?.published ? String(new Date(basic.published).getFullYear()) : null,
        views: basic?.view_count ? `${Number(basic.view_count).toLocaleString()} views` : null,
        slug: slugify(title),
      };

      if (title !== "Unknown Title") {
        setToCache(cacheKey, song);
      }
      return song;
    } catch (err) {
      console.warn(`Could not getSongDetails for '${cleanId}':`, err);
    }
    return null;
  });
}

export interface SearchSongSuggestion {
  id: string;
  title: string;
  artist: string;
  thumbnail: string;
}

export interface SearchSuggestionsResult {
  queries: string[];
  songs: SearchSongSuggestion[];
}

/**
 * Lightweight YouTube Music Search Suggestions / Autocomplete
 * Uses Innertube yt.music.getSearchSuggestions with an in-memory cache and Google fallback
 */
export async function getSearchSuggestions(query: string): Promise<SearchSuggestionsResult> {
  const cleanQ = query.trim();
  if (!cleanQ) {
    return { queries: [], songs: [] };
  }

  const cacheKey = `suggestions_v2_${cleanQ.toLowerCase()}`;
  const cached = getFromCache<SearchSuggestionsResult>(cacheKey, 600); // 10 minutes cache
  if (cached && (cached.data.queries.length > 0 || cached.data.songs.length > 0)) {
    return cached.data;
  }

  return dedupeRequest(cacheKey, async () => {
    try {
      const yt = await getInnertube();
      const sections = await yt.music.getSearchSuggestions(cleanQ);

      const queries: string[] = [];
      const seenQueries = new Set<string>();

      if (Array.isArray(sections)) {
        for (const section of sections) {
          if (!section || !Array.isArray(section.contents)) continue;
          for (const rawNode of section.contents) {
            const item = rawNode as any;
            if (item.type === "SearchSuggestion") {
              const txt = item.suggestion?.text || item.suggestion?.toString();
              if (txt && typeof txt === "string") {
                const trimmed = txt.trim();
                if (trimmed && !seenQueries.has(trimmed.toLowerCase())) {
                  seenQueries.add(trimmed.toLowerCase());
                  queries.push(trimmed);
                  if (queries.length >= 8) break;
                }
              }
            }
          }
          if (queries.length >= 8) break;
        }
      }

      if (queries.length > 0) {
        const result: SearchSuggestionsResult = {
          queries: queries.slice(0, 8),
          songs: [],
        };
        setToCache(cacheKey, result);
        return result;
      }
    } catch (err: any) {
      console.warn("Innertube getSearchSuggestions error:", err?.message || err);
    }

    // High-speed fallback to Google YouTube suggestion service
    try {
      const fallbackUrl = `https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&q=${encodeURIComponent(cleanQ)}`;
      const res = await fetch(fallbackUrl, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
          Accept: "application/json",
        },
        signal: AbortSignal.timeout(2000),
      });
      if (res.ok) {
        const data: any = await res.json();
        if (Array.isArray(data) && Array.isArray(data[1])) {
          const queries = data[1]
            .filter((item: any) => typeof item === "string" && item.trim())
            .slice(0, 8);
          const result: SearchSuggestionsResult = { queries, songs: [] };
          setToCache(cacheKey, result);
          return result;
        }
      }
    } catch (fallbackErr: any) {
      console.warn("Fallback suggestions error:", fallbackErr?.message || fallbackErr);
    }

    return { queries: [], songs: [] };
  });
}

/**
 * Background warm-up function
 */
export async function warmupYtMusic(): Promise<void> {
  try {
    await getInnertube();
    await getHomeTopSongs();
  } catch (err) {
    console.warn("Warmup background task completed with warning:", err);
  }
}
