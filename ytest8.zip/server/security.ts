import { Request, Response, NextFunction } from "express";
import CryptoJS from "crypto-js";

// Master encryption & signing key for YTCAT API protection
export const API_ENCRYPTION_KEY =
  process.env.API_ENCRYPTION_KEY || "ytcat_sec_99f482a17b8c4d2e_v2_protected";

/**
 * Encrypt arbitrary JS data (objects, arrays, primitives) into AES-256 ciphertext
 */
export function encryptPayload(data: any): string {
  const jsonStr = JSON.stringify(data);
  return CryptoJS.AES.encrypt(jsonStr, API_ENCRYPTION_KEY).toString();
}

/**
 * Verify client signature and anti-scraping tokens
 */
export function verifyApiRequest(req: Request): { allowed: boolean; reason?: string } {
  // Allow health checks without signature
  if (
    req.path === "/api/health" ||
    req.path === "/health" ||
    (req.originalUrl && req.originalUrl.startsWith("/api/health"))
  ) {
    return { allowed: true };
  }

  const token = req.headers["x-ytcat-token"] as string | undefined;
  const timeStr = req.headers["x-ytcat-time"] as string | undefined;

  // 1. Check presence of anti-scraping headers
  if (!token || !timeStr) {
    return {
      allowed: false,
      reason: "Missing security credentials. Direct API scraping is forbidden.",
    };
  }

  // 2. Validate timestamp freshness (within 5 minutes tolerance to prevent replay attacks)
  const clientTime = parseInt(timeStr, 10);
  if (isNaN(clientTime)) {
    return { allowed: false, reason: "Invalid timestamp header." };
  }

  const now = Date.now();
  const maxClockDrift = 5 * 60 * 1000; // 5 minutes
  if (Math.abs(now - clientTime) > maxClockDrift) {
    return {
      allowed: false,
      reason: "Security token expired. Please refresh your browser.",
    };
  }

  // 3. Verify HMAC signature: path + "|" + timestamp
  const fullPath = (req.originalUrl ? req.originalUrl.split("?")[0] : req.path) || req.path;
  const expectedToken1 = CryptoJS.HmacSHA256(
    `${fullPath}|${clientTime}`,
    API_ENCRYPTION_KEY
  ).toString();
  const expectedToken2 = CryptoJS.HmacSHA256(
    `${req.path}|${clientTime}`,
    API_ENCRYPTION_KEY
  ).toString();

  if (token !== expectedToken1 && token !== expectedToken2) {
    return {
      allowed: false,
      reason: "Invalid API signature. Unauthorized client detected.",
    };
  }

  // 4. Validate Origin / Referer if present (prevent external site embedding/hotlinking)
  const origin = req.headers.origin || req.headers.referer;
  if (origin) {
    try {
      const parsed = new URL(origin);
      const host = parsed.hostname.toLowerCase();
      const currentHost = (req.get("host") || "").split(":")[0].toLowerCase();

      const isAllowedHost =
        host === currentHost ||
        host === "localhost" ||
        host === "127.0.0.1" ||
        host.endsWith(".anaku.web.id") ||
        host === "anaku.web.id" ||
        host.endsWith(".run.app") ||
        host.endsWith(".googleusercontent.com");

      if (!isAllowedHost) {
        return {
          allowed: false,
          reason: "Origin not permitted. Hotlinking API is forbidden.",
        };
      }
    } catch {
      // Ignore malformed referer URL if harmless
    }
  }

  return { allowed: true };
}

/**
 * Express Middleware protecting all API routes from external scraping
 */
export function apiSecurityGuard(req: Request, res: Response, next: NextFunction) {
  const check = verifyApiRequest(req);
  if (!check.allowed) {
    res.setHeader("Cache-Control", "no-store, max-age=0");
    return res.status(403).json({
      success: false,
      error: check.reason || "Forbidden: Unauthorized API access",
      code: "API_SCRAPE_FORBIDDEN",
    });
  }
  next();
}

/**
 * Helper to respond with an encrypted payload
 */
export function sendEncryptedResponse(
  res: Response,
  data: any,
  options?: {
    cacheControl?: string;
    extraMeta?: Record<string, any>;
  }
) {
  if (options?.cacheControl) {
    res.setHeader("Cache-Control", options.cacheControl);
  }

  const ciphertext = encryptPayload(data);

  res.json({
    success: true,
    encrypted: true,
    data: ciphertext,
    ts: Date.now(),
    ...(options?.extraMeta || {}),
  });
}
