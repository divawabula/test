import crypto from "crypto";

export interface EncryptedPayload {
  encrypted: true;
  algorithm: "AES-256-GCM";
  iv: string; // 12-byte hex
  data: string; // hex (ciphertext + 16-byte auth tag)
  timestamp: number;
}

export const API_SECRET_KEY =
  process.env.API_ENCRYPTION_KEY ||
  process.env.VITE_API_ENCRYPTION_KEY ||
  "ytcat-secure-symmetric-aes256-payload-key-2026";

// Derive a guaranteed 256-bit (32 bytes) symmetric key via SHA-256
const SYMMETRIC_KEY_BUFFER = crypto.createHash("sha256").update(API_SECRET_KEY).digest();

/**
 * Encrypts any data payload using Symmetric Encryption (AES-256-GCM).
 * Returns an EncryptedPayload containing the 12-byte IV and ciphertext with authentication tag.
 */
export function encryptPayload(data: any): EncryptedPayload {
  const plaintext = Buffer.from(JSON.stringify(data), "utf8");
  const iv = crypto.randomBytes(12); // 12-byte IV standard for GCM mode

  const cipher = crypto.createCipheriv("aes-256-gcm", SYMMETRIC_KEY_BUFFER, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const authTag = cipher.getAuthTag(); // 16-byte authentication tag
  const combined = Buffer.concat([encrypted, authTag]);

  return {
    encrypted: true,
    algorithm: "AES-256-GCM",
    iv: iv.toString("hex"),
    data: combined.toString("hex"),
    timestamp: Date.now(),
  };
}

/**
 * Decrypts an AES-256-GCM encrypted payload and parses the JSON.
 */
export function decryptPayload<T = any>(payload: { iv: string; data: string }): T {
  const iv = Buffer.from(payload.iv, "hex");
  const combined = Buffer.from(payload.data, "hex");

  if (combined.length < 16) {
    throw new Error("Invalid ciphertext length: missing authentication tag");
  }

  const authTag = combined.subarray(combined.length - 16);
  const ciphertext = combined.subarray(0, combined.length - 16);

  const decipher = crypto.createDecipheriv("aes-256-gcm", SYMMETRIC_KEY_BUFFER, iv);
  decipher.setAuthTag(authTag);

  const decrypted = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
  return JSON.parse(decrypted.toString("utf8"));
}

/**
 * Type guard to check if an object is an encrypted payload.
 */
export function isEncryptedPayload(body: any): body is EncryptedPayload {
  return (
    body &&
    typeof body === "object" &&
    body.encrypted === true &&
    typeof body.iv === "string" &&
    typeof body.data === "string"
  );
}
