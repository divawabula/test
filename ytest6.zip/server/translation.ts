import { translate } from "google-translate-api-x";
import { pinyin } from "pinyin-pro";
import anyAscii from "any-ascii";

// Singleton Kuroshiro instance with dynamic ESM/CJS import
let kuroshiroInstance: any = null;
let kuroshiroInitPromise: Promise<any> | null = null;

async function getKuroshiro(): Promise<any> {
  if (kuroshiroInstance) return kuroshiroInstance;
  if (!kuroshiroInitPromise) {
    kuroshiroInitPromise = (async () => {
      try {
        const kuroshiroMod: any = await import("kuroshiro");
        const KuroshiroClass =
          kuroshiroMod.default?.default || kuroshiroMod.default || kuroshiroMod;
        const analyzerMod: any = await import("kuroshiro-analyzer-kuromoji");
        const AnalyzerClass =
          analyzerMod.default?.default || analyzerMod.default || analyzerMod;

        const instance = new KuroshiroClass();
        await instance.init(new AnalyzerClass());
        kuroshiroInstance = instance;
        return instance;
      } catch (err) {
        console.warn("Failed to initialize Kuroshiro:", err);
        return null;
      }
    })();
  }
  return kuroshiroInitPromise;
}

// Singleton Hangul Romanizer with dynamic ESM/CJS import
let hangulInstance: any = null;
async function getHangul(): Promise<any> {
  if (hangulInstance) return hangulInstance;
  try {
    const mod: any = await import("hangul-romanization");
    hangulInstance = mod.default?.default || mod.default || mod;
    return hangulInstance;
  } catch (err) {
    console.warn("Failed to load hangul-romanization:", err);
    return null;
  }
}

// Regex patterns for script detection
const JAPANESE_KANA_REGEX = /[\u3040-\u309F\u30A0-\u30FF\u31F0-\u31FF\uFF66-\uFF9D]/;
const KOREAN_HANGUL_REGEX = /[\uAC00-\uD7AF\u1100-\u11FF\u3130-\u318F]/;
const CHINESE_HANZI_REGEX = /[\u4E00-\u9FFF]/;
const CYRILLIC_REGEX = /[\u0400-\u04FF]/;
const ARABIC_REGEX = /[\u0600-\u06FF]/;
const THAI_REGEX = /[\u0E00-\u0E7F]/;
const HINDI_REGEX = /[\u0900-\u097F]/;
const GREEK_REGEX = /[\u0370-\u03FF]/;

export type RomanizationType = "Romaji" | "Pinyin" | "Romanisasi" | "Transliterasi" | "None";

export interface ScriptAnalysis {
  hasRomanization: boolean;
  romanizationType: RomanizationType;
  scriptLabel: string;
  detectedLang: string;
}

/**
 * Analyzes an array of strings or full text to determine script and suitable romanizer
 */
export function analyzeScript(texts: string[]): ScriptAnalysis {
  let kanaCount = 0;
  let hangulCount = 0;
  let hanziCount = 0;
  let cyrillicCount = 0;
  let arabicCount = 0;
  let thaiCount = 0;
  let hindiCount = 0;
  let greekCount = 0;

  for (const text of texts) {
    if (!text) continue;
    if (JAPANESE_KANA_REGEX.test(text)) kanaCount++;
    if (KOREAN_HANGUL_REGEX.test(text)) hangulCount++;
    if (CHINESE_HANZI_REGEX.test(text)) hanziCount++;
    if (CYRILLIC_REGEX.test(text)) cyrillicCount++;
    if (ARABIC_REGEX.test(text)) arabicCount++;
    if (THAI_REGEX.test(text)) thaiCount++;
    if (HINDI_REGEX.test(text)) hindiCount++;
    if (GREEK_REGEX.test(text)) greekCount++;
  }

  // Japanese takes precedence if Kana is present (even if mixed with Kanji)
  if (kanaCount > 0) {
    return {
      hasRomanization: true,
      romanizationType: "Romaji",
      scriptLabel: "Romaji (Japanese)",
      detectedLang: "ja",
    };
  }

  if (hangulCount > 0) {
    return {
      hasRomanization: true,
      romanizationType: "Romanisasi",
      scriptLabel: "Romanization (Korean)",
      detectedLang: "ko",
    };
  }

  if (hanziCount > 0) {
    return {
      hasRomanization: true,
      romanizationType: "Pinyin",
      scriptLabel: "Pinyin (Mandarin)",
      detectedLang: "zh",
    };
  }

  if (cyrillicCount > 0) {
    return {
      hasRomanization: true,
      romanizationType: "Transliterasi",
      scriptLabel: "Transliteration (Cyrillic)",
      detectedLang: "ru",
    };
  }

  if (arabicCount > 0) {
    return {
      hasRomanization: true,
      romanizationType: "Transliterasi",
      scriptLabel: "Transliteration (Arabic)",
      detectedLang: "ar",
    };
  }

  if (thaiCount > 0) {
    return {
      hasRomanization: true,
      romanizationType: "Transliterasi",
      scriptLabel: "Transliteration (Thai)",
      detectedLang: "th",
    };
  }

  if (hindiCount > 0) {
    return {
      hasRomanization: true,
      romanizationType: "Transliterasi",
      scriptLabel: "Transliteration (Hindi)",
      detectedLang: "hi",
    };
  }

  if (greekCount > 0) {
    return {
      hasRomanization: true,
      romanizationType: "Transliterasi",
      scriptLabel: "Transliteration (Greek)",
      detectedLang: "el",
    };
  }

  return {
    hasRomanization: false,
    romanizationType: "None",
    scriptLabel: "",
    detectedLang: "latin",
  };
}

/**
 * Generate Romanization / Cara Baca for a list of texts
 */
export async function romanizeTexts(
  texts: string[],
  analysis?: ScriptAnalysis
): Promise<string[]> {
  const meta = analysis || analyzeScript(texts);
  if (!meta.hasRomanization) {
    return texts.map(() => "");
  }

  if (meta.romanizationType === "Romaji") {
    const kuro = await getKuroshiro();
    if (kuro) {
      const results: string[] = [];
      for (const text of texts) {
        if (!text || !text.trim()) {
          results.push("");
          continue;
        }
        try {
          const romaji = await kuro.convert(text, { to: "romaji", mode: "spaced" });
          results.push(romaji.trim());
        } catch {
          results.push(anyAscii(text).trim());
        }
      }
      return results;
    }
  }

  if (meta.romanizationType === "Romanisasi") {
    const hangul = await getHangul();
    return texts.map((text) => {
      if (!text || !text.trim()) return "";
      try {
        if (hangul && typeof hangul.convert === "function") {
          return hangul.convert(text).trim();
        }
        return anyAscii(text).trim();
      } catch {
        return anyAscii(text).trim();
      }
    });
  }

  if (meta.romanizationType === "Pinyin") {
    return texts.map((text) => {
      if (!text || !text.trim()) return "";
      try {
        return pinyin(text).trim();
      } catch {
        return anyAscii(text).trim();
      }
    });
  }

  // Universal fallback: anyAscii
  return texts.map((text) => {
    if (!text || !text.trim()) return "";
    return anyAscii(text).trim();
  });
}

// In-Memory cache for Google Translations (24 hours fresh)
const translationCache = new Map<string, { data: any; timestamp: number }>();

/**
 * Translate array of lines or plain text using Google Translate
 */
export async function translateLyrics(
  lines: string[],
  targetLanguage: string
): Promise<{
  translations: string[];
  sourceLanguage: string;
}> {
  if (!lines || lines.length === 0 || !targetLanguage || targetLanguage === "none") {
    return {
      translations: lines.map(() => ""),
      sourceLanguage: "auto",
    };
  }

  // Check cache for this exact set of lines & target language
  const contentHash = lines.slice(0, 5).join("|") + "_" + lines.length + "_" + targetLanguage;
  const cached = translationCache.get(contentHash);
  if (cached && Date.now() - cached.timestamp < 86_400_000) {
    return cached.data;
  }

  try {
    // Filter non-empty texts to translate efficiently while preserving original indices
    const toTranslate: { index: number; text: string }[] = [];
    for (let i = 0; i < lines.length; i++) {
      const line = (lines[i] || "").trim();
      if (line) {
        toTranslate.push({ index: i, text: line });
      }
    }

    if (toTranslate.length === 0) {
      return {
        translations: lines.map(() => ""),
        sourceLanguage: "auto",
      };
    }

    const textsOnly = toTranslate.map((item) => item.text);
    const googleRes = await translate(textsOnly, {
      to: targetLanguage,
      forceTo: true,
      forceBatch: true,
    });

    const resArray = Array.isArray(googleRes) ? googleRes : [googleRes];
    const results: string[] = new Array(lines.length).fill("");
    let detectedSource = "auto";

    for (let i = 0; i < toTranslate.length; i++) {
      const originalIdx = toTranslate[i].index;
      const transItem = resArray[i];
      if (transItem) {
        results[originalIdx] = transItem.text || "";
        if (transItem.from?.language?.iso && detectedSource === "auto") {
          detectedSource = transItem.from.language.iso;
        }
      }
    }

    const payload = {
      translations: results,
      sourceLanguage: detectedSource,
    };

    translationCache.set(contentHash, { data: payload, timestamp: Date.now() });
    return payload;
  } catch (error: any) {
    console.error("Google Translate batch error:", error.message || error);
    // In case of error, return empty strings gracefully without crashing
    return {
      translations: lines.map(() => ""),
      sourceLanguage: "auto",
    };
  }
}
