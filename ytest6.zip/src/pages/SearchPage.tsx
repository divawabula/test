import { useState, useEffect, useCallback, FormEvent } from "react";
import { useParams, useSearchParams, useNavigate, Link } from "react-router-dom";
import { Search, RefreshCw, Music2, ArrowLeft, X, Disc, Cat } from "lucide-react";
import { Song, ApiResponse } from "../types";
import SongListItem from "../components/SongListItem";
import LoadingSkeleton from "../components/LoadingSkeleton";
import ErrorMessage from "../components/ErrorMessage";
import SEO from "../components/SEO";
import SearchAutocomplete from "../components/SearchAutocomplete";
import { getClientCache, setClientCache } from "../utils/apiCache";
import { apiFetch } from "../utils/apiClient";
import { getSearchNavigationUrl, isYouTubeUrl, extractYouTubeVideoId } from "../utils/youtube";

export default function SearchPage() {
  const { searchQuery: routeSearchParam } = useParams<{ searchQuery?: string }>();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  // Extract query from /search?q=... or /search/:searchQuery
  const rawQParam = searchParams.get("q");
  const decodeRouteParam = (param?: string) => {
    if (!param) return "";
    try {
      return decodeURIComponent(param).replace(/[-_+]/g, " ");
    } catch {
      return param.replace(/[-_+]/g, " ");
    }
  };

  const queryParam = (
    rawQParam
      ? rawQParam
      : routeSearchParam
      ? decodeRouteParam(routeSearchParam)
      : ""
  ).trim();

  const isYt = isYouTubeUrl(queryParam) || Boolean(extractYouTubeVideoId(queryParam));
  const [searchInput, setSearchInput] = useState(queryParam);
  const [searchResults, setSearchResults] = useState<Song[]>([]);
  const [loading, setLoading] = useState<boolean>(Boolean(queryParam));
  const [error, setError] = useState<string | null>(null);

  // Sync input when URL parameter changes
  useEffect(() => {
    setSearchInput(queryParam);
  }, [queryParam]);

  // Execute search API request
  const fetchSearchResults = useCallback(async (query: string, isRefresh = false) => {
    const cleanQuery = query.trim();
    if (!cleanQuery) {
      setSearchResults([]);
      setError(null);
      setLoading(false);
      return;
    }

    const cacheKey = `/api/search?q=${encodeURIComponent(cleanQuery)}`;
    if (!isRefresh) {
      const cached = getClientCache<Song[]>(cacheKey, 180_000);
      if (cached && cached.length > 0) {
        setSearchResults(cached);
        setLoading(false);
        return;
      }
    }

    setLoading(true);
    setError(null);

    try {
      const json = await apiFetch<ApiResponse<Song[]>>(`/api/search?q=${encodeURIComponent(cleanQuery)}`);
      if (json && json.success && Array.isArray(json.data)) {
        // Filter only type === "song"
        const filtered = json.data.filter((s) => s.type?.toLowerCase() === "song").slice(0, 30);
        setSearchResults(filtered);
        setClientCache(cacheKey, filtered);
      } else {
        throw new Error((json && json.error) || "No search results found");
      }
    } catch (err: any) {
      console.error(`Search error for '${cleanQuery}':`, err);
      setError(err.message || "Failed to load search results");
      setSearchResults([]);
    } finally {
      setLoading(false);
    }
  }, []);

  // Trigger search whenever queryParam changes
  useEffect(() => {
    if (queryParam) {
      fetchSearchResults(queryParam);
    } else {
      setSearchResults([]);
      setLoading(false);
      setError(null);
    }
  }, [queryParam, fetchSearchResults]);

  const handleSubmit = (eOrQuery?: FormEvent | string) => {
    if (eOrQuery && typeof eOrQuery === "object" && "preventDefault" in eOrQuery) {
      eOrQuery.preventDefault();
    }
    const targetQuery = typeof eOrQuery === "string" ? eOrQuery : searchInput;
    const clean = targetQuery.trim();
    if (clean) {
      navigate(getSearchNavigationUrl(clean));
    }
  };

  const handleClear = () => {
    setSearchInput("");
  };

  // SEO configuration for search page
  const seoTitle = isYt
    ? "Play & Convert YouTube Link to MP3, M4A, WebM | YTcat"
    : queryParam
    ? `Download & Play "${queryParam}" to MP3, M4A, WebM | YTcat`
    : "Search & Download YouTube Music with Lyrics | YTcat";
  const seoDescription = isYt
    ? "Play and convert audio directly from YouTube link to MP3, M4A, and WebM with synchronized lyrics on YTcat."
    : queryParam
    ? `Stream and download "${queryParam}" in MP3, M4A, and WebM formats with synchronized karaoke lyrics on YTcat.`
    : "Discover, stream, and download millions of YouTube songs in MP3, M4A, and WebM with synced lyrics on YTcat.";
  const seoCanonical = queryParam
    ? `/search?q=${encodeURIComponent(queryParam)}`
    : "/search";

  const isInputYt = isYouTubeUrl(searchInput);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-8 pb-32">
      <SEO
        title={seoTitle}
        description={seoDescription}
        canonicalUrl={seoCanonical}
        type="website"
      />

      {/* Breadcrumb & Navigation */}
      <nav aria-label="Breadcrumb" className="mb-4 text-xs font-bold text-neutral-600 flex items-center gap-1.5 flex-wrap">
        <Link to="/" className="inline-flex items-center gap-1 hover:text-black hover:underline">
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Home</span>
        </Link>
        <span>/</span>
        <span className="text-black font-black truncate max-w-xs sm:max-w-md">
          {isYt
            ? "YouTube Link Search"
            : queryParam
            ? `Search: "${queryParam}"`
            : "Search"}
        </span>
      </nav>

      {/* Search Input Box */}
      <section className="mb-6" aria-label="Search Box">
        <div className="border-2 border-black bg-white p-5 sm:p-6">
          <form onSubmit={handleSubmit} className="flex flex-col gap-2" id="search-page-form">
            <div className="flex flex-col sm:flex-row gap-2">
              <SearchAutocomplete
                id="search-page-input"
                value={searchInput}
                onChange={setSearchInput}
                onSubmit={(val) => handleSubmit(val)}
                placeholder="Search songs, artists, or paste YouTube link..."
                autoFocus={!queryParam}
              />

              <button
                type="submit"
                id="search-page-submit-btn"
                className="px-6 py-2.5 bg-[#FFE600] border-2 border-black font-black text-sm hover:bg-black hover:text-[#FFE600] transition-colors flex items-center justify-center gap-2 cursor-pointer active:translate-x-0.5 active:translate-y-0.5"
              >
                <Search className="w-4 h-4" />
                <span>Search Songs</span>
              </button>
            </div>

            {isInputYt && (
              <div className="flex items-center gap-1.5 text-xs font-bold text-black bg-[#F4F4F0] border border-black px-2.5 py-1.5 w-fit" id="search-yt-url-badge">
                <span className="inline-block w-2 h-2 rounded-full bg-red-600 animate-pulse" />
                <span>YouTube link detected • Press <strong>Search Songs</strong> to open</span>
              </div>
            )}
          </form>
        </div>
      </section>

      {/* Results Header */}
      {queryParam && (
        <section className="mb-4" aria-label="Results Status">
          <div className="flex items-center justify-between gap-3 p-3 border-2 border-black bg-white">
            <div className="flex items-center gap-2 min-w-0">
              <h1 className="font-black text-sm sm:text-base text-black truncate">
                {isYt ? (
                  <span className="inline-flex items-center gap-2 truncate">
                    <span className="px-1.5 py-0.5 bg-red-600 text-white text-[11px] font-black uppercase flex-shrink-0">
                      YouTube URL
                    </span>
                    <span className="truncate">Link Result: {queryParam}</span>
                  </span>
                ) : (
                  <>
                    Search Results for: <span>"{queryParam}"</span>
                  </>
                )}
              </h1>
            </div>

            <div className="flex items-center gap-2 flex-shrink-0">
              <button
                onClick={() => fetchSearchResults(queryParam, true)}
                disabled={loading}
                aria-label="Refresh search results"
                title="Refresh search results"
                className="p-1.5 border-2 border-black bg-white hover:bg-neutral-100 disabled:opacity-50 cursor-pointer transition-transform active:translate-x-0.5 active:translate-y-0.5"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
              </button>
            </div>
          </div>
        </section>
      )}

      {/* Content Body */}
      <main id="search-results-container">
        {loading && <LoadingSkeleton count={8} />}

        {error && !loading && (
          <ErrorMessage
            message={error}
            onRetry={() => fetchSearchResults(queryParam, true)}
          />
        )}

        {/* Empty query initial view */}
        {!loading && !queryParam && (
          <div className="p-10 border-2 border-black bg-white text-center">
            <div className="w-14 h-14 bg-[#FFE600] border-2 border-black mx-auto mb-3 flex items-center justify-center">
              <Cat className="w-8 h-8 text-black" strokeWidth={2} />
            </div>
            <h2 className="text-lg font-black uppercase mb-1">Find Your Favorite Music</h2>
            <p className="text-sm font-semibold text-neutral-600 max-w-md mx-auto mb-4">
              Type a song title, artist name, or paste a YouTube link in the search box above to start listening directly on YTcat.
            </p>
            <Link
              to="/"
              className="inline-block px-4 py-2 border-2 border-black bg-[#FFE600] font-black text-sm hover:bg-black hover:text-[#FFE600] transition-colors"
            >
              View Top Trending Songs
            </Link>
          </div>
        )}

        {/* No results found */}
        {!loading && !error && queryParam && searchResults.length === 0 && (
          <div className="p-10 border-2 border-black bg-white text-center">
            <Music2 className="w-12 h-12 mx-auto text-neutral-400 mb-3" />
            <h2 className="text-lg font-black uppercase mb-1">No Songs Found</h2>
            <p className="text-sm font-semibold text-neutral-600 mb-4 max-w-md mx-auto">
              {isYt
                ? "The song from this YouTube link could not be found or the video is private/restricted. Please check the URL."
                : `No audio tracks matching "${queryParam}" were found. Try a different spelling or search for an artist.`}
            </p>
            <Link
              to="/"
              className="inline-block px-4 py-2 border-2 border-black bg-[#FFE600] font-black text-sm cursor-pointer hover:bg-black hover:text-[#FFE600] transition-colors"
            >
              Back to Home
            </Link>
          </div>
        )}

        {/* Results List */}
        {!loading && !error && searchResults.length > 0 && (
          <div className="space-y-2.5" role="feed" aria-label="Search Results List">
            {searchResults.map((song, index) => (
              <div key={song.id}>
                {isYt && index === 0 && (
                  <div className="mb-2 px-3 py-1.5 bg-[#FFE600] border-2 border-black flex items-center justify-between gap-2 text-xs font-black">
                    <span className="uppercase flex items-center gap-1.5">
                      <Disc className="w-3.5 h-3.5" />
                      Song from YouTube Link
                    </span>
                    <span className="text-[11px] font-bold text-neutral-800">
                      Ready to Play
                    </span>
                  </div>
                )}
                {isYt && index === 1 && (
                  <div className="mt-4 mb-2 pt-2 border-t-2 border-dashed border-neutral-300">
                    <h3 className="text-xs font-black uppercase tracking-wider text-neutral-600">
                      Other Related Songs
                    </h3>
                  </div>
                )}
                <SongListItem
                  song={song}
                  index={index}
                  playlistQueue={searchResults}
                />
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
