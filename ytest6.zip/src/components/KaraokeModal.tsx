import React, { useState, useEffect, useRef, useMemo } from "react";
import { Link } from "react-router-dom";
import {
  Mic2,
  X,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  RotateCcw,
  AlignLeft,
  Volume2,
  VolumeX,
  Globe,
  BookOpen,
  Copy,
  Check,
  Loader2,
  Timer,
  Type,
  Settings,
} from "lucide-react";
import {
  Song,
  SongLyricsData,
  LyricLine,
  SUPPORTED_TRANSLATION_LANGUAGES,
} from "../types";
import { apiFetch } from "../utils/apiClient";
import { getArtistUrl } from "../utils/seo";
import { formatThumbnailUrl } from "../utils/thumbnail";

interface KaraokeModalProps {
  isOpen: boolean;
  onClose: () => void;
  song: Song;
  currentTime: number;
  duration: number;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onSeek: (time: number) => void;
  onNext: () => void;
  onPrev: () => void;
  canPrev: boolean;
  canNext: boolean;
  volume: number;
  isMuted: boolean;
  onToggleMute: () => void;
}

export default function KaraokeModal({
  isOpen,
  onClose,
  song,
  currentTime,
  duration,
  isPlaying,
  onTogglePlay,
  onSeek,
  onNext,
  onPrev,
  canPrev,
  canNext,
  volume,
  isMuted,
  onToggleMute,
}: KaraokeModalProps) {
  const [lyricsData, setLyricsData] = useState<SongLyricsData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<"karaoke" | "plain">("karaoke");
  const [userHasScrolled, setUserHasScrolled] = useState(false);

  // Translation & Cara Baca state
  const [selectedLanguage, setSelectedLanguage] = useState<string>("none");
  const [showRomanization, setShowRomanization] = useState<boolean>(true);
  const [isTranslating, setIsTranslating] = useState<boolean>(false);
  const [translationError, setTranslationError] = useState<string | null>(null);
  const [copied, setCopied] = useState<boolean>(false);
  const [translationsCache, setTranslationsCache] = useState<
    Record<string, { translations: string[]; romanizations: string[] }>
  >({});

  // Lyric Timing Offset state (in seconds, e.g. -1.0s to +1.0s)
  const [lyricOffset, setLyricOffset] = useState<number>(0);
  const [showLyricSettings, setShowLyricSettings] = useState<boolean>(false);

  // Load saved timing offset for this song
  useEffect(() => {
    if (!song?.id) return;
    try {
      const saved = localStorage.getItem(`lyric_offset_${song.id}`);
      if (saved !== null) {
        const parsed = parseFloat(saved);
        if (!isNaN(parsed) && Math.abs(parsed) <= 15) {
          setLyricOffset(parsed);
          return;
        }
      }
    } catch {
      // ignore storage access errors
    }
    setLyricOffset(0);
  }, [song?.id]);

  // Adjust timing offset and persist
  const updateOffset = (newOffset: number) => {
    const rounded = Math.round(newOffset * 10) / 10;
    const clamped = Math.max(-15, Math.min(15, rounded));
    setLyricOffset(clamped);
    try {
      if (clamped === 0) {
        localStorage.removeItem(`lyric_offset_${song.id}`);
      } else {
        localStorage.setItem(`lyric_offset_${song.id}`, clamped.toString());
      }
    } catch {
      // ignore
    }
  };

  // Font size levels: A-- (xxsmall), A- (xsmall), A (normal), A+ (large - default), A++ (xlarge)
  const FONT_SIZE_LEVELS = [
    { key: "xxsmall", badge: "A--", name: "Ekstra Kecil" },
    { key: "xsmall", badge: "A-", name: "Kecil" },
    { key: "normal", badge: "A", name: "Normal" },
    { key: "large", badge: "A+", name: "Besar" },
    { key: "xlarge", badge: "A++", name: "Ekstra Besar" },
  ] as const;

  const [fontSizeIndex, setFontSizeIndex] = useState<number>(() => {
    try {
      const saved = localStorage.getItem("ytcat_lyric_font_level");
      if (saved !== null) {
        const idx = parseInt(saved, 10);
        if (!isNaN(idx) && idx >= 0 && idx < 5) {
          return idx;
        }
      }
    } catch {
      // ignore
    }
    return 3; // Default to "A+" (Large)
  });

  const decreaseFontSize = () => {
    setFontSizeIndex((prev) => {
      const next = Math.max(0, prev - 1);
      try {
        localStorage.setItem("ytcat_lyric_font_level", next.toString());
      } catch {
        // ignore
      }
      return next;
    });
  };

  const increaseFontSize = () => {
    setFontSizeIndex((prev) => {
      const next = Math.min(FONT_SIZE_LEVELS.length - 1, prev + 1);
      try {
        localStorage.setItem("ytcat_lyric_font_level", next.toString());
      } catch {
        // ignore
      }
      return next;
    });
  };

  // Pre-computed typography classes for optimal contrast and eye-strain reduction across 5 levels
  const typography = useMemo(() => {
    switch (fontSizeIndex) {
      case 0: // A-- (Ekstra Kecil)
        return {
          activeMain: "text-xs sm:text-sm md:text-base font-black",
          inactiveMain: "text-[11px] sm:text-xs md:text-sm font-bold",
          activeRomaji: "text-[10px] sm:text-xs font-semibold",
          inactiveRomaji: "text-[9px] sm:text-[10px] font-medium",
          activeTrans: "text-[10px] sm:text-xs font-medium",
          inactiveTrans: "text-[9px] sm:text-[10px] font-normal",
        };
      case 1: // A- (Kecil)
        return {
          activeMain: "text-sm sm:text-base md:text-lg font-black",
          inactiveMain: "text-xs sm:text-sm md:text-base font-bold",
          activeRomaji: "text-xs sm:text-xs md:text-sm font-semibold",
          inactiveRomaji: "text-[10px] sm:text-xs font-medium",
          activeTrans: "text-xs sm:text-xs md:text-sm font-medium",
          inactiveTrans: "text-[10px] sm:text-xs font-normal",
        };
      case 2: // A (Normal)
        return {
          activeMain: "text-base sm:text-lg md:text-xl font-black",
          inactiveMain: "text-sm sm:text-base md:text-lg font-bold",
          activeRomaji: "text-xs sm:text-sm md:text-base font-semibold",
          inactiveRomaji: "text-[11px] sm:text-xs md:text-sm font-medium",
          activeTrans: "text-xs sm:text-sm font-medium",
          inactiveTrans: "text-[11px] sm:text-xs font-normal",
        };
      case 4: // A++ (Ekstra Besar)
        return {
          activeMain: "text-xl sm:text-2xl md:text-3xl font-black",
          inactiveMain: "text-base sm:text-xl md:text-2xl font-bold",
          activeRomaji: "text-sm sm:text-base md:text-lg font-semibold",
          inactiveRomaji: "text-xs sm:text-sm md:text-base font-medium",
          activeTrans: "text-sm sm:text-base font-medium",
          inactiveTrans: "text-xs sm:text-sm font-normal",
        };
      case 3: // A+ (Besar - Default)
      default:
        return {
          activeMain: "text-lg sm:text-xl md:text-2xl font-black",
          inactiveMain: "text-sm sm:text-base md:text-lg font-bold",
          activeRomaji: "text-xs sm:text-sm md:text-base font-semibold",
          inactiveRomaji: "text-[11px] sm:text-xs md:text-sm font-medium",
          activeTrans: "text-xs sm:text-sm font-medium",
          inactiveTrans: "text-[11px] sm:text-xs font-normal",
        };
    }
  }, [fontSizeIndex]);

  const lyricsContainerRef = useRef<HTMLDivElement>(null);
  const activeLineRef = useRef<HTMLDivElement>(null);
  const userScrollTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Format seconds into mm:ss
  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return "0:00";
    const minutes = Math.floor(secs / 60);
    const seconds = Math.floor(secs % 60);
    return `${minutes}:${seconds.toString().padStart(2, "0")}`;
  };

  // Reset states when song changes
  useEffect(() => {
    setSelectedLanguage("none");
    setTranslationsCache({});
    setTranslationError(null);
  }, [song?.id]);

  // Fetch lyrics when modal is open and song changes
  useEffect(() => {
    if (!isOpen || !song?.id) return;

    let isCancelled = false;
    setLoading(true);
    setError(null);

    const queryParams = new URLSearchParams({
      track: song.title || "",
      artist: song.artist_name || "",
    });
    if (song.duration_seconds) {
      queryParams.append("duration", song.duration_seconds.toString());
    }

    apiFetch<any>(`/api/lyrics/${encodeURIComponent(song.id)}?${queryParams}`)
      .then((res) => {
        if (isCancelled) return;
        if (res && res.success && res.data) {
          setLyricsData(res.data);
          setViewMode(res.data.isSynced ? "karaoke" : "plain");
          // If song has romanization (Japanese, Korean, Chinese, etc.), default to show it
          if (res.data.hasRomanization) {
            setShowRomanization(true);
          }
        } else {
          setError((res && res.error) || "Lyrics not found for this track.");
        }
      })
      .catch((err: any) => {
        if (isCancelled) return;
        console.warn("Failed to load lyrics:", err);
        setError(err.message || "Failed to load lyrics.");
      })
      .finally(() => {
        if (!isCancelled) setLoading(false);
      });

    return () => {
      isCancelled = true;
    };
  }, [isOpen, song?.id, song?.title, song?.artist_name]);

  // Handle translation language change using Google Translate
  const handleLanguageChange = async (targetLang: string) => {
    setSelectedLanguage(targetLang);
    setTranslationError(null);

    if (targetLang === "none" || !lyricsData) return;

    // Check in-memory cache first
    if (translationsCache[targetLang]) return;

    setIsTranslating(true);
    try {
      const lines = lyricsData.lines.length > 0
        ? lyricsData.lines.map((l) => l.text)
        : (lyricsData.plainLyrics?.split("\n") || []);

      const res = await apiFetch<any>("/api/lyrics/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          songId: song.id,
          targetLang,
          lines,
          plainText: lyricsData.plainLyrics,
        }),
      });

      if (res && res.success && res.data) {
        setTranslationsCache((prev) => ({
          ...prev,
          [targetLang]: {
            translations: res.data.translations || [],
            romanizations: res.data.romanizations || [],
          },
        }));

        // If backend returned romanization and not yet available on original lyrics
        if (res.data.hasRomanization && res.data.romanizations?.length > 0) {
          setShowRomanization(true);
        }
      } else {
        setTranslationError(res?.error || "Failed to translate lyrics");
      }
    } catch (err: any) {
      console.warn("Translation failed:", err);
      setTranslationError("Google Translate is currently busy. Please try another language or try again.");
    } finally {
      setIsTranslating(false);
    }
  };

  // Find active line index based on currentTime + lyricOffset
  const activeLineIndex = useMemo(() => {
    if (!lyricsData || !lyricsData.lines || lyricsData.lines.length === 0) {
      return -1;
    }

    const lines = lyricsData.lines;
    const effectiveTime = currentTime + lyricOffset;
    // Find the latest line whose timestamp is <= effectiveTime
    let activeIdx = -1;
    for (let i = 0; i < lines.length; i++) {
      if (effectiveTime >= lines[i].time - 0.25) {
        activeIdx = i;
      } else {
        break;
      }
    }
    return activeIdx;
  }, [lyricsData, currentTime, lyricOffset]);

  // Current active translation data
  const currentTranslation = useMemo(() => {
    if (selectedLanguage === "none" || !translationsCache[selectedLanguage]) {
      return null;
    }
    return translationsCache[selectedLanguage];
  }, [selectedLanguage, translationsCache]);

  // Determine Romanization Label (e.g. Romaji for Japanese, Pinyin for Chinese, Romanization for Korean)
  const romanizationLabel = useMemo(() => {
    if (lyricsData?.romanizationType === "Romaji") return "Romaji (Japanese)";
    if (lyricsData?.romanizationType === "Pinyin") return "Pinyin (Mandarin)";
    if (lyricsData?.romanizationType === "Romanisasi") return "Romanization (Korean)";
    if (lyricsData?.romanizationType === "Transliterasi") return "Transliteration";
    return "Phonetics / Romaji";
  }, [lyricsData?.romanizationType]);

  // Check if romanization is available
  const hasRomanizationAvailable = useMemo(() => {
    if (lyricsData?.hasRomanization) return true;
    if (lyricsData?.lines?.some((l) => !!l.romanization)) return true;
    if (currentTranslation?.romanizations?.some((r) => !!r)) return true;
    return false;
  }, [lyricsData, currentTranslation]);

  // Copy full lyrics to clipboard
  const handleCopyLyrics = () => {
    if (!lyricsData) return;

    let textToCopy = "";
    const lines = lyricsData.lines.length > 0
      ? lyricsData.lines.map((l) => l.text)
      : (lyricsData.plainLyrics?.split("\n") || []);

    const resultBlocks: string[] = [];

    for (let i = 0; i < lines.length; i++) {
      const orig = lines[i];
      if (!orig.trim()) continue;

      const romaji = showRomanization
        ? lyricsData.lines[i]?.romanization || currentTranslation?.romanizations?.[i]
        : null;
      const trans = currentTranslation?.translations?.[i];

      const parts = [orig];
      if (romaji) parts.push(`(${romaji})`);
      if (trans) parts.push(`→ ${trans}`);

      resultBlocks.push(parts.join("\n"));
    }

    textToCopy = resultBlocks.join("\n\n");
    navigator.clipboard.writeText(textToCopy).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const isFirstScrollRef = useRef<boolean>(true);
  const isAutoScrollingRef = useRef<boolean>(false);
  const autoScrollTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (!isOpen) {
      isFirstScrollRef.current = true;
      setUserHasScrolled(false);
    }
  }, [isOpen]);

  // Smoothly auto-scroll active lyric into exact vertical center
  useEffect(() => {
    if (
      !isOpen ||
      viewMode !== "karaoke" ||
      userHasScrolled ||
      activeLineIndex < 0 ||
      !activeLineRef.current ||
      !lyricsContainerRef.current
    ) {
      return;
    }

    const container = lyricsContainerRef.current;
    const activeEl = activeLineRef.current;

    const containerRect = container.getBoundingClientRect();
    const activeRect = activeEl.getBoundingClientRect();

    // Exact vertical difference between active line center and container center
    const activeCenter = activeRect.top + activeRect.height / 2;
    const containerCenter = containerRect.top + containerRect.height / 2;
    const diff = activeCenter - containerCenter;

    if (Math.abs(diff) > 2) {
      // Mark as programmatic scroll so user manual scroll handler won't pause auto-centering
      isAutoScrollingRef.current = true;
      if (autoScrollTimeoutRef.current) {
        clearTimeout(autoScrollTimeoutRef.current);
      }
      autoScrollTimeoutRef.current = setTimeout(() => {
        isAutoScrollingRef.current = false;
      }, 700);

      container.scrollBy({
        top: diff,
        behavior: isFirstScrollRef.current ? "auto" : "smooth",
      });
      isFirstScrollRef.current = false;
    }
  }, [activeLineIndex, isOpen, viewMode, userHasScrolled]);

  // Track user manual scrolling to prevent fighting the user while they interact
  const handleUserInteraction = () => {
    if (isAutoScrollingRef.current) return;
    setUserHasScrolled(true);
    if (userScrollTimeoutRef.current) {
      clearTimeout(userScrollTimeoutRef.current);
    }
    userScrollTimeoutRef.current = setTimeout(() => {
      setUserHasScrolled(false);
    }, 4000);
  };

  const resumeAutoScroll = () => {
    setUserHasScrolled(false);
    if (activeLineRef.current && lyricsContainerRef.current) {
      const container = lyricsContainerRef.current;
      const activeEl = activeLineRef.current;
      const containerRect = container.getBoundingClientRect();
      const activeRect = activeEl.getBoundingClientRect();
      const diff = (activeRect.top + activeRect.height / 2) - (containerRect.top + containerRect.height / 2);
      if (Math.abs(diff) > 2) {
        container.scrollBy({
          top: diff,
          behavior: "smooth",
        });
      }
    }
  };

  if (!isOpen) return null;

  const artistUrl = getArtistUrl(
    song.artist_id || song.artists?.[0]?.id,
    song.artist_name
  );

  const progressPercent = duration > 0 ? Math.min(100, (currentTime / duration) * 100) : 0;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200"
      data-interactive="true"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className="w-full max-w-2xl max-h-[92vh] sm:max-h-[88vh] bg-white border-4 border-black flex flex-col relative overflow-hidden"
        role="dialog"
        aria-modal="true"
        aria-label="Karaoke Lyrics"
      >
        {/* Top Header Bar */}
        <div className="bg-[#FFE600] border-b-2 border-black p-3 sm:p-4 flex items-center justify-between gap-3 flex-shrink-0">
          <div className="flex items-center gap-2.5 min-w-0 flex-1">
            <div className="p-1.5 bg-black text-[#FFE600] border border-black flex-shrink-0">
              <Mic2 className="w-5 h-5" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <h2 className="font-black text-base sm:text-lg text-black truncate leading-tight">
                  {song.title}
                </h2>
              </div>
              <div className="text-xs font-bold text-neutral-700 truncate mt-0.5">
                <Link
                  to={artistUrl}
                  onClick={onClose}
                  className="hover:underline hover:text-black cursor-pointer"
                >
                  {song.artist_name}
                </Link>
              </div>
            </div>
          </div>

          {/* Mode Switcher & Close - Icon Only & Responsive on all screens */}
          <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
            {lyricsData?.isSynced && (
              <div className="flex border-2 border-black bg-white">
                <button
                  type="button"
                  onClick={() => setViewMode("karaoke")}
                  className={`p-1.5 sm:p-2 cursor-pointer transition-colors ${
                    viewMode === "karaoke"
                      ? "bg-black text-[#FFE600]"
                      : "bg-white text-black hover:bg-neutral-100"
                  }`}
                  title="Karaoke Mode (Synced)"
                  aria-label="Karaoke Mode"
                >
                  <Mic2 className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode("plain")}
                  className={`p-1.5 sm:p-2 cursor-pointer border-l-2 border-black transition-colors ${
                    viewMode === "plain"
                      ? "bg-black text-[#FFE600]"
                      : "bg-white text-black hover:bg-neutral-100"
                  }`}
                  title="Plain Text Mode"
                  aria-label="Plain Text Mode"
                >
                  <AlignLeft className="w-4 h-4" />
                </button>
              </div>
            )}

            <button
              onClick={onClose}
              id="close-lyrics-modal-btn"
              className="p-1.5 sm:p-2 border-2 border-black bg-white hover:bg-black hover:text-white cursor-pointer transition-colors active:translate-x-0.5 active:translate-y-0.5"
              title="Close lyrics"
              aria-label="Close lyrics"
            >
              <X className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          </div>
        </div>

        {/* Translation & Action Toolbar - Responsive & Icon-Only */}
        {lyricsData && (
          <div className="bg-neutral-100 border-b-2 border-black px-2.5 py-1.5 sm:px-4 sm:py-2 flex items-center justify-between gap-2 text-xs flex-shrink-0">
            {/* Left side: Language Selector & Status */}
            <div className="flex items-center gap-1.5 min-w-0 flex-1">
              <div className="flex items-center gap-1.5 bg-white border-2 border-black px-2 py-1 min-w-0 max-w-[180px] sm:max-w-[240px]">
                <Globe className="w-4 h-4 text-black flex-shrink-0" />
                <select
                  value={selectedLanguage}
                  onChange={(e) => handleLanguageChange(e.target.value)}
                  className="bg-transparent font-black text-xs text-black outline-none cursor-pointer w-full truncate"
                  aria-label="Select Google Translate language"
                  title="Select Google Translate language"
                >
                  <option value="none">Original (No Translation)</option>
                  {SUPPORTED_TRANSLATION_LANGUAGES.map((lang) => (
                    <option key={lang.code} value={lang.code}>
                      {lang.flag} {lang.name}
                    </option>
                  ))}
                </select>
              </div>

              {isTranslating && (
                <span
                  className="p-1 text-black flex-shrink-0"
                  title="Translating with Google Translate..."
                >
                  <Loader2 className="w-4 h-4 animate-spin text-black" />
                </span>
              )}

              {translationError && (
                <span className="text-[10px] font-bold text-red-600 bg-red-50 border border-red-300 px-1.5 py-0.5 truncate max-w-[120px] sm:max-w-none">
                  {translationError}
                </span>
              )}
            </div>

            {/* Right side: Icon-Only Action Buttons */}
            <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
              {/* Follow Song / Re-center Button - In Toolbar, Never Overlaps */}
              {lyricsData.isSynced && viewMode === "karaoke" && (
                <button
                  type="button"
                  onClick={resumeAutoScroll}
                  className={`p-1.5 sm:p-2 border-2 border-black cursor-pointer transition-colors ${
                    userHasScrolled
                      ? "bg-[#FFE600] text-black shadow-sm"
                      : "bg-white text-black hover:bg-neutral-100"
                  }`}
                  title={
                    userHasScrolled
                      ? "Follow song: Paused (Click to re-center)"
                      : "Follow song: Active (Click to re-center)"
                  }
                  aria-label="Follow song"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              )}

              {/* Cara Baca (Romaji / Pinyin / Pronunciation) Button - Icon Only */}
              {hasRomanizationAvailable && (
                <button
                  type="button"
                  onClick={() => setShowRomanization(!showRomanization)}
                  className={`p-1.5 sm:p-2 border-2 border-black cursor-pointer transition-colors ${
                    showRomanization
                      ? "bg-[#FFE600] text-black"
                      : "bg-white text-black hover:bg-neutral-100"
                  }`}
                  title={
                    showRomanization
                      ? `${romanizationLabel}: Active (Click to disable)`
                      : `${romanizationLabel}: Inactive (Click to enable)`
                  }
                  aria-label={romanizationLabel}
                >
                  <BookOpen className="w-4 h-4" />
                </button>
              )}

              {/* Salin Lirik Button - Icon Only */}
              <button
                type="button"
                onClick={handleCopyLyrics}
                className="p-1.5 sm:p-2 border-2 border-black bg-white hover:bg-neutral-100 text-black cursor-pointer transition-colors"
                title={copied ? "Lyrics copied!" : "Copy lyrics"}
                aria-label="Copy lyrics"
              >
                {copied ? (
                  <Check className="w-4 h-4 text-green-600 stroke-[3]" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </button>

              {/* Pengaturan Lirik (Ukuran Huruf & Offset Timing) - Single Icon Button */}
              <button
                type="button"
                id="lyric-settings-btn"
                onClick={() => setShowLyricSettings((prev) => !prev)}
                className={`p-1.5 sm:p-2 border-2 border-black cursor-pointer transition-colors relative flex items-center gap-1 ${
                  showLyricSettings || lyricOffset !== 0
                    ? "bg-[#FFE600] text-black shadow-sm font-black"
                    : "bg-white text-black hover:bg-neutral-100"
                }`}
                title="Pengaturan Lirik (Ukuran Huruf & Offset Timing)"
                aria-label="Pengaturan lirik"
              >
                <Settings
                  className={`w-4 h-4 transition-transform duration-200 ${
                    showLyricSettings ? "rotate-45" : ""
                  }`}
                />
                {lyricOffset !== 0 && (
                  <span className="text-[10px] font-black font-mono">
                    {lyricOffset > 0
                      ? `+${lyricOffset.toFixed(1)}s`
                      : `${lyricOffset.toFixed(1)}s`}
                  </span>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Unified Lyric Settings Panel (Minimalist Icon-Only Controls) */}
        {showLyricSettings && (
          <div
            id="lyric-settings-panel"
            className="bg-[#FFFDE6] border-b-2 border-black px-3 py-2 text-xs animate-in fade-in slide-in-from-top-1 duration-150 flex-shrink-0"
          >
            <div className="flex items-center justify-between gap-3 max-w-xl mx-auto flex-wrap">
              <div className="flex items-center gap-3 sm:gap-5 flex-wrap">
                {/* 1. Pengaturan Ukuran Huruf: [Type Icon] [-] [A] [+] */}
                <div
                  className="flex items-center gap-1.5"
                  title="Ukuran Huruf (A--, A-, A, A+, A++)"
                >
                  <Type className="w-4 h-4 text-black flex-shrink-0" />
                  <div className="inline-flex items-center border-2 border-black bg-white divide-x-2 divide-black shadow-2xs">
                    <button
                      type="button"
                      id="lyric-font-dec-btn"
                      onClick={decreaseFontSize}
                      disabled={fontSizeIndex === 0}
                      className="w-7 h-7 sm:w-8 sm:h-7.5 flex items-center justify-center font-black text-sm text-black hover:bg-neutral-100 disabled:opacity-30 disabled:hover:bg-white cursor-pointer transition-colors active:bg-neutral-200"
                      title="Perkecil huruf"
                      aria-label="Perkecil huruf"
                    >
                      -
                    </button>
                    <div className="px-2.5 h-7 sm:h-7.5 flex items-center justify-center font-mono font-black text-xs sm:text-sm text-black select-none bg-[#FFE600] min-w-[38px] text-center">
                      {FONT_SIZE_LEVELS[fontSizeIndex].badge}
                    </div>
                    <button
                      type="button"
                      id="lyric-font-inc-btn"
                      onClick={increaseFontSize}
                      disabled={fontSizeIndex === FONT_SIZE_LEVELS.length - 1}
                      className="w-7 h-7 sm:w-8 sm:h-7.5 flex items-center justify-center font-black text-sm text-black hover:bg-neutral-100 disabled:opacity-30 disabled:hover:bg-white cursor-pointer transition-colors active:bg-neutral-200"
                      title="Perbesar huruf"
                      aria-label="Perbesar huruf"
                    >
                      +
                    </button>
                  </div>
                </div>

                {/* 2. Pengaturan Offset Timing: [Timer Icon] [-0.1s] [0s] [+0.1s] */}
                {lyricsData?.isSynced && viewMode === "karaoke" && (
                  <div
                    className="flex items-center gap-1.5"
                    title="Offset Timing Sinkronisasi"
                  >
                    <Timer className="w-4 h-4 text-black flex-shrink-0" />
                    <div className="inline-flex items-center border-2 border-black bg-white divide-x-2 divide-black shadow-2xs">
                      <button
                        type="button"
                        onClick={() => updateOffset(lyricOffset - 0.1)}
                        className="px-2 h-7 sm:h-7.5 flex items-center justify-center font-mono font-bold text-xs text-black hover:bg-neutral-100 active:bg-neutral-200 cursor-pointer transition-colors"
                        title="Perlambat 0.1s (-0.1s)"
                        aria-label="Perlambat 0.1 detik"
                      >
                        -0.1s
                      </button>

                      <button
                        type="button"
                        onClick={() => updateOffset(0)}
                        className={`px-2.5 h-7 sm:h-7.5 flex items-center justify-center font-mono font-black text-xs min-w-[48px] text-center cursor-pointer transition-colors select-none ${
                          lyricOffset !== 0
                            ? "bg-[#FFE600] text-black hover:bg-[#ffe000]"
                            : "bg-white text-neutral-800"
                        }`}
                        title={
                          lyricOffset !== 0
                            ? "Klik untuk reset ke 0s"
                            : "Offset normal (0s)"
                        }
                        aria-label="Reset offset ke 0s"
                      >
                        {lyricOffset === 0
                          ? "0s"
                          : lyricOffset > 0
                          ? `+${lyricOffset.toFixed(1)}s`
                          : `${lyricOffset.toFixed(1)}s`}
                      </button>

                      <button
                        type="button"
                        onClick={() => updateOffset(lyricOffset + 0.1)}
                        className="px-2 h-7 sm:h-7.5 flex items-center justify-center font-mono font-bold text-xs text-black hover:bg-neutral-100 active:bg-neutral-200 cursor-pointer transition-colors"
                        title="Percepat 0.1s (+0.1s)"
                        aria-label="Percepat 0.1 detik"
                      >
                        +0.1s
                      </button>
                    </div>
                  </div>
                )}
              </div>

              {/* Close Button */}
              <button
                type="button"
                onClick={() => setShowLyricSettings(false)}
                className="p-1 border border-black bg-white hover:bg-black hover:text-white transition-colors cursor-pointer text-xs ml-auto"
                title="Tutup Pengaturan Lirik"
                aria-label="Tutup Pengaturan Lirik"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        )}

        {/* Main Lyrics Content Area */}
        <div
          ref={lyricsContainerRef}
          onScroll={handleUserInteraction}
          onWheel={handleUserInteraction}
          onTouchMove={handleUserInteraction}
          className="flex-1 overflow-y-auto px-4 sm:px-8 select-text relative scroll-smooth bg-neutral-50/50"
        >
          {loading && (
            <div className="py-12 space-y-4 text-center">
              <div className="inline-block p-3 bg-[#FFE600] border-2 border-black animate-spin">
                <Mic2 className="w-6 h-6 text-black" />
              </div>
              <p className="font-black text-sm text-neutral-800">
                Loading karaoke lyrics...
              </p>
              <div className="max-w-md mx-auto space-y-2 opacity-50">
                <div className="h-4 bg-neutral-300 rounded border border-neutral-400 w-3/4 mx-auto animate-pulse" />
                <div className="h-4 bg-neutral-300 rounded border border-neutral-400 w-1/2 mx-auto animate-pulse" />
                <div className="h-4 bg-neutral-300 rounded border border-neutral-400 w-2/3 mx-auto animate-pulse" />
              </div>
            </div>
          )}

          {!loading && error && (
            <div className="py-12 text-center max-w-sm mx-auto space-y-3">
              <div className="w-12 h-12 mx-auto bg-neutral-100 border-2 border-black flex items-center justify-center">
                <AlignLeft className="w-6 h-6 text-neutral-500" />
              </div>
              <h3 className="font-black text-base text-black">Lyrics Not Available</h3>
              <p className="text-xs font-semibold text-neutral-600">
                Synced lyrics for this song are not yet available in the database.
              </p>
              <a
                href={`https://www.google.com/search?q=${encodeURIComponent(`${song.title} ${song.artist_name} lyrics`)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block px-3 py-1.5 border-2 border-black bg-[#FFE600] text-black font-black text-xs hover:bg-black hover:text-[#FFE600] transition-colors cursor-pointer"
              >
                Search Lyrics on Google
              </a>
            </div>
          )}

          {!loading && !error && lyricsData && (
            <>
              {/* Karaoke Synced View */}
              {viewMode === "karaoke" && lyricsData.lines.length > 0 ? (
                <div className="flex flex-col items-center justify-center space-y-2 sm:space-y-3 text-center min-h-full py-[38vh]">
                  {lyricsData.lines.map((line, idx) => {
                    const isActive = idx === activeLineIndex;

                    const romajiText = showRomanization
                      ? line.romanization || currentTranslation?.romanizations?.[idx]
                      : null;
                    const translatedText = currentTranslation?.translations?.[idx];

                    return (
                      <div
                        key={`${line.time}-${idx}`}
                        ref={isActive ? activeLineRef : null}
                        onClick={() => {
                          setUserHasScrolled(false);
                          onSeek(Math.max(0, line.time - lyricOffset));
                        }}
                        className={`cursor-pointer transition-colors duration-150 py-1 sm:py-1.5 px-3 select-none max-w-2xl w-full ${
                          isActive
                            ? "text-black"
                            : "text-neutral-400 hover:text-neutral-600"
                        }`}
                        title={`Jump to ${formatTime(Math.max(0, line.time - lyricOffset))}`}
                      >
                        {/* 1. Original text */}
                        <div
                          className={`leading-tight transition-colors duration-150 tracking-tight ${
                            isActive
                              ? `${typography.activeMain} text-black`
                              : `${typography.inactiveMain} text-neutral-400 hover:text-neutral-600`
                          }`}
                        >
                          {line.text}
                        </div>

                        {/* 2. Cara Baca (Romaji / Pinyin / Transliterasi) */}
                        {romajiText && (
                          <div
                            className={`mt-0.5 leading-snug transition-colors duration-150 tracking-normal ${
                              isActive
                                ? `${typography.activeRomaji} text-neutral-800`
                                : `${typography.inactiveRomaji} text-neutral-400`
                            }`}
                          >
                            {romajiText}
                          </div>
                        )}

                        {/* 3. Google Translate Translation */}
                        {selectedLanguage !== "none" && translatedText && (
                          <div
                            className={`mt-0.5 italic leading-snug transition-colors duration-150 ${
                              isActive
                                ? `${typography.activeTrans} text-neutral-700`
                                : `${typography.inactiveTrans} text-neutral-400`
                            }`}
                          >
                            {translatedText}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              ) : (
                /* Plain Text View */
                <div className="max-w-xl mx-auto py-6 px-2 space-y-2.5 text-center">
                  {(lyricsData.lines.length > 0
                    ? lyricsData.lines
                    : (lyricsData.plainLyrics?.split("\n") || []).map((text, i) => ({
                        time: i,
                        text,
                        romanization: lyricsData.plainRomanization?.split("\n")?.[i],
                      }))
                  ).map((line, idx) => {
                    const text = typeof line === "string" ? line : line.text;
                    if (!text.trim()) return <div key={idx} className="h-2" />;

                    const romaji = showRomanization
                      ? (typeof line !== "string" && line.romanization) ||
                        currentTranslation?.romanizations?.[idx]
                      : null;
                    const trans = currentTranslation?.translations?.[idx];

                    return (
                      <div key={idx} className="space-y-0.5 py-0.5">
                        <p className="font-bold text-base sm:text-lg text-black leading-tight tracking-tight">
                          {text}
                        </p>
                        {romaji && (
                          <p className="text-xs sm:text-sm font-semibold text-neutral-700 tracking-normal mt-0.5">
                            {romaji}
                          </p>
                        )}
                        {selectedLanguage !== "none" && trans && (
                          <p className="italic text-xs sm:text-sm font-medium text-neutral-600 mt-0.5">
                            {trans}
                          </p>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}
        </div>

        {/* Bottom Integrated Mini Player Bar */}
        <div className="bg-white border-t-2 border-black p-3 sm:px-6 flex-shrink-0">
          {/* Progress Slider */}
          <div className="relative w-full h-2 bg-neutral-200 border border-black cursor-pointer group mb-2.5">
            <div
              className="h-full bg-[#FFE600] border-r-2 border-black relative"
              style={{ width: `${progressPercent}%` }}
            >
              <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 w-3 h-3 bg-black border border-[#FFE600] pointer-events-none" />
            </div>
            <input
              type="range"
              min={0}
              max={duration || 100}
              step={0.5}
              value={currentTime}
              onChange={(e) => onSeek(parseFloat(e.target.value))}
              aria-label="Seek track"
              className="absolute -top-2 -bottom-2 inset-x-0 w-full opacity-0 cursor-pointer z-10"
            />
          </div>

          <div className="flex items-center justify-between gap-2 sm:gap-3">
            {/* Thumbnail & Title */}
            <div className="flex items-center gap-2 sm:gap-2.5 min-w-0 max-w-[120px] sm:max-w-[200px] md:max-w-xs">
              <img
                src={formatThumbnailUrl(song.thumbnail, 60, 60)}
                alt={song.title}
                className="w-7 h-7 sm:w-8 sm:h-8 border border-black object-cover flex-shrink-0"
              />
              <div className="min-w-0">
                <p className="font-black text-xs text-black truncate">{song.title}</p>
                <p className="text-[10px] font-bold text-neutral-600 truncate">{song.artist_name}</p>
              </div>
            </div>

            {/* Central Controls */}
            <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
              <button
                type="button"
                onClick={onPrev}
                disabled={!canPrev}
                className="p-1 sm:p-1.5 border-2 border-black bg-white hover:bg-neutral-100 disabled:opacity-30 cursor-pointer"
                title="Previous track"
                aria-label="Previous track"
              >
                <SkipBack className="w-3.5 h-3.5 fill-current text-black" />
              </button>

              <button
                type="button"
                onClick={onTogglePlay}
                className="p-1.5 sm:p-2 border-2 border-black bg-[#FFE600] hover:bg-black hover:text-[#FFE600] transition-colors cursor-pointer active:translate-x-0.5 active:translate-y-0.5"
                title={isPlaying ? "Pause" : "Play"}
                aria-label={isPlaying ? "Pause" : "Play"}
              >
                {isPlaying ? (
                  <Pause className="w-4 h-4 fill-current" />
                ) : (
                  <Play className="w-4 h-4 fill-current ml-0.5" />
                )}
              </button>

              <button
                type="button"
                onClick={onNext}
                disabled={!canNext}
                className="p-1 sm:p-1.5 border-2 border-black bg-white hover:bg-neutral-100 disabled:opacity-30 cursor-pointer"
                title="Next track"
                aria-label="Next track"
              >
                <SkipForward className="w-3.5 h-3.5 fill-current text-black" />
              </button>
            </div>

            {/* Time / Volume */}
            <div className="flex items-center gap-1.5 sm:gap-2 text-right flex-shrink-0">
              <span className="font-mono text-[10px] sm:text-xs font-bold text-neutral-700">
                {formatTime(currentTime)} / {formatTime(duration)}
              </span>
              <button
                type="button"
                onClick={onToggleMute}
                className="hidden sm:inline-flex p-1 border-2 border-black bg-white hover:bg-neutral-100 cursor-pointer"
                title={isMuted ? "Unmute" : "Mute"}
                aria-label={isMuted ? "Unmute" : "Mute"}
              >
                {isMuted || volume === 0 ? (
                  <VolumeX className="w-3.5 h-3.5 text-black" />
                ) : (
                  <Volume2 className="w-3.5 h-3.5 text-black" />
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
