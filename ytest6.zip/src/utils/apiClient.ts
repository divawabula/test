import { decryptPayload, isEncryptedPayload } from "./crypto";

/**
 * Universal API fetcher with automatic AES-256 Symmetric Decryption.
 * Seamlessly handles encrypted and plain payloads.
 */
export async function apiFetch<T = any>(
  input: RequestInfo | URL,
  init?: RequestInit
): Promise<T> {
  const res = await fetch(input, init);

  if (!res.ok) {
    try {
      const errorJson = await res.json();
      const decrypted = isEncryptedPayload(errorJson)
        ? await decryptPayload(errorJson)
        : errorJson;
      throw new Error(
        decrypted.error || decrypted.detail || `Request failed with status ${res.status}`
      );
    } catch (parseErr: any) {
      if (parseErr.message && !parseErr.message.includes("status")) {
        throw parseErr;
      }
      throw new Error(`HTTP error ${res.status}`);
    }
  }

  const rawJson = await res.json();

  if (isEncryptedPayload(rawJson)) {
    return await decryptPayload<T>(rawJson);
  }

  return rawJson as T;
}
