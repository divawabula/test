import React, { useState } from "react";
import { Download, Loader2, Sparkles, AlertTriangle, Play, Pause, Cookie, Music, FileAudio, Disc, ShieldCheck } from "lucide-react";
import { DownloadResponse, AudioFormat } from "../types";
import { secureFetch } from "../utils/crypto";

interface OneClickDownloaderProps {
  onDownloadSuccess: () => void;
  onOpenCookies: () => void;
}

export const OneClickDownloader: React.FC<OneClickDownloaderProps> = ({
  onDownloadSuccess,
  onOpenCookies,
}) => {
  const [urlInput, setUrlInput] = useState("");
  const [selectedFormat, setSelectedFormat] = useState<AudioFormat>("mp3");
  const [loading, setLoading] = useState(false);
  const [statusStep, setStatusStep] = useState<string>("");
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<DownloadResponse | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [audioEl, setAudioEl] = useState<HTMLAudioElement | null>(null);
  const [buttonErrorText, setButtonErrorText] = useState<string | null>(null);

  // Example requested by user
  const EXAMPLE_ID = "NDLsmKPOPyE";

  const handleUseExample = () => {
    setUrlInput(EXAMPLE_ID);
    setError(null);
    setButtonErrorText(null);
  };

  const handleDownload = async (inputVal?: string) => {
    const target = (inputVal || urlInput).trim();
    if (!target) {
      setError("Please enter a YouTube Music URL or video ID.");
      setButtonErrorText("Error: Empty Input");
      setTimeout(() => setButtonErrorText(null), 4000);
      return;
    }

    setLoading(true);
    setError(null);
    setButtonErrorText(null);
    setResult(null);
    setIsPlaying(false);
    setStatusStep(
      selectedFormat === "webm"
        ? "Mengunduh stream asli WebM langsung tanpa metadata..."
        : `Memeriksa cache & metadata YouTube (${selectedFormat.toUpperCase()})...`
    );

    try {
      // Execute download with AES-256 encrypted payload
      const res = await secureFetch("/api/download", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ urlOrId: target, format: selectedFormat }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Failed to download audio");
      }

      setResult(data);
      onDownloadSuccess();
      setStatusStep(
        data.cached
          ? `Cache Hit! Durasi penyimpanan diperpanjang 15 menit (${selectedFormat.toUpperCase()}).`
          : selectedFormat === "webm"
          ? "Download WebM Selesai (Audio Asli Tanpa Metadata Tag)!"
          : `Download & Penanaman Metadata Selesai (${selectedFormat.toUpperCase()})!`
      );
    } catch (err: any) {
      console.error(err);
      const rawMsg = err.message || "An unexpected error occurred while processing request.";
      setError(rawMsg);

      let btnErr = "Error: Download Failed";
      if (rawMsg.toLowerCase().includes("30 minute") || rawMsg.toLowerCase().includes("exceeds")) {
        btnErr = "Error: Exceeds 30 Min Limit";
      } else if (rawMsg.toLowerCase().includes("invalid") || rawMsg.toLowerCase().includes("not found")) {
        btnErr = "Error: Video Not Found";
      } else if (rawMsg.toLowerCase().includes("bot") || rawMsg.toLowerCase().includes("cookies")) {
        btnErr = "Error: Cookies Required";
      }

      setButtonErrorText(btnErr);
      setTimeout(() => {
        setButtonErrorText(null);
      }, 6000);
    } finally {
      setLoading(false);
    }
  };

  const toggleAudio = (url: string) => {
    if (!audioEl) {
      const audio = new Audio(url);
      audio.onended = () => setIsPlaying(false);
      audio.play();
      setAudioEl(audio);
      setIsPlaying(true);
    } else {
      if (isPlaying) {
        audioEl.pause();
        setIsPlaying(false);
      } else {
        audioEl.play();
        setIsPlaying(true);
      }
    }
  };

  return (
    <div className="w-full bg-white border-2 border-black p-4 sm:p-6 space-y-5">
      {/* Title & Badge */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b-2 border-black pb-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-base sm:text-lg font-black tracking-tight uppercase text-black">
              Satu Klik Unduh Audio YouTube Music
            </h2>
            <span className="bg-[#FFE500] text-black border-2 border-black px-2 py-0.5 text-[10px] font-black uppercase">
              1-Click
            </span>
            <span className="bg-black text-[#FFE500] px-2 py-0.5 text-[10px] font-mono font-bold uppercase">
              MP3 &bull; WEBM &bull; M4A
            </span>
          </div>
          <p className="text-xs text-zinc-600 font-medium mt-0.5">
            Pilih format audio yang diinginkan: <strong className="text-black">MP3 (Best Audio)</strong>, <strong className="text-black">WebM (Langsung Tanpa Metadata)</strong>, atau <strong className="text-black">M4A (AAC)</strong>.
          </p>
        </div>

        {/* Quick Example Button */}
        <button
          type="button"
          onClick={handleUseExample}
          className="inline-flex items-center gap-1.5 bg-[#fafafa] hover:bg-[#FFE500] border-2 border-black px-3 py-1 text-xs font-bold transition-colors cursor-pointer"
        >
          <Sparkles className="w-3.5 h-3.5 text-black" />
          <span>Contoh: NDLsmKPOPyE (キセキ)</span>
        </button>
      </div>

      {/* Format Selector Bar: MP3, WebM, M4A */}
      <div className="space-y-1">
        <label className="text-[11px] font-black uppercase tracking-wider text-black block">
          Pilih Format Output Audio
        </label>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          {/* MP3 Option */}
          <button
            type="button"
            onClick={() => setSelectedFormat("mp3")}
            className={`px-3 py-2 border-2 border-black text-xs font-black uppercase tracking-wider flex items-center justify-between gap-2 cursor-pointer transition-colors ${
              selectedFormat === "mp3"
                ? "bg-black text-[#FFE500]"
                : "bg-white text-black hover:bg-zinc-100"
            }`}
          >
            <div className="flex items-center gap-1.5">
              <FileAudio className="w-4 h-4" />
              <span>MP3</span>
            </div>
            <span className={`text-[9px] px-1 py-0.2 font-mono font-bold ${
              selectedFormat === "mp3" ? "bg-[#FFE500] text-black" : "bg-zinc-200 text-zinc-800"
            }`}>
              Best Audio + Tag
            </span>
          </button>

          {/* WebM Option (Requested: Direct without metadata) */}
          <button
            type="button"
            onClick={() => setSelectedFormat("webm")}
            className={`px-3 py-2 border-2 border-black text-xs font-black uppercase tracking-wider flex items-center justify-between gap-2 cursor-pointer transition-colors ${
              selectedFormat === "webm"
                ? "bg-black text-[#FFE500]"
                : "bg-white text-black hover:bg-zinc-100"
            }`}
          >
            <div className="flex items-center gap-1.5">
              <Disc className="w-4 h-4" />
              <span>WebM</span>
            </div>
            <span className={`text-[9px] px-1 py-0.2 font-mono font-bold ${
              selectedFormat === "webm" ? "bg-[#FFE500] text-black" : "bg-zinc-200 text-zinc-800"
            }`}>
              Langsung (No Tags)
            </span>
          </button>

          {/* M4A Option */}
          <button
            type="button"
            onClick={() => setSelectedFormat("m4a")}
            className={`px-3 py-2 border-2 border-black text-xs font-black uppercase tracking-wider flex items-center justify-between gap-2 cursor-pointer transition-colors ${
              selectedFormat === "m4a"
                ? "bg-black text-[#FFE500]"
                : "bg-white text-black hover:bg-zinc-100"
            }`}
          >
            <div className="flex items-center gap-1.5">
              <Music className="w-4 h-4" />
              <span>M4A</span>
            </div>
            <span className={`text-[9px] px-1 py-0.2 font-mono font-bold ${
              selectedFormat === "m4a" ? "bg-[#FFE500] text-black" : "bg-zinc-200 text-zinc-800"
            }`}>
              AAC + Tag
            </span>
          </button>
        </div>
      </div>

      {/* Input Bar */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleDownload();
        }}
        className="space-y-2"
      >
        <div className="flex flex-col sm:flex-row gap-2">
          <div className="relative flex-1">
            <input
              type="text"
              value={urlInput}
              onChange={(e) => setUrlInput(e.target.value)}
              placeholder="Masukkan link YouTube Music (contoh: https://music.youtube.com/watch?v=NDLsmKPOPyE)"
              disabled={loading}
              className="w-full px-3.5 py-3 border-2 border-black bg-white text-xs sm:text-sm font-medium text-black placeholder:text-zinc-400 focus:outline-none"
            />
          </div>

          <button
            type="submit"
            disabled={loading || !urlInput.trim()}
            className={`px-6 py-3 border-2 border-black text-xs sm:text-sm font-black uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
              buttonErrorText
                ? "bg-[#EF4444] text-white hover:bg-red-700"
                : "bg-[#FFE500] hover:bg-[#ffd900] active:bg-black active:text-white text-black"
            }`}
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Processing {selectedFormat.toUpperCase()}...</span>
              </>
            ) : buttonErrorText ? (
              <>
                <AlertTriangle className="w-4 h-4 text-white" />
                <span>{buttonErrorText}</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Unduh {selectedFormat.toUpperCase()}</span>
              </>
            )}
          </button>
        </div>

        {/* Info label under input */}
        <div className="flex flex-wrap items-center justify-between text-[11px] text-zinc-600 font-medium pt-1">
          <span>
            Mode: <strong>{selectedFormat.toUpperCase()}</strong> &bull; {selectedFormat === "webm" ? "bestaudio[ext=webm] tanpa tagging" : "Dengan penanaman metadata otomatis"} &bull; <strong>Maks. 30 menit</strong>
          </span>
          <span className="font-mono">Cache TTL: 15 Menit &bull; Auto Reset jika Diulang</span>
        </div>
      </form>

      {/* Loading Progress State */}
      {loading && (
        <div className="p-4 border-2 border-black bg-[#FFE500]/20 flex items-center gap-3">
          <Loader2 className="w-5 h-5 text-black animate-spin shrink-0" />
          <div className="overflow-x-auto">
            <p className="text-xs font-black text-black uppercase tracking-wide">
              {statusStep || `Processing ${selectedFormat.toUpperCase()} request...`}
            </p>
            <p className="text-[11px] text-zinc-700 font-mono mt-0.5">
              {selectedFormat === "webm"
                ? `yt-dlp -f "bestaudio[ext=webm]" --match-filter "duration <= 1800"`
                : selectedFormat === "mp3"
                ? `yt-dlp -f "bestaudio/best" -x --audio-format mp3 --audio-quality 0 --match-filter "duration <= 1800"`
                : `yt-dlp -f "ba[acodec^=mp4a.40.]/ba" --match-filter "duration <= 1800"`}
            </p>
          </div>
        </div>
      )}

      {/* Error Message */}
      {error && (
        <div className="p-4 border-2 border-black bg-[#EF4444] text-white space-y-2">
          <div className="flex items-start gap-2.5">
            <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5 text-white" />
            <div className="space-y-1">
              <h4 className="text-xs font-black uppercase tracking-wider">
                Download Error
              </h4>
              <p className="text-xs leading-relaxed font-medium">
                {error}
              </p>
            </div>
          </div>

          {(error.includes("Sign in to confirm you’re not a bot") ||
            error.includes("cookies") ||
            error.includes("bot")) && (
            <div className="pt-2 border-t border-white/40 flex flex-wrap items-center justify-between gap-2">
              <span className="text-[11px]">
                YouTube memerlukan otentikasi bot via <code className="bg-black/30 px-1">cookies.txt</code>.
              </span>
              <button
                type="button"
                onClick={onOpenCookies}
                className="px-2.5 py-1 bg-white text-black border-2 border-black text-xs font-black uppercase flex items-center gap-1 cursor-pointer"
              >
                <Cookie className="w-3.5 h-3.5" />
                <span>Atur cookies.txt Sekarang</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* Result Card */}
      {result && (
        <div className="border-2 border-black bg-[#FAFAFA] p-4 sm:p-5 space-y-4">
          {/* Status banner */}
          <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b-2 border-black">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 bg-[#00AA00] inline-block border border-black"></span>
              <span className="text-xs font-black uppercase text-black tracking-wide">
                {result.cached
                  ? `Cache Hit (${result.format.toUpperCase()}) &bull; Durasi Diperpanjang 15 Menit`
                  : result.format === "webm"
                  ? `Berhasil Diunduh Langsung (${result.format.toUpperCase()} No Metadata)`
                  : `Berhasil Diunduh & Ditanam Meta Tag (${result.format.toUpperCase()})`}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-[11px] font-mono bg-black text-[#FFE500] border border-black px-2 py-0.5 font-bold uppercase">
                {result.format.toUpperCase()} &bull; {(result.fileSize / (1024 * 1024)).toFixed(2)} MB
              </span>
            </div>
          </div>

          {/* Song Card Layout */}
          <div className="flex flex-col sm:flex-row items-start gap-4">
            {/* Artwork */}
            <div className="w-28 h-28 shrink-0 border-2 border-black bg-zinc-200 overflow-hidden relative">
              {result.metadata.coverArtUrl ? (
                <img
                  src={result.metadata.coverArtUrl}
                  alt={result.metadata.title}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center font-bold text-xs">
                  {result.format.toUpperCase()}
                </div>
              )}
              <span className="absolute bottom-0 right-0 bg-black text-[#FFE500] text-[9px] font-mono font-bold px-1 border-t-2 border-l-2 border-black">
                {result.format.toUpperCase()}
              </span>
            </div>

            {/* Metadata Fields */}
            <div className="flex-1 min-w-0 space-y-2">
              <div>
                <span className="text-[10px] font-black text-zinc-500 uppercase tracking-wider block">
                  Judul Lagu
                </span>
                <h3 className="text-sm sm:text-base font-black text-black truncate">
                  {result.metadata.title}
                </h3>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                <div>
                  <span className="text-[10px] font-bold text-zinc-500 uppercase block">Artis</span>
                  <p className="font-bold text-black truncate">{result.metadata.artist}</p>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-zinc-500 uppercase block">Format</span>
                  <p className="font-bold text-black truncate">
                    {result.format === "webm" ? "WebM (Audio Direct)" : result.format.toUpperCase()}
                  </p>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-zinc-500 uppercase block">Tahun / Album</span>
                  <p className="font-bold text-black truncate">
                    {result.metadata.year || "2019"} &bull; {result.metadata.album || "Single"}
                  </p>
                </div>
                <div>
                  <span className="text-[10px] font-bold text-zinc-500 uppercase block">Durasi</span>
                  <p className="font-bold text-black truncate">
                    {result.metadata.duration
                      ? `${Math.floor(result.metadata.duration / 60)}:${(result.metadata.duration % 60) < 10 ? "0" : ""}${result.metadata.duration % 60}`
                      : "< 30:00"}
                  </p>
                </div>
              </div>

              {result.format === "webm" ? (
                <div className="text-[11px] text-amber-700 bg-amber-50 border border-amber-300 p-1.5 font-medium">
                  Catatan: Sesuai konfigurasi, file WebM diunduh langsung tanpa penanaman metadata ID3/cover art.
                </div>
              ) : (
                <div className="text-[10px] text-zinc-500 font-mono truncate">
                  <span className="font-bold text-zinc-700">Cover: </span>
                  {result.metadata.coverArtUrl}
                </div>
              )}
            </div>
          </div>

          {/* Action Buttons: Audio Preview & Download */}
          <div className="flex flex-wrap items-center gap-2 pt-2 border-t-2 border-black">
            {/* Play Preview */}
            <button
              type="button"
              onClick={() => toggleAudio(result.downloadUrl)}
              className="px-4 py-2 bg-white hover:bg-zinc-100 border-2 border-black text-xs font-black uppercase flex items-center gap-2 cursor-pointer transition-colors"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              <span>{isPlaying ? "Jeda Audio" : "Putar Audio"}</span>
            </button>

            {/* Direct Download File */}
            <a
              href={result.downloadUrl}
              download={result.fileName.startsWith("[ytcat.anaku.web.id]") ? result.fileName : `[ytcat.anaku.web.id] ${result.fileName}`}
              onClick={() => {
                secureFetch("/api/cache/renew", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({ videoId: result.metadata.id, format: result.format }),
                }).then(() => onDownloadSuccess());
              }}
              className="px-5 py-2 bg-[#FFE500] hover:bg-[#edd100] border-2 border-black text-xs font-black uppercase flex items-center gap-2 cursor-pointer transition-colors text-black"
            >
              <Download className="w-4 h-4" />
              <span>Unduh File Audio (.{result.format})</span>
            </a>

            <div className="ml-auto flex items-center gap-2 text-[11px] font-mono text-zinc-600 font-bold">
              <span className="bg-[#009900]/10 text-[#007700] border border-[#009900]/30 px-1.5 py-0.5 text-[10px] flex items-center gap-1 font-bold">
                <ShieldCheck className="w-3 h-3" />
                <span>AES-256 Secured</span>
              </span>
              <span>ID: {result.metadata.id} &bull; {result.format.toUpperCase()}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
