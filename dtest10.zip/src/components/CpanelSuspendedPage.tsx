import React, { useEffect, useState } from "react";

export const CpanelSuspendedPage: React.FC = () => {
  const [hostname, setHostname] = useState<string>("");

  useEffect(() => {
    if (typeof window !== "undefined") {
      document.title = "Account Suspended";
      setHostname(window.location.hostname || "localhost");
    }
  }, []);

  return (
    <div className="min-h-screen bg-[#eceff1] text-[#293a4c] flex flex-col justify-between font-sans selection:bg-[#ff6c2c] selection:text-white antialiased">
      {/* Top subtle bar */}
      <div className="h-1.5 w-full bg-[#ff6c2c]"></div>

      {/* Main Center Box */}
      <div className="flex-1 flex items-center justify-center p-4 sm:p-6">
        <div className="w-full max-w-lg bg-white border border-[#d2d8dc] rounded-md shadow-sm overflow-hidden">
          {/* Card Header with cPanel Logo */}
          <div className="p-6 sm:p-8 text-center border-b border-[#e5e9ec] bg-white">
            <div className="flex justify-center mb-6">
              {/* Authentic cPanel Brand SVG */}
              <div className="flex items-center gap-2.5">
                <svg
                  className="w-10 h-10"
                  viewBox="0 0 100 100"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <rect width="100" height="100" rx="20" fill="#FF6C2C" />
                  <path
                    d="M32 68C23.163 68 16 60.837 16 52C16 43.163 23.163 36 32 36C38.2 36 43.5 39.5 46.1 44.6L39.8 47.7C38.4 44.8 35.4 43 32 43C27.029 43 23 47.029 23 52C23 56.971 27.029 61 32 61C35.4 61 38.4 59.2 39.8 56.3L46.1 59.4C43.5 64.5 38.2 68 32 68Z"
                    fill="white"
                  />
                  <path
                    d="M62 36V43H70C74.971 43 79 47.029 79 52C79 56.971 74.971 61 70 61H62V68H55V36H62ZM62 54H70C71.105 54 72 53.105 72 52C72 50.895 71.105 50 70 50H62V54Z"
                    fill="white"
                  />
                </svg>
                <div className="text-left leading-none">
                  <span className="text-2xl font-extrabold tracking-tight text-[#293a4c]">
                    cPanel<sup className="text-[10px] font-normal text-zinc-400">®</sup>
                  </span>
                </div>
              </div>
            </div>

            {/* Warning Indicator */}
            <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-[#FFF2EB] text-[#FF6C2C] mb-4 border border-[#FFD9C6]">
              <svg
                className="w-7 h-7"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                strokeWidth="2.2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
                <line x1="12" y1="9" x2="12" y2="13" />
                <line x1="12" y1="17" x2="12.01" y2="17" />
              </svg>
            </div>

            <h1 className="text-2xl sm:text-3xl font-bold text-[#1f2d3d] tracking-tight mb-2">
              Account Suspended
            </h1>
            <p className="text-base text-[#475f7b] font-medium leading-relaxed">
              This Account has been suspended.
            </p>
            <p className="text-sm text-[#6b7c92] mt-1 leading-relaxed">
              Contact your hosting provider for more information.
            </p>
          </div>

          {/* Technical Info Box */}
          <div className="bg-[#f8fafc] px-6 py-4 text-xs text-[#5a6a7e] flex flex-col sm:flex-row items-center justify-between gap-2 border-t border-[#edf2f6]">
            <div className="flex items-center gap-1.5 font-mono">
              <span className="w-2 h-2 rounded-full bg-amber-500 inline-block"></span>
              <span>Host:</span>
              <span className="font-semibold text-[#293a4c]">{hostname || "server"}</span>
            </div>
            <div className="text-[11px] text-zinc-500 font-mono">
              HTTP 403 / Status: SUSPENDED
            </div>
          </div>
        </div>
      </div>

      {/* cPanel Standard Footer */}
      <footer className="w-full text-center py-4 px-4 text-xs text-[#7d8b99]">
        <p>
          Copyright © {new Date().getFullYear()} cPanel, L.L.C. &bull; All Rights Reserved.
        </p>
      </footer>
    </div>
  );
};
