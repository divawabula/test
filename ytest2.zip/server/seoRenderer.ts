import { Request } from "express";
import { getHomeTopSongs, getArtistDetails, slugify } from "./ytmusic";

interface PageMeta {
  title: string;
  description: string;
  canonicalUrl: string;
  imageUrl: string;
  ogType: string;
  jsonLd: Record<string, any>[];
  noscriptHtml: string;
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

export async function resolvePageMeta(req: Request): Promise<PageMeta> {
  const host = req.get("host") || "localhost:3000";
  const protocol =
    req.protocol === "https" || req.headers["x-forwarded-proto"] === "https"
      ? "https"
      : "http";
  const baseUrl = `${protocol}://${host}`;
  const defaultImage =
    "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=1200&auto=format&fit=crop&q=80";

  // 1. Check if route is /artist/:artistId/:slug or /artist/:idOrName
  const artistMatch = req.path.match(/^\/artist\/([^/?#]+)(?:\/([^/?#]+))?/i);
  if (artistMatch && artistMatch[1]) {
    const rawParam = decodeURIComponent(artistMatch[1]).trim();
    try {
      const artist = await getArtistDetails(rawParam);
      if (artist) {
        const topSongTitles = artist.songs.slice(0, 5).map((s) => s.title).join(", ");
        const pageTitle = `${artist.name} - Songs & Full Album | YTcat`;
        const pageDesc = topSongTitles
          ? `Complete song list of ${artist.name} (${artist.total_songs} songs) including ${topSongTitles}. Free streaming and fast playback.`
          : `Complete song list and discography for ${artist.name} (${artist.total_songs} songs). High-quality music streaming and playback.`;
        const cleanSlug = slugify(artist.name) || slugify(rawParam);
        const canonicalUrl = artist.id
          ? `${baseUrl}/artist/${artist.id}/${cleanSlug}`
          : `${baseUrl}/artist/${cleanSlug}`;
        const imageUrl = artist.banner || artist.thumbnail || defaultImage;

        // Structured JSON-LD for MusicGroup & BreadcrumbList
        const musicGroupSchema = {
          "@context": "https://schema.org",
          "@type": "MusicGroup",
          name: artist.name,
          url: canonicalUrl,
          image: artist.thumbnail || defaultImage,
          description: artist.description || pageDesc,
          numTracks: artist.total_songs,
          track: artist.songs.slice(0, 30).map((s) => ({
            "@type": "MusicRecording",
            name: s.title,
            duration: `PT${Math.floor(s.duration_seconds / 60)}M${s.duration_seconds % 60}S`,
            byArtist: {
              "@type": "MusicGroup",
              name: artist.name,
            },
          })),
        };

        const breadcrumbSchema = {
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          itemListElement: [
            {
              "@type": "ListItem",
              position: 1,
              name: "Home",
              item: `${baseUrl}/`,
            },
            {
              "@type": "ListItem",
              position: 2,
              name: "Artists",
              item: `${baseUrl}/`,
            },
            {
              "@type": "ListItem",
              position: 3,
              name: artist.name,
              item: canonicalUrl,
            },
          ],
        };

        const noscriptSongsList = artist.songs
          .slice(0, 25)
          .map(
            (s) =>
              `<li><strong>${escapeHtml(s.title)}</strong> (${escapeHtml(s.duration)})</li>`
          )
          .join("\n");

        return {
          title: pageTitle,
          description: pageDesc,
          canonicalUrl,
          imageUrl,
          ogType: "music.musician",
          jsonLd: [musicGroupSchema, breadcrumbSchema],
          noscriptHtml: `
            <article class="crawler-artist-profile" style="max-width:800px;margin:20px auto;padding:20px;font-family:sans-serif;">
              <h1>${escapeHtml(artist.name)} - Complete Song List</h1>
              <p>${escapeHtml(artist.subscribers ? `Audience: ${artist.subscribers}` : "")}</p>
              ${artist.description ? `<p>${escapeHtml(artist.description)}</p>` : ""}
              <h2>Song Collection (${artist.total_songs} Songs)</h2>
              <ol>${noscriptSongsList}</ol>
            </article>
          `,
        };
      }
    } catch (err) {
      console.warn("Could not resolve artist SEO meta:", err);
    }
  }

  // 3. Check if route is /search/:query or /search?q=query or /?q=query
  const rawQ = typeof req.query.q === "string" ? req.query.q.trim() : "";
  const searchMatch = req.path.match(/^\/search\/([^/?#]+)/i);
  const searchParam = rawQ || (searchMatch ? decodeURIComponent(searchMatch[1]).trim() : "");

  if (searchParam) {
    const isYt = /(?:youtu\.be\/|youtube\.com\/)/i.test(searchParam);
    const cleanSearch = isYt ? searchParam : (rawQ || searchParam.replace(/[-_+]/g, " ").trim());
    const searchCanonical = `${baseUrl}/search?q=${encodeURIComponent(cleanSearch)}`;
    const searchTitle = isYt
      ? `Play Song from YouTube Link | YTcat`
      : `Search Songs "${cleanSearch}" | YTcat`;
    const searchDesc = isYt
      ? `Play clear audio directly from YouTube link. High-quality music streaming seamlessly on YTcat.`
      : `Search results and discography for "${cleanSearch}". Stream instantly on YTcat without buffering.`;

    return {
      title: searchTitle,
      description: searchDesc,
      canonicalUrl: searchCanonical,
      imageUrl: defaultImage,
      ogType: "website",
      jsonLd: [
        {
          "@context": "https://schema.org",
          "@type": "SearchResultsPage",
          name: searchTitle,
          url: searchCanonical,
          description: searchDesc,
        },
      ],
      noscriptHtml: `
        <div class="crawler-search" style="max-width:800px;margin:20px auto;padding:20px;font-family:sans-serif;">
          <h1>${escapeHtml(searchTitle)}</h1>
          <p>${escapeHtml(searchDesc)}</p>
        </div>
      `,
    };
  }

  // Default Home Page Meta
  let topSongsNames = "";
  try {
    const topSongs = await getHomeTopSongs();
    if (topSongs && topSongs.length > 0) {
      topSongsNames = topSongs.slice(0, 5).map((s) => s.title).join(", ");
    }
  } catch {
    // Continue with default
  }

  const homeTitle = "YTcat - Music Player & Downloader";
  const homeDesc = topSongsNames
    ? `Stream trending top hits including ${topSongsNames} on YTcat. Fast, lightweight, and responsive music player.`
    : "Stream official trending hits on YTcat. Fast, lightweight, and responsive music player and downloader.";
  const homeCanonical = `${baseUrl}/`;

  return {
    title: homeTitle,
    description: homeDesc,
    canonicalUrl: homeCanonical,
    imageUrl: defaultImage,
    ogType: "website",
    jsonLd: [
      {
        "@context": "https://schema.org",
        "@type": "WebSite",
        name: "YTcat",
        url: baseUrl,
        description: homeDesc,
      },
    ],
    noscriptHtml: `
      <div class="crawler-fallback" style="max-width:800px;margin:20px auto;padding:20px;font-family:sans-serif;">
        <h1>${escapeHtml(homeTitle)}</h1>
        <p>${escapeHtml(homeDesc)}</p>
      </div>
    `,
  };
}

export function injectMetaIntoHtml(html: string, meta: PageMeta): string {
  // Replace <title>...</title>
  let result = html.replace(/<title>[\s\S]*?<\/title>/i, `<title>${escapeHtml(meta.title)}</title>`);

  // Replace or inject <meta name="description">
  if (result.includes('<meta name="description"')) {
    result = result.replace(
      /<meta\s+name="description"\s+content="[^"]*"\s*\/?>/i,
      `<meta name="description" content="${escapeHtml(meta.description)}" />`
    );
  } else {
    result = result.replace("</head>", `  <meta name="description" content="${escapeHtml(meta.description)}" />\n</head>`);
  }

  // Build new SEO head tags (OG, Twitter, Canonical, JSON-LD)
  const schemaScripts = meta.jsonLd
    .map(
      (schema) =>
        `<script type="application/ld+json">\n${JSON.stringify(schema, null, 2)}\n</script>`
    )
    .join("\n");

  const seoTags = `
    <!-- Dynamic SEO & Open Graph Tags (Server Pre-rendered) -->
    <link rel="canonical" href="${escapeHtml(meta.canonicalUrl)}" />
    <meta property="og:title" content="${escapeHtml(meta.title)}" />
    <meta property="og:description" content="${escapeHtml(meta.description)}" />
    <meta property="og:url" content="${escapeHtml(meta.canonicalUrl)}" />
    <meta property="og:image" content="${escapeHtml(meta.imageUrl)}" />
    <meta property="og:type" content="${escapeHtml(meta.ogType)}" />
    <meta property="og:site_name" content="YTcat" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="${escapeHtml(meta.title)}" />
    <meta name="twitter:description" content="${escapeHtml(meta.description)}" />
    <meta name="twitter:image" content="${escapeHtml(meta.imageUrl)}" />
    <meta name="robots" content="index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1" />
    ${schemaScripts}
  `;

  // Remove previous existing canonical / og / twitter tags in head template to avoid duplicates
  result = result
    .replace(/<link\s+rel="canonical"[\s\S]*?>/gi, "")
    .replace(/<meta\s+property="og:[^"]+"\s+content="[^"]*"\s*\/?>/gi, "")
    .replace(/<meta\s+name="twitter:[^"]+"\s+content="[^"]*"\s*\/?>/gi, "")
    .replace(/<meta\s+name="robots"\s+content="[^"]*"\s*\/?>/gi, "");

  result = result.replace("</head>", `${seoTags}\n</head>`);

  // Inject crawler fallback inside <div id="root">
  if (meta.noscriptHtml) {
    result = result.replace(
      '<div id="root"></div>',
      `<div id="root"><noscript>${meta.noscriptHtml}</noscript></div>`
    );
  }

  return result;
}
