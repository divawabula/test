import { useEffect } from "react";
import { useLocation } from "react-router-dom";

interface SEOProps {
  title: string;
  description: string;
  image?: string;
  type?: "website" | "music.song" | "profile" | "music.group";
  jsonLd?: Record<string, any>;
  canonicalUrl?: string;
}

export default function SEO({
  title,
  description,
  image = "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=1200&auto=format&fit=crop&q=80",
  type = "website",
  jsonLd,
  canonicalUrl,
}: SEOProps) {
  const location = useLocation();

  useEffect(() => {
    // Dynamic Title
    const formattedTitle = title.includes("YTcat")
      ? title
      : `${title} | YTcat`;
    document.title = formattedTitle;

    const origin = window.location.origin;
    const finalCanonical = canonicalUrl
      ? canonicalUrl.startsWith("http")
        ? canonicalUrl
        : `${origin}${canonicalUrl}`
      : `${origin}${location.pathname}${location.search}`;

    // Helper to set or create meta tag
    const setMetaTag = (attributeName: string, attributeValue: string, content: string) => {
      let element = document.querySelector(`meta[${attributeName}="${attributeValue}"]`);
      if (!element) {
        element = document.createElement("meta");
        element.setAttribute(attributeName, attributeValue);
        document.head.appendChild(element);
      }
      element.setAttribute("content", content);
    };

    // Description
    setMetaTag("name", "description", description);

    // Canonical
    let canonical = document.querySelector('link[rel="canonical"]');
    if (!canonical) {
      canonical = document.createElement("link");
      canonical.setAttribute("rel", "canonical");
      document.head.appendChild(canonical);
    }
    canonical.setAttribute("href", finalCanonical);

    // Open Graph
    setMetaTag("property", "og:title", formattedTitle);
    setMetaTag("property", "og:description", description);
    setMetaTag("property", "og:type", type);
    setMetaTag("property", "og:url", finalCanonical);
    setMetaTag("property", "og:image", image);

    // Twitter Card
    setMetaTag("name", "twitter:card", "summary_large_image");
    setMetaTag("name", "twitter:title", formattedTitle);
    setMetaTag("name", "twitter:description", description);
    setMetaTag("name", "twitter:image", image);

    // Structured Data JSON-LD
    const jsonLdScriptId = "app-seo-jsonld";
    let scriptTag = document.getElementById(jsonLdScriptId) as HTMLScriptElement | null;
    if (!scriptTag) {
      scriptTag = document.createElement("script");
      scriptTag.id = jsonLdScriptId;
      scriptTag.type = "application/ld+json";
      document.head.appendChild(scriptTag);
    }

    const defaultSchema = {
      "@context": "https://schema.org",
      "@type": "WebSite",
      name: "YTcat",
      url: origin,
      potentialAction: {
        "@type": "SearchAction",
        target: `${origin}/search?q={search_term_string}`,
        "query-input": "required name=search_term_string",
      },
    };

    scriptTag.textContent = JSON.stringify(jsonLd || defaultSchema);
  }, [title, description, image, type, jsonLd, location]);

  return null;
}
