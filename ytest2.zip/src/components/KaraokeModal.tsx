import React, { useState, useEffect, useRef, useMemo } from "react";
import { Link } from "react-router-dom";
import {
  Mic2,
  X,
  Sparkles,
  Play,
  Pause,
  SkipBack,
  SkipForward,
  RotateCcw,
  AlignLeft,
  Volume2,
  VolumeX,
  Globe,
  BookOpen,
  Copy,
  Check,
  Loader2,
} from "lucide-react";
import {
  Song,
  SongLyricsData,
  LyricLine,
  SUPPORTED_TRANSLATION_LANGUAGES,
} from "../types";
import { apiFetch } from "../utils/apiClient";
import { getArtistUrl } from "../utils/seo";
import { formatThumbnailUrl } from "../utils/thumbnail";

interface KaraokeModalProps {
  isOpen: boolean;
  onClose: () => void;
  song: Song;
  currentTime: number;
  duration: number;
  isPlaying: boolean;
  onTogglePlay: () => void;
  onSeek: (time: number) => void;
  onNext: () => void;
  onPrev: () => void;
  canPrev: boolean;
  canNext: boolean;
  volume: number;
  isMuted: boolean;
  onToggleMute: () => void;
}

export default function KaraokeModal({
  isOpen,
  onClose,
  song,
  currentTime,
  duration,
  isPlaying,
  onTogglePlay,
  onSeek,
  onNext,
  onPrev,
  canPrev,
  canNext,
  volume,
  isMuted,
  onToggleMute,
}: KaraokeModalProps) {
  const [lyricsData, setLyricsData] = useState<SongLyricsData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<"karaoke" | "plain">("karaoke");
  const [userHasScrolled, setUserHasScrolled] = useState(false);

  // Translation & Cara Baca state
  const [selectedLanguage, setSelectedLanguage] = useState<string>("none");
  const [showRomanization, setShowRomanization] = useState<boolean>(true);
  const [isTranslating, setIsTranslating] = useState<boolean>(false);
  const [translationError, setTranslationError] = useState<string | null>(null);
  const [copied, setCopied] = useState<boolean>(false);
  const [translationsCache, setTranslationsCache] = useState<
    Record<string, { translations: string[]; romanizations: string[] }>
  >({});

  const lyricsContainerRef = useRef<HTMLDivElement>(null);
  const activeLineRef = useRef<HTMLDivElement>(null);
  const userScrollTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Format seconds into mm:ss
  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return "0:00";
    const minutes = Math.floor(secs / 60);
    const seconds = Math.floor(secs % 60);
    return `${minutes}:${seconds.toString().padStart(2, "0")}`;
  };

  // Reset states when song changes
  useEffect(() => {
    setSelectedLanguage("none");
    setTranslationsCache({});
    setTranslationError(null);
  }, [song?.id]);

  // Fetch lyrics when modal is open and song changes
  useEffect(() => {
    if (!isOpen || !song?.id) return;

    let isCancelled = false;
    setLoading(true);
    setError(null);

    const queryParams = new URLSearchParams({
      track: song.title || "",
      artist: song.artist_name || "",
    });
    if (song.duration_seconds) {
      queryParams.append("duration", song.duration_seconds.toString());
    }

    apiFetch<any>(`/api/lyrics/${encodeURIComponent(song.id)}?${queryParams}`)
      .then((res) => {
        if (isCancelled) return;
        if (res && res.success && res.data) {
          setLyricsData(res.data);
          setViewMode(res.data.isSynced ? "karaoke" : "plain");
          // If song has romanization (Japanese, Korean, Chinese, etc.), default to show it
          if (res.data.hasRomanization) {
            setShowRomanization(true);
          }
        } else {
          setError((res && res.error) || "Lyrics not found for this track.");
        }
      })
      .catch((err: any) => {
        if (isCancelled) return;
        console.warn("Failed to load lyrics:", err);
        setError(err.message || "Failed to load lyrics.");
      })
      .finally(() => {
        if (!isCancelled) setLoading(false);
      });

    return () => {
      isCancelled = true;
    };
  }, [isOpen, song?.id, song?.title, song?.artist_name]);

  // Handle translation language change using Google Translate
  const handleLanguageChange = async (targetLang: string) => {
    setSelectedLanguage(targetLang);
    setTranslationError(null);

    if (targetLang === "none" || !lyricsData) return;

    // Check in-memory cache first
    if (translationsCache[targetLang]) return;

    setIsTranslating(true);
    try {
      const lines = lyricsData.lines.length > 0
        ? lyricsData.lines.map((l) => l.text)
        : (lyricsData.plainLyrics?.split("\n") || []);

      const res = await apiFetch<any>("/api/lyrics/translate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          songId: song.id,
          targetLang,
          lines,
          plainText: lyricsData.plainLyrics,
        }),
      });

      if (res && res.success && res.data) {
        setTranslationsCache((prev) => ({
          ...prev,
          [targetLang]: {
            translations: res.data.translations || [],
            romanizations: res.data.romanizations || [],
          },
        }));

        // If backend returned romanization and not yet available on original lyrics
        if (res.data.hasRomanization && res.data.romanizations?.length > 0) {
          setShowRomanization(true);
        }
      } else {
        setTranslationError(res?.error || "Failed to translate lyrics");
      }
    } catch (err: any) {
      console.warn("Translation failed:", err);
      setTranslationError("Google Translate is currently busy. Please try another language or try again.");
    } finally {
      setIsTranslating(false);
    }
  };

  // Find active line index based on currentTime
  const activeLineIndex = useMemo(() => {
    if (!lyricsData || !lyricsData.lines || lyricsData.lines.length === 0) {
      return -1;
    }

    const lines = lyricsData.lines;
    // Find the latest line whose timestamp is <= currentTime
    let activeIdx = -1;
    for (let i = 0; i < lines.length; i++) {
      if (currentTime >= lines[i].time - 0.25) {
        activeIdx = i;
      } else {
        break;
      }
    }
    return activeIdx;
  }, [lyricsData, currentTime]);

  // Current active translation data
  const currentTranslation = useMemo(() => {
    if (selectedLanguage === "none" || !translationsCache[selectedLanguage]) {
      return null;
    }
    return translationsCache[selectedLanguage];
  }, [selectedLanguage, translationsCache]);

  // Determine Romanization Label (e.g. Romaji for Japanese, Pinyin for Chinese, Romanization for Korean)
  const romanizationLabel = useMemo(() => {
    if (lyricsData?.romanizationType === "Romaji") return "Romaji (Japanese)";
    if (lyricsData?.romanizationType === "Pinyin") return "Pinyin (Mandarin)";
    if (lyricsData?.romanizationType === "Romanisasi") return "Romanization (Korean)";
    if (lyricsData?.romanizationType === "Transliterasi") return "Transliteration";
    return "Phonetics / Romaji";
  }, [lyricsData?.romanizationType]);

  // Check if romanization is available
  const hasRomanizationAvailable = useMemo(() => {
    if (lyricsData?.hasRomanization) return true;
    if (lyricsData?.lines?.some((l) => !!l.romanization)) return true;
    if (currentTranslation?.romanizations?.some((r) => !!r)) return true;
    return false;
  }, [lyricsData, currentTranslation]);

  // Copy full lyrics to clipboard
  const handleCopyLyrics = () => {
    if (!lyricsData) return;

    let textToCopy = "";
    const lines = lyricsData.lines.length > 0
      ? lyricsData.lines.map((l) => l.text)
      : (lyricsData.plainLyrics?.split("\n") || []);

    const resultBlocks: string[] = [];

    for (let i = 0; i < lines.length; i++) {
      const orig = lines[i];
      if (!orig.trim()) continue;

      const romaji = showRomanization
        ? lyricsData.lines[i]?.romanization || currentTranslation?.romanizations?.[i]
        : null;
      const trans = currentTranslation?.translations?.[i];

      const parts = [orig];
      if (romaji) parts.push(`(${romaji})`);
      if (trans) parts.push(`→ ${trans}`);

      resultBlocks.push(parts.join("\n"));
    }

    textToCopy = resultBlocks.join("\n\n");
    navigator.clipboard.writeText(textToCopy).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  // Smoothly auto-scroll active lyric into view
  useEffect(() => {
    if (
      !isOpen ||
      viewMode !== "karaoke" ||
      userHasScrolled ||
      activeLineIndex < 0 ||
      !activeLineRef.current ||
      !lyricsContainerRef.current
    ) {
      return;
    }

    const container = lyricsContainerRef.current;
    const activeEl = activeLineRef.current;

    const containerHeight = container.clientHeight;
    const activeElTop = activeEl.offsetTop;
    const activeElHeight = activeEl.clientHeight;

    const targetScrollTop = activeElTop - containerHeight / 2 + activeElHeight / 2;

    container.scrollTo({
      top: Math.max(0, targetScrollTop),
      behavior: "smooth",
    });
  }, [activeLineIndex, isOpen, viewMode, userHasScrolled]);

  // Track user manual scrolling to prevent jitter
  const handleScroll = () => {
    setUserHasScrolled(true);
    if (userScrollTimeoutRef.current) {
      clearTimeout(userScrollTimeoutRef.current);
    }
    userScrollTimeoutRef.current = setTimeout(() => {
      setUserHasScrolled(false);
    }, 4500);
  };

  const resumeAutoScroll = () => {
    setUserHasScrolled(false);
  };

  if (!isOpen) return null;

  const artistUrl = getArtistUrl(
    song.artist_id || song.artists?.[0]?.id,
    song.artist_name
  );

  const progressPercent = duration > 0 ? Math.min(100, (currentTime / duration) * 100) : 0;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200"
      data-interactive="true"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className="w-full max-w-2xl max-h-[92vh] sm:max-h-[88vh] bg-white border-4 border-black flex flex-col relative overflow-hidden"
        role="dialog"
        aria-modal="true"
        aria-label="Karaoke Lyrics"
      >
        {/* Top Header Bar */}
        <div className="bg-[#FFE600] border-b-2 border-black p-3 sm:p-4 flex items-center justify-between gap-3 flex-shrink-0">
          <div className="flex items-center gap-2.5 min-w-0 flex-1">
            <div className="p-1.5 bg-black text-[#FFE600] border border-black flex-shrink-0">
              <Mic2 className="w-5 h-5" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-2">
                <h2 className="font-black text-base sm:text-lg text-black truncate leading-tight">
                  {song.title}
                </h2>
                {lyricsData?.isSynced && (
                  <span className="hidden sm:inline-flex items-center gap-1 bg-black text-[#FFE600] text-[10px] font-black uppercase px-1.5 py-0.5 border border-black flex-shrink-0">
                    <Sparkles className="w-2.5 h-2.5" />
                    Karaoke Sync
                  </span>
                )}
              </div>
              <div className="text-xs font-bold text-neutral-700 truncate mt-0.5">
                <Link
                  to={artistUrl}
                  onClick={onClose}
                  className="hover:underline hover:text-black cursor-pointer"
                >
                  {song.artist_name}
                </Link>
              </div>
            </div>
          </div>

          {/* Mode Switcher & Close - Icon Only & Responsive on all screens */}
          <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
            {lyricsData?.isSynced && (
              <div className="flex border-2 border-black bg-white">
                <button
                  type="button"
                  onClick={() => setViewMode("karaoke")}
                  className={`p-1.5 sm:p-2 cursor-pointer transition-colors ${
                    viewMode === "karaoke"
                      ? "bg-black text-[#FFE600]"
                      : "bg-white text-black hover:bg-neutral-100"
                  }`}
                  title="Karaoke Mode (Synced)"
                  aria-label="Karaoke Mode"
                >
                  <Mic2 className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setViewMode("plain")}
                  className={`p-1.5 sm:p-2 cursor-pointer border-l-2 border-black transition-colors ${
                    viewMode === "plain"
                      ? "bg-black text-[#FFE600]"
                      : "bg-white text-black hover:bg-neutral-100"
                  }`}
                  title="Plain Text Mode"
                  aria-label="Plain Text Mode"
                >
                  <AlignLeft className="w-4 h-4" />
                </button>
              </div>
            )}

            <button
              onClick={onClose}
              id="close-lyrics-modal-btn"
              className="p-1.5 sm:p-2 border-2 border-black bg-white hover:bg-black hover:text-white cursor-pointer transition-colors active:translate-x-0.5 active:translate-y-0.5"
              title="Close lyrics"
              aria-label="Close lyrics"
            >
              <X className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          </div>
        </div>

        {/* Translation & Action Toolbar - Responsive & Icon-Only */}
        {lyricsData && (
          <div className="bg-neutral-100 border-b-2 border-black px-2.5 py-1.5 sm:px-4 sm:py-2 flex items-center justify-between gap-2 text-xs flex-shrink-0">
            {/* Left side: Language Selector & Status */}
            <div className="flex items-center gap-1.5 min-w-0 flex-1">
              <div className="flex items-center gap-1.5 bg-white border-2 border-black px-2 py-1 min-w-0 max-w-[180px] sm:max-w-[240px]">
                <Globe className="w-4 h-4 text-black flex-shrink-0" />
                <select
                  value={selectedLanguage}
                  onChange={(e) => handleLanguageChange(e.target.value)}
                  className="bg-transparent font-black text-xs text-black outline-none cursor-pointer w-full truncate"
                  aria-label="Select Google Translate language"
                  title="Select Google Translate language"
                >
                  <option value="none">Original (No Translation)</option>
                  {SUPPORTED_TRANSLATION_LANGUAGES.map((lang) => (
                    <option key={lang.code} value={lang.code}>
                      {lang.flag} {lang.name}
                    </option>
                  ))}
                </select>
              </div>

              {isTranslating && (
                <span
                  className="p-1 text-black flex-shrink-0"
                  title="Translating with Google Translate..."
                >
                  <Loader2 className="w-4 h-4 animate-spin text-black" />
                </span>
              )}

              {translationError && (
                <span className="text-[10px] font-bold text-red-600 bg-red-50 border border-red-300 px-1.5 py-0.5 truncate max-w-[120px] sm:max-w-none">
                  {translationError}
                </span>
              )}
            </div>

            {/* Right side: Icon-Only Action Buttons */}
            <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
              {/* Follow Song / Re-center Button - In Toolbar, Never Overlaps */}
              {lyricsData.isSynced && viewMode === "karaoke" && (
                <button
                  type="button"
                  onClick={resumeAutoScroll}
                  className={`p-1.5 sm:p-2 border-2 border-black cursor-pointer transition-colors ${
                    userHasScrolled
                      ? "bg-[#FFE600] text-black shadow-sm"
                      : "bg-white text-black hover:bg-neutral-100"
                  }`}
                  title={
                    userHasScrolled
                      ? "Follow song: Paused (Click to re-center)"
                      : "Follow song: Active (Click to re-center)"
                  }
                  aria-label="Follow song"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              )}

              {/* Cara Baca (Romaji / Pinyin / Pronunciation) Button - Icon Only */}
              {hasRomanizationAvailable && (
                <button
                  type="button"
                  onClick={() => setShowRomanization(!showRomanization)}
                  className={`p-1.5 sm:p-2 border-2 border-black cursor-pointer transition-colors ${
                    showRomanization
                      ? "bg-[#FFE600] text-black"
                      : "bg-white text-black hover:bg-neutral-100"
                  }`}
                  title={
                    showRomanization
                      ? `${romanizationLabel}: Active (Click to disable)`
                      : `${romanizationLabel}: Inactive (Click to enable)`
                  }
                  aria-label={romanizationLabel}
                >
                  <BookOpen className="w-4 h-4" />
                </button>
              )}

              {/* Salin Lirik Button - Icon Only */}
              <button
                type="button"
                onClick={handleCopyLyrics}
                className="p-1.5 sm:p-2 border-2 border-black bg-white hover:bg-neutral-100 text-black cursor-pointer transition-colors"
                title={copied ? "Lyrics copied!" : "Copy lyrics"}
                aria-label="Copy lyrics"
              >
                {copied ? (
                  <Check className="w-4 h-4 text-green-600 stroke-[3]" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </button>
            </div>
          </div>
        )}

        {/* Main Lyrics Content Area */}
        <div
          ref={lyricsContainerRef}
          onScroll={handleScroll}
          className="flex-1 overflow-y-auto px-4 py-8 sm:px-8 sm:py-10 space-y-4 select-text relative scroll-smooth bg-neutral-50/50"
        >
          {loading && (
            <div className="py-12 space-y-4 text-center">
              <div className="inline-block p-3 bg-[#FFE600] border-2 border-black animate-spin">
                <Mic2 className="w-6 h-6 text-black" />
              </div>
              <p className="font-black text-sm text-neutral-800">
                Loading karaoke lyrics...
              </p>
              <div className="max-w-md mx-auto space-y-2 opacity-50">
                <div className="h-4 bg-neutral-300 rounded border border-neutral-400 w-3/4 mx-auto animate-pulse" />
                <div className="h-4 bg-neutral-300 rounded border border-neutral-400 w-1/2 mx-auto animate-pulse" />
                <div className="h-4 bg-neutral-300 rounded border border-neutral-400 w-2/3 mx-auto animate-pulse" />
              </div>
            </div>
          )}

          {!loading && error && (
            <div className="py-12 text-center max-w-sm mx-auto space-y-3">
              <div className="w-12 h-12 mx-auto bg-neutral-100 border-2 border-black flex items-center justify-center">
                <AlignLeft className="w-6 h-6 text-neutral-500" />
              </div>
              <h3 className="font-black text-base text-black">Lyrics Not Available</h3>
              <p className="text-xs font-semibold text-neutral-600">
                Synced lyrics for this song are not yet available in the database.
              </p>
              <a
                href={`https://www.google.com/search?q=${encodeURIComponent(`${song.title} ${song.artist_name} lyrics`)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block px-3 py-1.5 border-2 border-black bg-[#FFE600] text-black font-black text-xs hover:bg-black hover:text-[#FFE600] transition-colors cursor-pointer"
              >
                Search Lyrics on Google
              </a>
            </div>
          )}

          {!loading && !error && lyricsData && (
            <>
              {/* Karaoke Synced View */}
              {viewMode === "karaoke" && lyricsData.lines.length > 0 ? (
                <div className="flex flex-col items-center justify-center space-y-4 sm:space-y-6 text-center min-h-full py-8">
                  {lyricsData.lines.map((line, idx) => {
                    const isActive = idx === activeLineIndex;
                    const isPast = idx < activeLineIndex;

                    const romajiText = showRomanization
                      ? line.romanization || currentTranslation?.romanizations?.[idx]
                      : null;
                    const translatedText = currentTranslation?.translations?.[idx];

                    return (
                      <div
                        key={`${line.time}-${idx}`}
                        ref={isActive ? activeLineRef : null}
                        onClick={() => onSeek(line.time)}
                        className={`cursor-pointer transition-colors duration-200 px-4 py-2 rounded-sm select-none max-w-xl w-full ${
                          isActive
                            ? "bg-[#FFE600] text-black border-2 border-black"
                            : isPast
                            ? "text-neutral-500 hover:text-black"
                            : "text-neutral-800 hover:text-black opacity-85"
                        }`}
                        title={`Jump to ${formatTime(line.time)}`}
                      >
                        {/* 1. Original text */}
                        <div
                          className={`leading-tight text-sm sm:text-base ${
                            isActive
                              ? "font-bold text-black"
                              : isPast
                              ? "font-medium text-neutral-500"
                              : "font-medium text-neutral-800"
                          }`}
                        >
                          {line.text}
                        </div>

                        {/* 2. Cara Baca (Romaji / Pinyin / Transliterasi) */}
                        {romajiText && (
                          <div
                            className={`mt-1 font-mono tracking-wide text-xs ${
                              isActive
                                ? "font-normal text-neutral-900"
                                : "font-normal text-neutral-500"
                            }`}
                          >
                            {romajiText}
                          </div>
                        )}

                        {/* 3. Google Translate Translation - Huruf normal (tidak tebal) */}
                        {selectedLanguage !== "none" && translatedText && (
                          <div
                            className={`mt-1.5 italic leading-snug font-normal text-xs sm:text-sm transition-colors ${
                              isActive
                                ? "text-neutral-900 border-t border-black/20 pt-1"
                                : "text-neutral-600 border-t border-neutral-200 pt-0.5"
                            }`}
                          >
                            {translatedText}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              ) : (
                /* Plain Text View */
                <div className="max-w-xl mx-auto py-4 space-y-4 text-center">
                  {(lyricsData.lines.length > 0
                    ? lyricsData.lines
                    : (lyricsData.plainLyrics?.split("\n") || []).map((text, i) => ({
                        time: i,
                        text,
                        romanization: lyricsData.plainRomanization?.split("\n")?.[i],
                      }))
                  ).map((line, idx) => {
                    const text = typeof line === "string" ? line : line.text;
                    if (!text.trim()) return <div key={idx} className="h-3" />;

                    const romaji = showRomanization
                      ? (typeof line !== "string" && line.romanization) ||
                        currentTranslation?.romanizations?.[idx]
                      : null;
                    const trans = currentTranslation?.translations?.[idx];

                    return (
                      <div key={idx} className="space-y-0.5 py-1">
                        <p className="font-medium text-sm sm:text-base text-neutral-900">
                          {text}
                        </p>
                        {romaji && (
                          <p className="font-mono text-xs sm:text-sm font-normal text-neutral-600">
                            {romaji}
                          </p>
                        )}
                        {selectedLanguage !== "none" && trans && (
                          <p className="italic text-xs sm:text-sm font-normal text-neutral-700">
                            {trans}
                          </p>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </>
          )}
        </div>

        {/* Bottom Integrated Mini Player Bar */}
        <div className="bg-white border-t-2 border-black p-3 sm:px-6 flex-shrink-0">
          {/* Progress Slider */}
          <div className="relative w-full h-2 bg-neutral-200 border border-black cursor-pointer group mb-2.5">
            <div
              className="h-full bg-[#FFE600] border-r-2 border-black relative"
              style={{ width: `${progressPercent}%` }}
            >
              <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 w-3 h-3 bg-black border border-[#FFE600] pointer-events-none" />
            </div>
            <input
              type="range"
              min={0}
              max={duration || 100}
              step={0.5}
              value={currentTime}
              onChange={(e) => onSeek(parseFloat(e.target.value))}
              aria-label="Seek track"
              className="absolute -top-2 -bottom-2 inset-x-0 w-full opacity-0 cursor-pointer z-10"
            />
          </div>

          <div className="flex items-center justify-between gap-2 sm:gap-3">
            {/* Thumbnail & Title */}
            <div className="flex items-center gap-2 sm:gap-2.5 min-w-0 max-w-[120px] sm:max-w-[200px] md:max-w-xs">
              <img
                src={formatThumbnailUrl(song.thumbnail, 60, 60)}
                alt={song.title}
                className="w-7 h-7 sm:w-8 sm:h-8 border border-black object-cover flex-shrink-0"
              />
              <div className="min-w-0">
                <p className="font-black text-xs text-black truncate">{song.title}</p>
                <p className="text-[10px] font-bold text-neutral-600 truncate">{song.artist_name}</p>
              </div>
            </div>

            {/* Central Controls */}
            <div className="flex items-center gap-1.5 sm:gap-2 flex-shrink-0">
              <button
                type="button"
                onClick={onPrev}
                disabled={!canPrev}
                className="p-1 sm:p-1.5 border-2 border-black bg-white hover:bg-neutral-100 disabled:opacity-30 cursor-pointer"
                title="Previous track"
                aria-label="Previous track"
              >
                <SkipBack className="w-3.5 h-3.5 fill-current text-black" />
              </button>

              <button
                type="button"
                onClick={onTogglePlay}
                className="p-1.5 sm:p-2 border-2 border-black bg-[#FFE600] hover:bg-black hover:text-[#FFE600] transition-colors cursor-pointer active:translate-x-0.5 active:translate-y-0.5"
                title={isPlaying ? "Pause" : "Play"}
                aria-label={isPlaying ? "Pause" : "Play"}
              >
                {isPlaying ? (
                  <Pause className="w-4 h-4 fill-current" />
                ) : (
                  <Play className="w-4 h-4 fill-current ml-0.5" />
                )}
              </button>

              <button
                type="button"
                onClick={onNext}
                disabled={!canNext}
                className="p-1 sm:p-1.5 border-2 border-black bg-white hover:bg-neutral-100 disabled:opacity-30 cursor-pointer"
                title="Next track"
                aria-label="Next track"
              >
                <SkipForward className="w-3.5 h-3.5 fill-current text-black" />
              </button>
            </div>

            {/* Time / Volume */}
            <div className="flex items-center gap-1.5 sm:gap-2 text-right flex-shrink-0">
              <span className="font-mono text-[10px] sm:text-xs font-bold text-neutral-700">
                {formatTime(currentTime)} / {formatTime(duration)}
              </span>
              <button
                type="button"
                onClick={onToggleMute}
                className="hidden sm:inline-flex p-1 border-2 border-black bg-white hover:bg-neutral-100 cursor-pointer"
                title={isMuted ? "Unmute" : "Mute"}
                aria-label={isMuted ? "Unmute" : "Mute"}
              >
                {isMuted || volume === 0 ? (
                  <VolumeX className="w-3.5 h-3.5 text-black" />
                ) : (
                  <Volume2 className="w-3.5 h-3.5 text-black" />
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
