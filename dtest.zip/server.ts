import express from "express";
import path from "path";
import fs from "fs";
import { spawn } from "child_process";
import https from "https";
import http from "http";
import { Innertube } from "youtubei.js";
import { createServer as createViteServer } from "vite";

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true, limit: "10mb" }));

// Allow CORS for anaku.web.id and fomo.web.id
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin) {
    try {
      const originHost = new URL(origin).hostname.toLowerCase();
      if (
        originHost === "anaku.web.id" ||
        originHost.endsWith(".anaku.web.id") ||
        originHost === "fomo.web.id" ||
        originHost.endsWith(".fomo.web.id") ||
        originHost === "localhost" ||
        originHost === "127.0.0.1" ||
        originHost.endsWith(".run.app")
      ) {
        res.setHeader("Access-Control-Allow-Origin", origin);
        res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS, DELETE");
        res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
      }
    } catch {}
  }
  if (req.method === "OPTIONS") {
    return res.sendStatus(204);
  }
  next();
});

// Cache directory
const CACHE_DIR = path.join(process.cwd(), "cache", "downloads");
if (!fs.existsSync(CACHE_DIR)) {
  fs.mkdirSync(CACHE_DIR, { recursive: true });
}

// Cookies file location
const COOKIES_PATH = path.join(process.cwd(), "cookies.txt");
if (!fs.existsSync(COOKIES_PATH)) {
  fs.writeFileSync(COOKIES_PATH, "# Netscape HTTP Cookie File\n", "utf8");
}

const DEFAULT_YTDLP_BIN = fs.existsSync("/usr/local/bin/yt-dlp") ? "/usr/local/bin/yt-dlp" : "yt-dlp";

export interface TrackMetadata {
  id: string;
  title: string;
  artist: string;
  album: string;
  year: string;
  genre: string;
  coverArtUrl: string;
  duration?: number;
}

export type AudioFormat = "mp3" | "m4a";

export interface CacheEntry {
  videoId: string;
  format: AudioFormat;
  fileName: string;
  filePath: string;
  fileSize: number;
  metadata: TrackMetadata;
  cachedAt: number;
  expiresAt: number;
}

// In-memory cache store mapped by `${videoId}_${format}`
const cacheRegistry = new Map<string, CacheEntry>();

// Cache TTL: 15 minutes in milliseconds
const CACHE_TTL_MS = 15 * 60 * 1000;

// Maximum allowed audio duration: 30 minutes (1800 seconds)
const MAX_AUDIO_DURATION_SECONDS = 30 * 60;

function getCacheKey(videoId: string, format: AudioFormat): string {
  return `${videoId}_${format}`;
}

function saveCacheMeta(entry: CacheEntry) {
  try {
    const metaPath = path.join(path.dirname(entry.filePath), "meta.json");
    fs.writeFileSync(metaPath, JSON.stringify(entry, null, 2), "utf8");
  } catch (e) {
    console.error("Failed to write meta.json:", e);
  }
}

function loadDiskCache() {
  try {
    if (!fs.existsSync(CACHE_DIR)) return;
    const dirs = fs.readdirSync(CACHE_DIR);
    const now = Date.now();
    for (const d of dirs) {
      const folder = path.join(CACHE_DIR, d);
      if (!fs.statSync(folder).isDirectory()) continue;
      const metaPath = path.join(folder, "meta.json");
      if (fs.existsSync(metaPath)) {
        try {
          const entry: CacheEntry = JSON.parse(fs.readFileSync(metaPath, "utf8"));
          if (!entry.format) {
            entry.format = entry.fileName.endsWith(".mp3") ? "mp3" : "m4a";
          }
          if (now < entry.expiresAt && fs.existsSync(entry.filePath)) {
            const key = getCacheKey(entry.videoId, entry.format);
            cacheRegistry.set(key, entry);
          } else {
            // Expired or file missing
            fs.rmSync(folder, { recursive: true, force: true });
          }
        } catch (err) {
          console.warn(`Could not parse meta.json in ${folder}:`, err);
        }
      }
    }
  } catch (e) {
    console.error("Error loading disk cache:", e);
  }
}

function getCacheEntry(videoId: string, format?: AudioFormat): CacheEntry | null {
  if (!videoId) return null;
  const now = Date.now();

  if (format) {
    const key = getCacheKey(videoId, format);
    let entry = cacheRegistry.get(key);
    if (entry) {
      if (now >= entry.expiresAt) {
        cacheRegistry.delete(key);
        return null;
      }
      return entry;
    }

    // Disk fallback for specific format
    const metaPath = path.join(CACHE_DIR, `${videoId}_${format}`, "meta.json");
    if (fs.existsSync(metaPath)) {
      try {
        const parsed: CacheEntry = JSON.parse(fs.readFileSync(metaPath, "utf8"));
        if (!parsed.format) parsed.format = format;
        if (now < parsed.expiresAt && fs.existsSync(parsed.filePath)) {
          cacheRegistry.set(key, parsed);
          return parsed;
        }
      } catch (e) {}
    }
  } else {
    // If format is not specified, prefer mp3, then m4a
    const mp3Entry = getCacheEntry(videoId, "mp3");
    if (mp3Entry) return mp3Entry;
    const m4aEntry = getCacheEntry(videoId, "m4a");
    if (m4aEntry) return m4aEntry;
  }

  return null;
}

// Initial disk cache load
loadDiskCache();

// Periodic cleanup worker running every 15 seconds
setInterval(() => {
  const now = Date.now();
  for (const [key, entry] of cacheRegistry.entries()) {
    if (now >= entry.expiresAt) {
      try {
        const parentDir = path.dirname(entry.filePath);
        if (fs.existsSync(parentDir)) {
          fs.rmSync(parentDir, { recursive: true, force: true });
        }
      } catch (err) {
        console.error(`Failed to delete expired cache for ${key}:`, err);
      }
      cacheRegistry.delete(key);
      console.log(`[Cache Cleanup] Expired and removed cache for: ${key}`);
    }
  }
}, 15000);

// Innertube singleton
let innertubeInstance: Innertube | null = null;
async function getInnertube(): Promise<Innertube> {
  if (!innertubeInstance) {
    innertubeInstance = await Innertube.create();
  }
  return innertubeInstance;
}

// Utility: extract video ID from input string
export function extractVideoId(input: string): string | null {
  if (!input) return null;
  const clean = input.trim();
  if (/^[a-zA-Z0-9_-]{11}$/.test(clean)) {
    return clean;
  }
  const match = clean.match(/(?:v=|\/v\/|youtu\.be\/|\/embed\/|\/watch\?v=|\/shorts\/|watch%3Fv%3D)([a-zA-Z0-9_-]{11})/);
  if (match && match[1]) {
    return match[1];
  }
  return null;
}

// Utility: Download image to file
function downloadFile(url: string, destPath: string): Promise<void> {
  return new Promise((resolve, reject) => {
    const file = fs.createWriteStream(destPath);
    const client = url.startsWith("https") ? https : http;
    client
      .get(url, (response) => {
        if (response.statusCode && response.statusCode >= 300 && response.statusCode < 400 && response.headers.location) {
          file.close();
          downloadFile(response.headers.location, destPath).then(resolve).catch(reject);
          return;
        }
        response.pipe(file);
        file.on("finish", () => {
          file.close(() => resolve());
        });
      })
      .on("error", (err) => {
        fs.unlink(destPath, () => {});
        reject(err);
      });
  });
}

// Utility: Sanitize string for filename
function sanitizeFilename(name: string): string {
  return name.replace(/[\/\\?%*:|"<>]/g, "_").trim() || "audio";
}

// Extract metadata using youtubei.js
export async function getTrackMetadata(videoId: string): Promise<TrackMetadata> {
  const yt = await getInnertube();
  let title = "Unknown Title";
  let artist = "Unknown Artist";
  let album = "Unknown Album";
  let year = new Date().getFullYear().toString();
  const genre = "Music"; // default "Music"
  let coverArtUrl = "";
  let duration: number | undefined = undefined;

  try {
    const info = await yt.music.getInfo(videoId);

    // 1. Inspect queue item (tabs[0].content.content.contents[0])
    const tabs = info.tabs as any[];
    const queueContent = tabs?.[0]?.content?.content?.contents?.[0];

    if (queueContent) {
      if (queueContent.title?.text) title = queueContent.title.text;
      else if (queueContent.title?.runs?.[0]?.text) title = queueContent.title.runs[0].text;

      if (queueContent.author) artist = queueContent.author;
      else if (queueContent.artists?.[0]?.name) artist = queueContent.artists[0].name;

      if (queueContent.album?.name) album = queueContent.album.name;
      if (queueContent.album?.year) year = queueContent.album.year;

      if (queueContent.duration?.seconds) {
        duration = Number(queueContent.duration.seconds);
      }
    }

    // 2. Fallbacks from browser_media_session
    const browserMedia = (info.player_overlays as any)?.browser_media_session;
    if (browserMedia) {
      if ((!album || album === "Unknown Album") && browserMedia.album?.text) {
        album = browserMedia.album.text;
      }
      // Prioritize thumbnails on https://yt3.googleusercontent.com/
      const thumbs = browserMedia.thumbnails || [];
      const yt3Thumbs = thumbs.filter((t: any) => t.url && t.url.includes("yt3.googleusercontent.com"));
      if (yt3Thumbs.length > 0) {
        yt3Thumbs.sort((a: any, b: any) => (b.width || 0) - (a.width || 0));
        coverArtUrl = yt3Thumbs[0].url;
      } else if (thumbs.length > 0) {
        thumbs.sort((a: any, b: any) => (b.width || 0) - (a.width || 0));
        coverArtUrl = thumbs[0].url;
      }
    }

    // 3. Fallbacks from basic_info and primary_info
    const primary = (info as any).primary_info;
    if ((!title || title === "Unknown Title") && primary?.title?.text) {
      title = primary.title.text;
    }
    if ((!title || title === "Unknown Title") && info.basic_info?.title) {
      title = info.basic_info.title;
    }
    if ((!artist || artist === "Unknown Artist") && info.basic_info?.author) {
      artist = info.basic_info.author;
    }

    // If still no cover art, look at basic_info thumbnails
    if (!coverArtUrl && info.basic_info?.thumbnail) {
      const basicThumbs = info.basic_info.thumbnail as any[];
      const yt3 = basicThumbs.filter((t: any) => t.url && t.url.includes("yt3.googleusercontent.com"));
      if (yt3.length > 0) {
        yt3.sort((a: any, b: any) => (b.width || 0) - (a.width || 0));
        coverArtUrl = yt3[0].url;
      } else if (basicThumbs.length > 0) {
        basicThumbs.sort((a: any, b: any) => (b.width || 0) - (a.width || 0));
        coverArtUrl = basicThumbs[0].url;
      }
    }
  } catch (err: any) {
    console.warn(`[youtubei.js] Error fetching music info for ${videoId}:`, err?.message || err);
    // Fallback using basic getBasicInfo or general getInfo
    try {
      const basic = await yt.getBasicInfo(videoId);
      if (basic.basic_info?.title) title = basic.basic_info.title;
      if (basic.basic_info?.author) artist = basic.basic_info.author;
      if ((basic.basic_info as any)?.duration) {
        duration = Number((basic.basic_info as any).duration);
      }
      if (basic.basic_info?.thumbnail && Array.isArray(basic.basic_info.thumbnail)) {
        const sorted = [...basic.basic_info.thumbnail].sort((a: any, b: any) => (b.width || 0) - (a.width || 0));
        coverArtUrl = sorted[0]?.url || "";
      }
    } catch (fallbackErr) {
      console.error(`[youtubei.js] Fallback failed:`, fallbackErr);
    }
  }

  // Absolute fallback for cover art
  if (!coverArtUrl) {
    coverArtUrl = `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`;
  }

  return {
    id: videoId,
    title,
    artist,
    album,
    year,
    genre,
    coverArtUrl,
    duration,
  };
}

// ----------------------------------------------------
// API ROUTES
// ----------------------------------------------------

// 1. Check cookies status
app.get("/api/cookies", (req, res) => {
  try {
    const exists = fs.existsSync(COOKIES_PATH);
    if (!exists) {
      return res.json({ exists: false, lineCount: 0, hasNetscapeHeader: false, size: 0 });
    }
    const content = fs.readFileSync(COOKIES_PATH, "utf8");
    const lines = content.split("\n").filter((l) => l.trim().length > 0 && !l.startsWith("#"));
    const hasNetscapeHeader = content.includes("Netscape");
    return res.json({
      exists: true,
      lineCount: lines.length,
      hasNetscapeHeader,
      size: content.length,
      path: COOKIES_PATH,
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// 2. Save cookies.txt
app.post("/api/cookies", (req, res) => {
  try {
    let { cookiesContent } = req.body;
    if (typeof cookiesContent !== "string") {
      return res.status(400).json({ error: "cookiesContent must be a string" });
    }
    if (!cookiesContent.includes("# Netscape HTTP Cookie File")) {
      cookiesContent = "# Netscape HTTP Cookie File\n" + cookiesContent.trim();
    }
    fs.writeFileSync(COOKIES_PATH, cookiesContent, "utf8");
    return res.json({ success: true, message: "cookies.txt updated successfully" });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// 3. Cache Status
app.get("/api/cache", (req, res) => {
  loadDiskCache();
  const now = Date.now();
  const items = Array.from(cacheRegistry.values()).map((entry) => {
    const remainingMs = Math.max(0, entry.expiresAt - now);
    return {
      videoId: entry.videoId,
      format: entry.format || "mp3",
      fileName: entry.fileName,
      fileSize: entry.fileSize,
      metadata: entry.metadata,
      cachedAt: entry.cachedAt,
      expiresAt: entry.expiresAt,
      remainingSeconds: Math.round(remainingMs / 1000),
    };
  });
  return res.json({
    ttlMinutes: 15,
    totalItems: items.length,
    items,
  });
});

// 4. Renew cache manually
app.post("/api/cache/renew", (req, res) => {
  const { videoId, format } = req.body;
  if (!videoId) return res.status(400).json({ error: "videoId is required" });
  const entry = getCacheEntry(videoId, format as AudioFormat);
  if (!entry) return res.status(404).json({ error: "Item not in cache" });

  entry.expiresAt = Date.now() + CACHE_TTL_MS;
  saveCacheMeta(entry);
  return res.json({
    success: true,
    message: "Cache renewed for 15 minutes",
    expiresAt: entry.expiresAt,
    remainingSeconds: 900,
  });
});

// 5. Clear cache item
app.delete("/api/cache/:id", (req, res) => {
  const { id } = req.params;
  let deleted = false;

  // Try exact key first
  if (cacheRegistry.has(id)) {
    const entry = cacheRegistry.get(id)!;
    try {
      if (fs.existsSync(entry.filePath)) fs.unlinkSync(entry.filePath);
      const dir = path.dirname(entry.filePath);
      if (fs.existsSync(dir)) fs.rmSync(dir, { recursive: true, force: true });
    } catch (e) {}
    cacheRegistry.delete(id);
    deleted = true;
  }

  // Also search by videoId for both formats
  const cleanId = extractVideoId(id) || id;
  for (const fmt of ["mp3", "m4a"] as AudioFormat[]) {
    const key = getCacheKey(cleanId, fmt);
    const entry = cacheRegistry.get(key);
    if (entry) {
      try {
        if (fs.existsSync(entry.filePath)) fs.unlinkSync(entry.filePath);
        const dir = path.dirname(entry.filePath);
        if (fs.existsSync(dir)) fs.rmSync(dir, { recursive: true, force: true });
      } catch (e) {}
      cacheRegistry.delete(key);
      deleted = true;
    }
  }

  if (deleted) {
    return res.json({ success: true, message: `Cache removed for ${id}` });
  }
  return res.status(404).json({ error: "Item not found in cache" });
});

// 6. Fetch Metadata Only (Lightweight Preview)
app.post("/api/metadata", async (req, res) => {
  const { urlOrId } = req.body;
  const videoId = extractVideoId(urlOrId);
  if (!videoId) {
    return res.status(400).json({ error: "Invalid YouTube Music URL or Video ID" });
  }

  // Check if already in cache!
  const cached = getCacheEntry(videoId);
  if (cached && fs.existsSync(cached.filePath)) {
    // Renew TTL to 15 minutes
    cached.expiresAt = Date.now() + CACHE_TTL_MS;
    saveCacheMeta(cached);
    const remainingSeconds = Math.round((cached.expiresAt - Date.now()) / 1000);
    return res.json({
      metadata: cached.metadata,
      cached: true,
      format: cached.format,
      expiresAt: cached.expiresAt,
      remainingSeconds,
      downloadUrl: `/api/file/${videoId}?format=${cached.format}`,
    });
  }

  try {
    const metadata = await getTrackMetadata(videoId);
    return res.json({
      metadata,
      cached: false,
      downloadUrl: `/api/file/${videoId}?format=mp3`,
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || "Failed to fetch metadata" });
  }
});

// 7. Download & Tag (Core Engine for MP3 & M4A)
app.post("/api/download", async (req, res) => {
  const { urlOrId, customMetadata } = req.body;
  const requestedFormat: AudioFormat = req.body.format === "m4a" ? "m4a" : "mp3";
  const videoId = extractVideoId(urlOrId);
  if (!videoId) {
    return res.status(400).json({ error: "Invalid YouTube Music URL or Video ID" });
  }

  const cacheKey = getCacheKey(videoId, requestedFormat);

  // 1. Check if item is already in cache for this format
  const existingEntry = getCacheEntry(videoId, requestedFormat);
  if (existingEntry && fs.existsSync(existingEntry.filePath)) {
    // When the user inputs the same link, renew duration back to 15 minutes!
    existingEntry.expiresAt = Date.now() + CACHE_TTL_MS;
    saveCacheMeta(existingEntry);
    console.log(`[Cache Hit] Renewed 15-min TTL for ${cacheKey}`);
    return res.json({
      success: true,
      cached: true,
      renewed: true,
      format: requestedFormat,
      message: `Menggunakan cache lokal (${requestedFormat.toUpperCase()}). Durasi penyimpanan diperpanjang 15 menit.`,
      metadata: existingEntry.metadata,
      fileName: existingEntry.fileName,
      fileSize: existingEntry.fileSize,
      downloadUrl: `/api/file/${videoId}?format=${requestedFormat}`,
      expiresAt: existingEntry.expiresAt,
      remainingSeconds: Math.round((existingEntry.expiresAt - Date.now()) / 1000),
    });
  }

  // 2. Fetch metadata from youtubei.js
  let metadata: TrackMetadata;
  try {
    const fetched = await getTrackMetadata(videoId);
    metadata = {
      ...fetched,
      ...(customMetadata || {}),
    };
  } catch (err: any) {
    console.error(`Metadata fetch failed:`, err);
    metadata = {
      id: videoId,
      title: customMetadata?.title || "Track " + videoId,
      artist: customMetadata?.artist || "Unknown Artist",
      album: customMetadata?.album || "Unknown Album",
      year: customMetadata?.year || new Date().getFullYear().toString(),
      genre: customMetadata?.genre || "Music",
      coverArtUrl: customMetadata?.coverArtUrl || `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
    };
  }

  // Check 30-minute duration limit (1800 seconds)
  if (metadata.duration && metadata.duration > MAX_AUDIO_DURATION_SECONDS) {
    const min = Math.floor(metadata.duration / 60);
    const sec = metadata.duration % 60;
    const durFormatted = `${min}:${sec < 10 ? "0" : ""}${sec}`;
    console.warn(`[Duration Limit Exceeded] Video ${videoId} duration is ${durFormatted} (exceeds 30:00 max)`);
    return res.status(400).json({
      error: `Audio duration (${durFormatted}) exceeds the maximum allowed limit of 30 minutes (30:00).`,
      duration: metadata.duration,
      maxDuration: MAX_AUDIO_DURATION_SECONDS,
    });
  }

  // 3. Prepare paths
  const tmpDir = path.join(process.cwd(), "cache", "tmp");
  if (!fs.existsSync(tmpDir)) {
    fs.mkdirSync(tmpDir, { recursive: true });
  }

  const timestamp = Date.now();
  const rawBaseName = `raw_${videoId}_${timestamp}`;
  const rawOutputTemplate = path.join(tmpDir, `${rawBaseName}.%(ext)s`);
  const expectedRawExt = requestedFormat === "mp3" ? "mp3" : "m4a";
  const rawOutputFile = path.join(tmpDir, `${rawBaseName}.${expectedRawExt}`);
  const coverArtFile = path.join(tmpDir, `cover_${videoId}_${timestamp}.jpg`);

  const finalFolder = path.join(CACHE_DIR, `${videoId}_${requestedFormat}`);
  if (!fs.existsSync(finalFolder)) {
    fs.mkdirSync(finalFolder, { recursive: true });
  }

  const cleanTitle = sanitizeFilename(metadata.title);
  const cleanArtist = sanitizeFilename(metadata.artist);
  const finalFileName = `${cleanArtist} - ${cleanTitle}.${requestedFormat}`;
  const finalFilePath = path.join(finalFolder, finalFileName);

  const ytdlpBin = DEFAULT_YTDLP_BIN;
  const youtubeMusicUrl = `https://music.youtube.com/watch?v=${videoId}`;

  // 4. yt-dlp Configuration:
  // For MP3:
  // yt-dlp -f "bestaudio/best" -x --audio-format mp3 --audio-quality 0 "https://music.youtube.com/watch?v=[idyoutube]"
  // For M4A:
  // yt-dlp -f "ba[acodec^=mp4a.40.]/ba" "https://music.youtube.com/watch?v=[idyoutube]"
  let ytdlpArgs: string[];
  if (requestedFormat === "mp3") {
    ytdlpArgs = [
      "--js-runtimes",
      "deno",
      "--cookies",
      COOKIES_PATH,
      "--match-filter",
      "duration <= 1800",
      "-f",
      "bestaudio/best",
      "-x",
      "--audio-format",
      "mp3",
      "--audio-quality",
      "0",
      "-o",
      rawOutputTemplate,
      youtubeMusicUrl,
      "--no-playlist",
    ];
  } else {
    ytdlpArgs = [
      "--js-runtimes",
      "deno",
      "--cookies",
      COOKIES_PATH,
      "--match-filter",
      "duration <= 1800",
      "-f",
      "ba[acodec^=mp4a.40.]/ba",
      "-o",
      rawOutputFile,
      youtubeMusicUrl,
      "--no-playlist",
    ];
  }

  console.log(`[Executing yt-dlp (${requestedFormat})]: ${ytdlpBin} ${ytdlpArgs.join(" ")}`);

  try {
    // Download audio with yt-dlp
    await new Promise<void>((resolve, reject) => {
      // Remove any existing raw file
      if (fs.existsSync(rawOutputFile)) fs.unlinkSync(rawOutputFile);

      const proc = spawn(ytdlpBin, ytdlpArgs);
      let stderrOutput = "";
      let stdoutOutput = "";

      proc.stdout.on("data", (data) => {
        stdoutOutput += data.toString();
      });

      proc.stderr.on("data", (data) => {
        stderrOutput += data.toString();
      });

      proc.on("close", (code) => {
        // Look for the output file
        let foundRaw = fs.existsSync(rawOutputFile);
        if (!foundRaw) {
          // Check if yt-dlp created a file matching the base name
          const files = fs.readdirSync(tmpDir);
          const matched = files.find((f) => f.startsWith(rawBaseName) && f.endsWith(`.${expectedRawExt}`));
          if (matched) {
            fs.renameSync(path.join(tmpDir, matched), rawOutputFile);
            foundRaw = true;
          }
        }

        if (code === 0 && foundRaw) {
          resolve();
        } else {
          const combinedOutput = `${stderrOutput}\n${stdoutOutput}`;
          if (combinedOutput.includes("does not pass filter (duration <= 1800)")) {
            reject(new Error("Audio duration exceeds the maximum allowed limit of 30 minutes (30:00)."));
          } else if (combinedOutput.includes("Sign in to confirm you’re not a bot")) {
            reject(new Error("YouTube bot authentication triggered. Please refresh cookies.txt."));
          } else if (combinedOutput.includes("Video unavailable") || combinedOutput.includes("Private video")) {
            reject(new Error("YouTube video is unavailable, private, or has been removed."));
          } else {
            const errDetail = stderrOutput || stdoutOutput || `Process exited with code ${code}`;
            reject(new Error(errDetail.slice(0, 300)));
          }
        }
      });

      proc.on("error", (err) => {
        reject(err);
      });
    });

    // 5. Download Cover Art
    let hasCoverArt = false;
    if (metadata.coverArtUrl) {
      try {
        await downloadFile(metadata.coverArtUrl, coverArtFile);
        if (fs.existsSync(coverArtFile) && fs.statSync(coverArtFile).size > 0) {
          hasCoverArt = true;
        }
      } catch (coverErr) {
        console.warn(`Cover art download failed:`, coverErr);
      }
    }

    // 6. Embed metadata and cover art using ffmpeg
    await new Promise<void>((resolve, reject) => {
      const ffmpegArgs = ["-i", rawOutputFile];

      if (requestedFormat === "mp3") {
        if (hasCoverArt) {
          ffmpegArgs.push("-i", coverArtFile);
          ffmpegArgs.push("-map", "0:a");
          ffmpegArgs.push("-map", "1:v");
          ffmpegArgs.push("-c:a", "copy");
          ffmpegArgs.push("-c:v", "copy");
          ffmpegArgs.push("-id3v2_version", "3");
          ffmpegArgs.push("-metadata:s:v", 'title="Album cover"');
          ffmpegArgs.push("-metadata:s:v", 'comment="Cover (front)"');
        } else {
          ffmpegArgs.push("-c", "copy");
          ffmpegArgs.push("-id3v2_version", "3");
        }
      } else {
        // M4A
        if (hasCoverArt) {
          ffmpegArgs.push("-i", coverArtFile);
          ffmpegArgs.push("-map", "0:a");
          ffmpegArgs.push("-map", "1:v");
          ffmpegArgs.push("-c:a", "copy");
          ffmpegArgs.push("-c:v", "copy");
          ffmpegArgs.push("-disposition:v:0", "attached_pic");
        } else {
          ffmpegArgs.push("-c", "copy");
        }
      }

      // Metadata tags
      ffmpegArgs.push(
        "-metadata",
        `title=${metadata.title}`,
        "-metadata",
        `artist=${metadata.artist}`,
        "-metadata",
        `album_artist=${metadata.artist}`,
        "-metadata",
        `album=${metadata.album}`,
        "-metadata",
        `date=${metadata.year}`,
        "-metadata",
        `genre=${metadata.genre || "Music"}`
      );

      ffmpegArgs.push(finalFilePath, "-y");

      console.log(`[Executing ffmpeg tagging (${requestedFormat})]: ffmpeg ${ffmpegArgs.join(" ")}`);
      const ffmpegProc = spawn("ffmpeg", ffmpegArgs);
      let ffmpegErr = "";

      ffmpegProc.stderr.on("data", (d) => {
        ffmpegErr += d.toString();
      });

      ffmpegProc.on("close", (code) => {
        if (code === 0 && fs.existsSync(finalFilePath)) {
          resolve();
        } else {
          reject(new Error(`ffmpeg tagging failed: ${ffmpegErr}`));
        }
      });

      ffmpegProc.on("error", (err) => reject(err));
    });

    // Clean up temporary files
    try {
      if (fs.existsSync(rawOutputFile)) fs.unlinkSync(rawOutputFile);
      if (fs.existsSync(coverArtFile)) fs.unlinkSync(coverArtFile);
    } catch (e) {}

    // 7. Store in Cache with 15-minute TTL
    const stats = fs.statSync(finalFilePath);
    const cachedAt = Date.now();
    const expiresAt = cachedAt + CACHE_TTL_MS;

    const cacheEntry: CacheEntry = {
      videoId,
      format: requestedFormat,
      fileName: finalFileName,
      filePath: finalFilePath,
      fileSize: stats.size,
      metadata,
      cachedAt,
      expiresAt,
    };

    cacheRegistry.set(cacheKey, cacheEntry);
    saveCacheMeta(cacheEntry);
    console.log(`[Cache Created] Stored ${cacheKey} until ${new Date(expiresAt).toISOString()}`);

    return res.json({
      success: true,
      cached: false,
      renewed: false,
      format: requestedFormat,
      message: `Lagu format ${requestedFormat.toUpperCase()} berhasil diunduh dan metadata berhasil ditanam.`,
      metadata,
      fileName: finalFileName,
      fileSize: stats.size,
      downloadUrl: `/api/file/${videoId}?format=${requestedFormat}`,
      expiresAt,
      remainingSeconds: 900,
    });
  } catch (err: any) {
    console.error(`Download process failed for ${videoId} (${requestedFormat}):`, err);
    return res.status(500).json({
      error: err.message || "Proses download atau tagging gagal",
      command: `${ytdlpBin} ${ytdlpArgs.join(" ")}`,
      videoId,
      format: requestedFormat,
    });
  }
});

// 8. Serve cached audio file for direct download
app.get(["/api/file/:videoId", "/api/file/:videoId/:format"], (req, res) => {
  const { videoId } = req.params;
  const requestedFormat = (req.params.format || req.query.format) as AudioFormat | undefined;
  const entry = getCacheEntry(videoId, requestedFormat);

  if (!entry || !fs.existsSync(entry.filePath)) {
    return res.status(404).send("File audio tidak ditemukan atau sudah kadaluarsa (melewati 15 menit). Silakan unduh ulang.");
  }

  // Renew TTL when accessed or downloaded!
  entry.expiresAt = Date.now() + CACHE_TTL_MS;
  saveCacheMeta(entry);
  console.log(`[Cache Renewed] Download served for ${videoId} (${entry.format}), TTL renewed to 15 mins`);

  const mimeType = entry.format === "mp3" ? "audio/mpeg" : "audio/mp4";
  res.setHeader("Content-Disposition", `attachment; filename="${encodeURIComponent(entry.fileName)}"`);
  res.setHeader("Content-Type", mimeType);
  res.setHeader("Cache-Control", "public, max-age=900");

  const stream = fs.createReadStream(entry.filePath);
  stream.pipe(res);
});

// 9. Status/Health
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    ytdlpLocation: DEFAULT_YTDLP_BIN,
    ytdlpExists: fs.existsSync(DEFAULT_YTDLP_BIN),
    cachedItemsCount: cacheRegistry.size,
    cookiesExists: fs.existsSync(COOKIES_PATH),
    formats: ["mp3", "m4a"],
  });
});

// ----------------------------------------------------
// DEDICATED IFRAME DOWNLOAD BUTTON PAGES
// /mp3/:id & /m4a/:id (mp3api.ytjar style)
// ----------------------------------------------------
function renderIframeButton(req: express.Request, res: express.Response, targetFormat: AudioFormat) {
  const videoId = req.params.id || (req.query.id as string) || "";
  const cleanId = extractVideoId(videoId) || videoId;
  const theme = (req.query.theme as string) || "ytjar";
  const customColor = (req.query.color as string) || "";
  const defaultLabel = targetFormat === "mp3" ? "Download MP3" : "Download M4A";
  const customText = (req.query.text as string) || defaultLabel;

  // Validate referer when embedded on an external website
  const referer = (req.headers.referer || req.headers.referrer) as string | undefined;
  if (referer) {
    try {
      const refUrl = new URL(referer);
      const refHost = refUrl.hostname.toLowerCase();
      const currentHost = (req.headers.host || "").split(":")[0].toLowerCase();

      const isAllowed =
        refHost === "anaku.web.id" ||
        refHost.endsWith(".anaku.web.id") ||
        refHost === "fomo.web.id" ||
        refHost.endsWith(".fomo.web.id") ||
        refHost === currentHost ||
        refHost === "localhost" ||
        refHost === "127.0.0.1" ||
        refHost.endsWith(".run.app");

      if (!isAllowed) {
        console.warn(`[Iframe Access Blocked] Unauthorized referer: ${refHost}`);
        return res.status(403).send(`<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <title>403 Forbidden</title>
  <style>
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      background: #FFF0F0;
      color: #B71C1C;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      height: 100vh;
      margin: 0;
      text-align: center;
      padding: 10px;
      font-size: 11px;
      font-weight: 700;
      box-sizing: border-box;
    }
  </style>
</head>
<body>
  <div>403 Forbidden</div>
</body>
</html>`);
      }
    } catch {}
  }

  // Restrict iframe embedding specifically to anaku.web.id and fomo.web.id (plus 'self' and preview container)
  const allowedAncestors = [
    "'self'",
    "https://anaku.web.id",
    "https://*.anaku.web.id",
    "http://anaku.web.id",
    "http://*.anaku.web.id",
    "https://fomo.web.id",
    "https://*.fomo.web.id",
    "http://fomo.web.id",
    "http://*.fomo.web.id",
    "https://*.run.app",
    "http://localhost:*",
    "http://127.0.0.1:*",
  ].join(" ");

  res.removeHeader("X-Frame-Options");
  res.setHeader("Content-Security-Policy", `frame-ancestors ${allowedAncestors};`);
  res.setHeader("Content-Type", "text/html; charset=utf-8");

  // Check if item is already in cache for immediate server-side title rendering
  const cachedEntry = cleanId ? getCacheEntry(cleanId, targetFormat) : null;
  const initialTitle = cachedEntry
    ? `${cachedEntry.metadata.title} - ${cachedEntry.metadata.artist}`
    : cleanId
    ? "Memuat info lagu..."
    : "ID YouTube Tidak Ditemukan";

  const isNeobrutalism = theme === "neobrutalism";
  const primaryBg = customColor
    ? `#${customColor.replace("#", "")}`
    : isNeobrutalism
    ? "#FFE500"
    : targetFormat === "mp3"
    ? "#2563EB"
    : "#64c896";

  const textColor = isNeobrutalism ? "#000000" : "#ffffff";
  const borderStyle = "border: none; outline: none;";
  const postMsgType = targetFormat === "mp3" ? "MP3_DOWNLOAD_RENEWED" : "M4A_DOWNLOAD_RENEWED";

  const html = `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${defaultLabel}</title>
  <style>
    * {
      box-sizing: border-box;
      outline: none !important;
    }
    html, body {
      height: 100%;
      width: 100%;
      padding: 0;
      margin: 0;
      overflow: hidden;
      background: transparent;
      outline: none !important;
    }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      font-size: 16px;
      user-select: none;
      -webkit-user-select: none;
      outline: none !important;
    }
    a#downloadButton {
      display: block;
      width: 100%;
      height: 100%;
      text-decoration: none !important;
      outline: none !important;
      border: none !important;
    }
    .progress-button {
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      width: 100%;
      height: 100%;
      background-color: ${primaryBg};
      color: ${textColor} !important;
      text-align: center;
      border-radius: ${isNeobrutalism ? "0px" : "2px"};
      cursor: pointer;
      line-height: 1.15;
      padding: 4px 8px;
      position: relative;
      overflow: hidden;
      box-shadow: none !important;
      border: none !important;
      outline: none !important;
      ${borderStyle}
      transition: opacity 0.15s ease, transform 0.1s ease;
    }
    .progress-button:hover {
      opacity: 0.92;
    }
    .progress-button:active {
      transform: scale(0.99);
    }
    .progress-button.is-error {
      background-color: #EF4444 !important;
      color: #FFFFFF !important;
    }
    .progress-button.is-error #dt,
    .progress-button.is-error .buttonTitle {
      color: #FFFFFF !important;
    }
    #percentageText {
      width: 96%;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }
    #dt {
      font-size: 17px;
      font-weight: 800;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      letter-spacing: -0.2px;
    }
    .buttonTitle {
      font-size: 10px;
      margin-top: 3px;
      font-weight: 600;
      opacity: 0.95;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      max-width: 95%;
    }
    .spinner {
      display: inline-block;
      width: 13px;
      height: 13px;
      border: 2px solid rgba(255,255,255,0.4);
      border-radius: 50%;
      border-top-color: #ffffff;
      animation: spin 0.7s linear infinite;
    }
    ${isNeobrutalism ? ".spinner { border: 2px solid rgba(0,0,0,0.25); border-top-color: #000000; }" : ""}
    @keyframes spin {
      to { transform: rotate(360deg); }
    }
    @media (max-height: 50px) {
      #dt { font-size: 14px; }
      .buttonTitle { font-size: 9px; margin-top: 2px; }
    }
    @media (max-height: 38px) {
      #dt { font-size: 13px; }
      .buttonTitle { display: none; }
    }
    @media (max-width: 180px) {
      #dt { font-size: 13px; }
      .buttonTitle { font-size: 8px; }
    }
  </style>
</head>
<body>
  <a id="downloadButton" href="javascript:void(0);" target="_self">
    <div id="container" class="progress-button">
      <div id="percentageText">
        <span id="dt">${customText}</span>
        <div id="buttonTitle" class="buttonTitle">${initialTitle}</div>
      </div>
    </div>
  </a>

  <script>
    (function() {
      var videoId = "${cleanId}";
      var targetFormat = "${targetFormat}";
      var dt = document.getElementById("dt");
      var titleEl = document.getElementById("buttonTitle");
      var btn = document.getElementById("downloadButton");
      var container = document.getElementById("container");
      var isProcessing = false;

      if (!videoId) {
        dt.innerText = "Error: Missing ID";
        titleEl.innerText = "Usage: /" + targetFormat + "/[youtube_id]";
        container.classList.add("is-error");
        return;
      }

      // 1. Fetch live metadata in background to ensure accurate title display & validate duration
      fetch("/api/metadata", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ urlOrId: videoId })
      })
      .then(function(res) { return res.json(); })
      .then(function(data) {
        if (data && data.metadata) {
          if (data.metadata.duration && data.metadata.duration > 1800) {
            var m = Math.floor(data.metadata.duration / 60);
            var s = data.metadata.duration % 60;
            var durTxt = m + ":" + (s < 10 ? "0" : "") + s;
            dt.innerText = "Error: Exceeds 30 Min";
            titleEl.innerText = (data.metadata.title || "Audio") + " (" + durTxt + " > 30:00 limit)";
            titleEl.title = "Audio duration exceeds maximum limit of 30 minutes";
            container.classList.add("is-error");
            btn.style.cursor = "not-allowed";
            return;
          }
          if (data.metadata.title) {
            titleEl.innerText = data.metadata.title + (data.metadata.artist ? " - " + data.metadata.artist : "");
            if (data.cached) {
              titleEl.title = "Available in cache (Fast 1-Click)";
            }
          }
        }
      })
      .catch(function(err) {
        console.warn("Could not prefetch metadata:", err);
      });

      // 2. Click Handler - 1-Click Download & Tagging
      btn.addEventListener("click", function(e) {
        e.preventDefault();
        if (isProcessing) return;
        isProcessing = true;

        var originalText = dt.innerText;
        var originalTitle = titleEl.innerText;
        container.classList.remove("is-error");

        dt.innerHTML = '<span class="spinner"></span> Processing...';
        titleEl.innerText = "Downloading " + targetFormat.toUpperCase() + " & embedding tags...";

        fetch("/api/download", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ urlOrId: videoId, format: targetFormat })
        })
        .then(function(res) {
          if (!res.ok) {
            return res.json().then(function(data) {
              throw new Error(data.error || "Failed to download audio");
            });
          }
          return res.json();
        })
        .then(function(data) {
          dt.innerText = "Download Ready!";
          titleEl.innerText = (data.metadata ? data.metadata.title : ("Audio " + targetFormat.toUpperCase())) + " (Cache reset to 15m)";

          // Notify parent window if embedded in iframe
          if (window.parent && window.parent !== window) {
            try {
              window.parent.postMessage({
                type: "${postMsgType}",
                videoId: videoId,
                format: targetFormat,
                expiresAt: data.expiresAt
              }, "*");
            } catch (err) {}
          }

          // Trigger browser file download
          var dlUrl = data.downloadUrl || ("/api/file/" + videoId + "?format=" + targetFormat);
          var downloadLink = document.createElement("a");
          downloadLink.href = dlUrl;
          downloadLink.setAttribute("download", data.fileName || ("audio." + targetFormat));
          document.body.appendChild(downloadLink);
          downloadLink.click();
          document.body.removeChild(downloadLink);

          setTimeout(function() {
            dt.innerText = "${customText}";
            if (data.metadata) {
              titleEl.innerText = data.metadata.title + " - " + data.metadata.artist;
            }
            isProcessing = false;
          }, 3500);
        })
        .catch(function(err) {
          isProcessing = false;
          container.classList.add("is-error");
          var msg = err.message || "Failed to process audio";

          // Format clean English error message on button
          if (msg.toLowerCase().includes("30 minute") || msg.toLowerCase().includes("exceeds")) {
            dt.innerText = "Error: Exceeds 30 Min";
            titleEl.innerText = "Max allowed duration is 30:00 minutes";
          } else if (msg.toLowerCase().includes("invalid") || msg.toLowerCase().includes("not found")) {
            dt.innerText = "Error: Video Not Found";
            titleEl.innerText = "Check YouTube ID or link";
          } else if (msg.toLowerCase().includes("bot") || msg.toLowerCase().includes("cookies")) {
            dt.innerText = "Error: Cookies Required";
            titleEl.innerText = "Bot verification triggered";
          } else {
            dt.innerText = "Error: Download Failed";
            titleEl.innerText = msg.length > 45 ? msg.slice(0, 42) + "..." : msg;
          }

          titleEl.title = msg;

          setTimeout(function() {
            container.classList.remove("is-error");
            dt.innerText = "${customText}";
            titleEl.innerText = originalTitle;
          }, 6000);
        });
      });
    })();
  </script>
</body>
</html>`;

  return res.send(html);
}

// 10. Dedicated Iframe Download Button Routes:
// A. MP3 Route (/mp3/:id and /mp3?id=...)
app.get(["/mp3/:id", "/mp3"], (req, res) => {
  renderIframeButton(req, res, "mp3");
});

// B. M4A Route (/m4a/:id and /m4a?id=...)
app.get(["/m4a/:id", "/m4a"], (req, res) => {
  renderIframeButton(req, res, "m4a");
});

// Start Express + Vite
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
