import React, { useState } from "react";
import { Terminal, Code, ChevronDown, ChevronUp, Copy, Check, ShieldCheck, FileAudio, Music } from "lucide-react";

export const CommandReference: React.FC = () => {
  const [copiedMp3, setCopiedMp3] = useState(false);
  const [copiedM4a, setCopiedM4a] = useState(false);
  const [expanded, setExpanded] = useState(false);

  const mp3Command = `yt-dlp \\
  -f "bestaudio/best" \\
  -x \\
  --audio-format mp3 \\
  --audio-quality 0 \\
  "https://music.youtube.com/watch?v=[idyoutube]"`;

  const m4aCommand = `yt-dlp \\
  --js-runtimes node \\
  --cookies cookies.txt \\
  -f "ba[acodec^=mp4a.40.]/ba" \\
  "https://music.youtube.com/watch?v=[idyoutube]"`;

  const copyMp3 = () => {
    navigator.clipboard.writeText(mp3Command);
    setCopiedMp3(true);
    setTimeout(() => setCopiedMp3(false), 2000);
  };

  const copyM4a = () => {
    navigator.clipboard.writeText(m4aCommand);
    setCopiedM4a(true);
    setTimeout(() => setCopiedM4a(false), 2000);
  };

  return (
    <div className="w-full bg-white border-2 border-black">
      {/* Accordion Bar */}
      <button
        type="button"
        onClick={() => setExpanded(!expanded)}
        className="w-full px-4 py-3 bg-[#fafafa] hover:bg-zinc-100 flex items-center justify-between text-left cursor-pointer transition-colors"
      >
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-black" />
          <span className="text-xs font-black uppercase tracking-wider text-black">
            Spesifikasi Eksekusi yt-dlp (MP3 &amp; M4A) &amp; Metadata Engine
          </span>
          <span className="hidden sm:inline-block text-[10px] bg-black text-[#FFE500] px-2 py-0.5 font-mono font-bold">
            /usr/local/bin/yt-dlp
          </span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-zinc-600">
            {expanded ? "Sembunyikan Detail" : "Lihat Perintah & Tag"}
          </span>
          {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </div>
      </button>

      {/* Expanded Content */}
      {expanded && (
        <div className="p-4 sm:p-5 border-t-2 border-black space-y-4 text-xs">
          {/* 1. MP3 Command (User Requested Configuration) */}
          <div className="space-y-1.5 border-2 border-black p-3 bg-zinc-50">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <FileAudio className="w-4 h-4 text-black" />
                <span className="font-black text-black uppercase tracking-wide">
                  Konfigurasi yt-dlp Format MP3:
                </span>
              </div>
              <button
                type="button"
                onClick={copyMp3}
                className="inline-flex items-center gap-1 bg-white hover:bg-[#FFE500] border-2 border-black px-2 py-0.5 font-bold text-[11px] cursor-pointer"
              >
                {copiedMp3 ? <Check className="w-3.5 h-3.5 text-green-700" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedMp3 ? "Tersalin!" : "Salin Perintah MP3"}</span>
              </button>
            </div>

            <div className="bg-black text-[#CCFF00] p-3 font-mono text-[11px] sm:text-xs overflow-x-auto border-2 border-black leading-relaxed whitespace-pre">
              <code>{mp3Command}</code>
            </div>
            <p className="text-[11px] text-zinc-600 font-medium">
              * Mode MP3 mengekstrak audio kualitas terbaik (<code className="font-mono">audio-quality 0</code>) dan menanam ID3v2 tags (Cover Art, Title, Artist, Album, Year, Genre Music). Iframe route: <code className="font-bold text-black font-mono">/mp3/[idyoutube]</code>.
            </p>
          </div>

          {/* 2. M4A Command */}
          <div className="space-y-1.5 border-2 border-black p-3 bg-zinc-50">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <Music className="w-4 h-4 text-black" />
                <span className="font-black text-black uppercase tracking-wide">
                  Konfigurasi yt-dlp Format M4A:
                </span>
              </div>
              <button
                type="button"
                onClick={copyM4a}
                className="inline-flex items-center gap-1 bg-white hover:bg-[#FFE500] border-2 border-black px-2 py-0.5 font-bold text-[11px] cursor-pointer"
              >
                {copiedM4a ? <Check className="w-3.5 h-3.5 text-green-700" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedM4a ? "Tersalin!" : "Salin Perintah M4A"}</span>
              </button>
            </div>

            <div className="bg-black text-[#FFE500] p-3 font-mono text-[11px] sm:text-xs overflow-x-auto border-2 border-black leading-relaxed whitespace-pre">
              <code>{m4aCommand}</code>
            </div>
            <p className="text-[11px] text-zinc-600 font-medium">
              * Mode M4A mengunduh stream AAC asli tanpa re-encode. Iframe route: <code className="font-bold text-black font-mono">/m4a/[idyoutube]</code>.
            </p>
          </div>

          {/* Breakdown Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {/* Box 1: YouTubei.js Meta Tag Injection */}
            <div className="p-3 border-2 border-black bg-white space-y-2">
              <div className="flex items-center gap-1.5 font-black text-black uppercase">
                <Code className="w-4 h-4 text-black" />
                <span>Penanaman Meta Tag (YouTubei.js)</span>
              </div>
              <ul className="space-y-1 text-zinc-800">
                <li>
                  &bull; <strong>Cover Art:</strong> Diprioritaskan dari{" "}
                  <code className="bg-zinc-100 px-1 border border-zinc-300 font-mono text-[10px]">
                    https://yt3.googleusercontent.com/
                  </code>
                </li>
                <li>
                  &bull; <strong>Title:</strong> Judul lagu resmi YouTube Music
                </li>
                <li>
                  &bull; <strong>Artist:</strong> Nama penyanyi / artis
                </li>
                <li>
                  &bull; <strong>Album:</strong> Album / Cover song collection
                </li>
                <li>
                  &bull; <strong>Year:</strong> Tahun rilis lagu
                </li>
                <li>
                  &bull; <strong>Genre:</strong> Default <span className="font-bold">Music</span>
                </li>
              </ul>
            </div>

            {/* Box 2: Cache & Auto Expire */}
            <div className="p-3 border-2 border-black bg-white space-y-2">
              <div className="flex items-center gap-1.5 font-black text-black uppercase">
                <ShieldCheck className="w-4 h-4 text-black" />
                <span>Mekanisme Cache 15 Menit</span>
              </div>
              <ul className="space-y-1 text-zinc-800">
                <li>
                  &bull; File audio MP3 &amp; M4A disimpan di cache lokal selama <strong>15 menit</strong>.
                </li>
                <li>
                  &bull; <strong>Reset Durasi:</strong> Jika Anda memasukkan link yang sama, durasi otomatis kembali menjadi <strong>15 menit penuh</strong>.
                </li>
                <li>
                  &bull; <strong>Pembersihan Otomatis:</strong> File yang tidak diakses selama 15 menit otomatis dihapus oleh background sweeper.
                </li>
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
