import React from "react";
import { Music, Clock, Terminal, Cookie } from "lucide-react";

interface HeaderProps {
  cachedCount: number;
  cookiesConfigured: boolean;
  onOpenCookies: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  cachedCount,
  cookiesConfigured,
  onOpenCookies,
}) => {
  return (
    <header className="w-full bg-[#FFE500] border-b-2 border-black px-4 py-3 sm:px-6">
      <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 bg-black text-white flex items-center justify-center font-black border-2 border-black">
            <Music className="w-5 h-5 text-[#FFE500]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-black tracking-tight text-black uppercase">
                YT-DLP Music Downloader
              </h1>
              <span className="text-[11px] font-bold bg-black text-[#FFE500] px-2 py-0.5 border-2 border-black uppercase tracking-wider">
                MP3 + M4A
              </span>
            </div>
            <p className="text-xs font-semibold text-black/80">
              YouTubei.js Metadata &bull; 15-Min Auto Cache &bull; /mp3/:id &amp; /m4a/:id
            </p>
          </div>
        </div>

        {/* System Badges */}
        <div className="flex flex-wrap items-center gap-2 text-xs font-bold">
          <div className="flex items-center gap-1.5 bg-white px-2.5 py-1 border-2 border-black">
            <Clock className="w-3.5 h-3.5 text-black" />
            <span>Cache: {cachedCount} Lagu</span>
          </div>

          <button
            type="button"
            onClick={onOpenCookies}
            className={`flex items-center gap-1.5 px-2.5 py-1 border-2 border-black transition-colors cursor-pointer ${
              cookiesConfigured
                ? "bg-[#CCFF00] hover:bg-[#b8e600] text-black"
                : "bg-[#FF5555] hover:bg-[#e04545] text-white"
            }`}
            title="Kelola cookies.txt"
          >
            <Cookie className="w-3.5 h-3.5" />
            <span>{cookiesConfigured ? "Cookies: Aktif" : "Cookies: Belum Diatur"}</span>
          </button>

          <div className="hidden md:flex items-center gap-1.5 bg-black text-white px-2.5 py-1 border-2 border-black">
            <Terminal className="w-3.5 h-3.5 text-[#FFE500]" />
            <span className="font-mono text-[11px]">/usr/local/bin/yt-dlp</span>
          </div>
        </div>
      </div>
    </header>
  );
};
