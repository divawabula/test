import React, { useState, useEffect } from "react";
import { Header } from "./components/Header";
import { OneClickDownloader } from "./components/OneClickDownloader";
import { CacheManager } from "./components/CacheManager";
import { CommandReference } from "./components/CommandReference";
import { IframeEmbedGenerator } from "./components/IframeEmbedGenerator";
import { CookiesModal } from "./components/CookiesModal";
import { CookiesStatus } from "./types";
import { secureFetch } from "./utils/crypto";

export default function App() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [cachedCount, setCachedCount] = useState(0);
  const [cookiesConfigured, setCookiesConfigured] = useState(false);
  const [isCookiesOpen, setIsCookiesOpen] = useState(false);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const params = new URLSearchParams(window.location.search);
      if (params.get("admin") === "true" || params.get("manage") === "1" || params.get("tools") === "1") {
        setIsAdmin(true);
      }
    }
  }, []);

  const checkStatus = async () => {
    try {
      // Check cache count with AES-256 encrypted payload
      const cacheRes = await secureFetch("/api/cache");
      const cacheData = await cacheRes.json();
      if (cacheData.totalItems !== undefined) {
        setCachedCount(cacheData.totalItems);
      }

      // Check cookies with AES-256 encrypted payload
      const cookiesRes = await secureFetch("/api/cookies");
      const cookiesData: CookiesStatus = await cookiesRes.json();
      setCookiesConfigured(Boolean(cookiesData.exists && cookiesData.lineCount > 0));
    } catch (err) {
      console.error("Gagal memeriksa status:", err);
    }
  };

  useEffect(() => {
    if (!isAdmin) return;
    checkStatus();
    const interval = setInterval(checkStatus, 10000);
    return () => clearInterval(interval);
  }, [isAdmin, refreshTrigger]);

  const handleDownloadSuccess = () => {
    setRefreshTrigger((prev) => prev + 1);
    checkStatus();
  };

  // Home Page: BLANK text "Hello World" (web fokus ke Iframe saja)
  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-white text-black p-4 font-mono text-base select-text">
        Hello World
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F5F5F0] text-[#111111] flex flex-col selection:bg-[#FFE500] selection:text-black">
      {/* Top Header */}
      <Header
        cachedCount={cachedCount}
        cookiesConfigured={cookiesConfigured}
        onOpenCookies={() => setIsCookiesOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-5xl w-full mx-auto p-4 sm:p-6 space-y-6">
        {/* Intro Banner */}
        <div className="bg-[#FFE500] border-2 border-black p-4 sm:p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="bg-black text-[#FFE500] px-2 py-0.5 text-[11px] font-mono font-bold uppercase tracking-wider">
                yt-dlp + youtubei.js
              </span>
              <span className="text-xs font-bold text-black uppercase">
                WEBM &bull; MP3 &bull; M4A
              </span>
            </div>
            <h2 className="text-lg sm:text-xl font-black text-black tracking-tight uppercase">
              Pengunduh Audio YouTube Music Presisi Tinggi
            </h2>
            <p className="text-xs text-black/90 font-medium max-w-2xl">
              Mendukung format <strong className="text-black font-bold">WebM (Langsung Tanpa Metadata)</strong>, <strong className="text-black font-bold">MP3 (Best Audio, Quality 0)</strong>, dan <strong className="text-black font-bold">M4A</strong> via <code className="bg-white/80 px-1 border border-black font-mono">yt-dlp</code>, halaman iframe <code className="bg-white/80 px-1 border border-black font-mono font-bold">/webm/[idyoutube]</code>, <code className="bg-white/80 px-1 border border-black font-mono font-bold">/mp3/[idyoutube]</code>, serta auto-cache 15 menit dengan auto-reset jika link diulang.
            </p>
          </div>

          <div className="shrink-0 flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsCookiesOpen(true)}
              className="px-3 py-2 bg-white hover:bg-zinc-100 text-black border-2 border-black text-xs font-black uppercase tracking-wide cursor-pointer transition-colors"
            >
              Pengaturan Cookies
            </button>
          </div>
        </div>

        {/* 1-Click Downloader with WebM, MP3 & M4A options */}
        <OneClickDownloader
          onDownloadSuccess={handleDownloadSuccess}
          onOpenCookies={() => setIsCookiesOpen(true)}
        />

        {/* Dedicated Iframe Download Button Generator (/webm/:id, /mp3/:id & /m4a/:id) */}
        <IframeEmbedGenerator />

        {/* Cache Manager with 15-Minute Countdown */}
        <CacheManager
          onSelectSong={() => {}}
          refreshTrigger={refreshTrigger}
        />

        {/* Technical Specification & Command Reference */}
        <CommandReference />
      </main>

      {/* Footer */}
      <footer className="w-full bg-white border-t-2 border-black px-4 py-4 mt-8">
        <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-xs font-bold text-zinc-600">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="w-2.5 h-2.5 bg-[#00AA00] rounded-none inline-block border border-black"></span>
            <span className="text-black font-mono">yt-dlp: /usr/local/bin/yt-dlp</span>
            <span>&bull;</span>
            <span className="text-black font-mono">Endpoints: /webm/:id &bull; /mp3/:id &bull; /m4a/:id</span>
            <span>&bull;</span>
            <span>Cache TTL: 15 Menit</span>
          </div>
          <p className="text-[11px] text-zinc-500">
            Neobrutalism UI &bull; No Shadow Box &bull; Ringan &amp; Responsif
          </p>
        </div>
      </footer>

      {/* Cookies Modal */}
      <CookiesModal
        isOpen={isCookiesOpen}
        onClose={() => setIsCookiesOpen(false)}
        onSaved={() => {
          checkStatus();
          setRefreshTrigger((p) => p + 1);
        }}
      />
    </div>
  );
}
